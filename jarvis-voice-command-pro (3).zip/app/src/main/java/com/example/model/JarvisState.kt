package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.AmberSecondary
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSecondary
import com.example.ui.theme.RedGlow
import com.example.ui.theme.RedPrimary
import com.example.ui.theme.RedSecondary
import com.example.ui.theme.VioletGlow
import com.example.ui.theme.VioletPrimary
import com.example.ui.theme.VioletSecondary

enum class AssistantState(val label: String) {
    IDLE("STANDBY"),
    LISTENING("LISTENING..."),
    THINKING("PROCESSING QUERY"),
    SPEAKING("ONLINE / TRANSMITTING"),
    OVERDRIVE("REACTOR OVERDRIVE")
}

enum class HoloTheme(
    val title: String,
    val codename: String,
    val primary: Color,
    val secondary: Color,
    val glow: Color
) {
    CYAN("Mark LXXXV", "Protocol Titanium", CyanPrimary, CyanSecondary, CyanGlow),
    RED("Mark XLII", "Protocol Hotrod", RedPrimary, RedSecondary, RedGlow),
    EMERALD("Mark XVII", "Heartbreaker", EmeraldPrimary, EmeraldSecondary, EmeraldGlow),
    VIOLET("Mark XLIX", "Rescue", VioletPrimary, VioletSecondary, VioletGlow),
    AMBER("Mark II", "War Machine", AmberPrimary, AmberSecondary, AmberGlow)
}

enum class ReactorStyle(val label: String) {
    RING("CONCENTRIC RINGS"),
    SPHERE("SPHERICAL MATRIX"),
    WIREFRAME("QUANTUM MESH")
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String, // "USER", "JARVIS", "SYSTEM"
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actionBadge: String? = null
)

data class TelemetryData(
    val batteryPct: Int = 88,
    val isCharging: Boolean = false,
    val memoryUsageMb: Int = 412,
    val coreTempC: Float = 34.2f,
    val coreOutputMw: Float = 3.2f,
    val rpm: Int = 14200,
    val latencyMs: Int = 18,
    val networkStatus: String = "SECURE STARK-NET"
)

data class TacticalDirective(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val detail: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isCompleted: Boolean = false,
    val priority: DirectivePriority = DirectivePriority.NORMAL
)

enum class DirectivePriority {
    CRITICAL, HIGH, NORMAL
}
