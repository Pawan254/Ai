package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Assistant
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tune
import androidx.compose.ui.graphics.vector.ImageVector

enum class AppCategory(val title: String) {
    ALL("ALL PROTOCOLS"),
    COMMUNICATION("COMMUNICATION"),
    SOCIAL("SOCIAL & MEDIA"),
    AI_TOOLS("AI & PRODUCTIVITY"),
    SYSTEM("SYSTEM & UTILITIES"),
    GAMING("GAMING & LEISURE")
}

enum class SubSystemType {
    WHATSAPP_COMPOSER,
    PHONE_DIALER,
    CALCULATOR,
    CAMERA_SCANNER,
    YOUTUBE_SEARCH,
    AI_TERMINAL,
    NOTES_PAD,
    BATTERY_AMPERE,
    MAPS_NAV,
    SOUND_RECORDER,
    GAME_BOOSTER,
    GENERIC_LAUNCHER
}

data class AppItem(
    val id: String,
    val name: String,
    val packageName: String,
    val category: AppCategory,
    val iconVector: ImageVector,
    val description: String,
    val subSystemType: SubSystemType = SubSystemType.GENERIC_LAUNCHER
)

object AppRegistry {
    val allApps = listOf(
        AppItem("whatsapp", "WhatsApp", "com.whatsapp", AppCategory.COMMUNICATION, Icons.AutoMirrored.Filled.Chat, "Secure encrypted communications", SubSystemType.WHATSAPP_COMPOSER),
        AppItem("phone", "Phone", "com.google.android.dialer", AppCategory.COMMUNICATION, Icons.Default.Phone, "Stark satellite frequency dialer", SubSystemType.PHONE_DIALER),
        AppItem("contacts", "Contacts", "com.google.android.contacts", AppCategory.COMMUNICATION, Icons.Default.Phone, "Personnel and operative database", SubSystemType.PHONE_DIALER),
        AppItem("nova_messages", "Nova Messages", "com.google.android.apps.messaging", AppCategory.COMMUNICATION, Icons.AutoMirrored.Filled.Message, "Sub-space SMS relays", SubSystemType.WHATSAPP_COMPOSER),
        AppItem("telegram", "Telegram", "org.telegram.messenger", AppCategory.COMMUNICATION, Icons.AutoMirrored.Filled.Chat, "Encrypted cloud channel matrix", SubSystemType.WHATSAPP_COMPOSER),
        AppItem("truecaller", "Truecaller", "com.truecaller", AppCategory.COMMUNICATION, Icons.Default.Security, "Caller ID telemetry & spam filter", SubSystemType.PHONE_DIALER),
        
        AppItem("instagram", "Instagram", "com.instagram.android", AppCategory.SOCIAL, Icons.Default.PhotoCamera, "Visual media reconnaissance", SubSystemType.GENERIC_LAUNCHER),
        AppItem("snapchat", "Snapchat", "com.snapchat.android", AppCategory.SOCIAL, Icons.Default.CameraAlt, "Ephemeral video telemetry", SubSystemType.CAMERA_SCANNER),
        AppItem("linkedin", "LinkedIn", "com.linkedin.android", AppCategory.SOCIAL, Icons.Default.Language, "Stark corporate operative network", SubSystemType.GENERIC_LAUNCHER),
        AppItem("pinterest", "Pinterest", "com.pinterest", AppCategory.SOCIAL, Icons.Default.PhotoLibrary, "Visual engineering moodboards", SubSystemType.GENERIC_LAUNCHER),
        
        AppItem("youtube", "YouTube", "com.google.android.youtube", AppCategory.SOCIAL, Icons.Default.SmartDisplay, "Visual data broadcast stream", SubSystemType.YOUTUBE_SEARCH),
        AppItem("yt_music", "YT Music", "com.google.android.apps.youtube.music", AppCategory.SOCIAL, Icons.Default.MusicNote, "Acoustic frequency playback", SubSystemType.SOUND_RECORDER),
        AppItem("stan", "STAN", "com.stan.app", AppCategory.SOCIAL, Icons.Default.SportsEsports, "Community esports hub", SubSystemType.GAME_BOOSTER),
        AppItem("snapseed", "Snapseed", "com.niksoftware.snapseed", AppCategory.SOCIAL, Icons.Default.PhotoLibrary, "Optical filter enhancements", SubSystemType.CAMERA_SCANNER),
        AppItem("vidmate", "VidMate", "com.nemo.vidmate", AppCategory.SOCIAL, Icons.Default.PlayArrow, "Media streaming link capture", SubSystemType.YOUTUBE_SEARCH),
        
        AppItem("chrome", "Chrome", "com.android.chrome", AppCategory.AI_TOOLS, Icons.Default.Language, "Quantum web gateway", SubSystemType.GENERIC_LAUNCHER),
        AppItem("chatgpt", "ChatGPT", "com.openai.chatgpt", AppCategory.AI_TOOLS, Icons.Default.Psychology, "Sub-system neural intelligence", SubSystemType.AI_TERMINAL),
        AppItem("claude", "Claude", "com.anthropic.claude", AppCategory.AI_TOOLS, Icons.Default.Psychology, "Claude Code neural brain link", SubSystemType.AI_TERMINAL),
        AppItem("assistant", "Assistant", "com.google.android.apps.googleassistant", AppCategory.AI_TOOLS, Icons.Default.Assistant, "Auxiliary tactical assistant", SubSystemType.AI_TERMINAL),
        AppItem("cortex", "CoRTEX Pa...", "com.cortex.app", AppCategory.AI_TOOLS, Icons.Default.Psychology, "Cortex cognitive processor", SubSystemType.AI_TERMINAL),
        AppItem("nexora", "NEXORA", "com.nexora.app", AppCategory.AI_TOOLS, Icons.Default.Speed, "Nexora automation protocols", SubSystemType.AI_TERMINAL),
        AppItem("bixberry", "BixBerry", "com.bixberry.app", AppCategory.AI_TOOLS, Icons.Default.Tune, "Bixberry smart automation", SubSystemType.AI_TERMINAL),
        
        AppItem("calculator", "Calculator", "com.google.android.calculator", AppCategory.SYSTEM, Icons.Default.Calculate, "Quantum mathematical calculator", SubSystemType.CALCULATOR),
        AppItem("calendar", "Calendar", "com.google.android.calendar", AppCategory.SYSTEM, Icons.Default.CalendarMonth, "Mission timeline scheduling", SubSystemType.GENERIC_LAUNCHER),
        AppItem("camera", "Camera", "com.google.android.GoogleCamera", AppCategory.SYSTEM, Icons.Default.CameraAlt, "Optical reconnaissance scanner", SubSystemType.CAMERA_SCANNER),
        AppItem("clock", "Clock", "com.google.android.deskclock", AppCategory.SYSTEM, Icons.Default.Schedule, "Chronometer and timer matrix", SubSystemType.GENERIC_LAUNCHER),
        AppItem("notes", "Notes", "com.google.android.keep", AppCategory.SYSTEM, Icons.Default.Notes, "Tactical directive memo pad", SubSystemType.NOTES_PAD),
        AppItem("drive", "Drive", "com.google.android.apps.docs", AppCategory.SYSTEM, Icons.Default.Storage, "Cloud blueprint archive", SubSystemType.GENERIC_LAUNCHER),
        AppItem("file_manager", "File Manager", "com.sec.android.app.myfiles", AppCategory.SYSTEM, Icons.Default.Folder, "Local storage diagnostic", SubSystemType.GENERIC_LAUNCHER),
        AppItem("files", "Files (Google)", "com.google.android.apps.nfiles", AppCategory.SYSTEM, Icons.Default.Folder, "Storage clean & telemetry", SubSystemType.GENERIC_LAUNCHER),
        AppItem("photos", "Photos", "com.google.android.apps.photos", AppCategory.SYSTEM, Icons.Default.PhotoLibrary, "Hologram photo database", SubSystemType.GENERIC_LAUNCHER),
        AppItem("ai_gallery", "AI Gallery", "com.transsion.aigallery", AppCategory.SYSTEM, Icons.Default.PhotoLibrary, "Neural visual library", SubSystemType.GENERIC_LAUNCHER),
        AppItem("sound_recorder", "Sound Recorder", "com.android.soundrecorder", AppCategory.SYSTEM, Icons.Default.Mic, "Acoustic audio telemetry recorder", SubSystemType.SOUND_RECORDER),
        
        AppItem("ampere", "Ampere", "com.gombosdev.ampere", AppCategory.SYSTEM, Icons.Default.BatteryChargingFull, "Real-time battery current analyzer", SubSystemType.BATTERY_AMPERE),
        AppItem("settings", "Settings", "com.android.settings", AppCategory.SYSTEM, Icons.Default.Settings, "Core Android configuration", SubSystemType.GENERIC_LAUNCHER),
        AppItem("face_unlock", "Face Unlock", "com.android.facelock", AppCategory.SYSTEM, Icons.Default.Security, "Biometric security scanner", SubSystemType.GENERIC_LAUNCHER),
        AppItem("phone_master", "Phone Master", "com.transsion.phonemaster", AppCategory.SYSTEM, Icons.Default.Speed, "RAM purge & thermal cool down", SubSystemType.BATTERY_AMPERE),
        AppItem("phone_cloner", "Phone Cloner", "com.cloner.app", AppCategory.SYSTEM, Icons.Default.Storage, "Data migration relay", SubSystemType.GENERIC_LAUNCHER),
        AppItem("authenticator", "Authenticator", "com.google.android.apps.authenticator2", AppCategory.SYSTEM, Icons.Default.Security, "2FA Stark security token", SubSystemType.GENERIC_LAUNCHER),
        AppItem("sim_toolkit", "SIM Toolkit", "com.android.stk", AppCategory.SYSTEM, Icons.Default.Security, "Cellular SIM protocol utility", SubSystemType.GENERIC_LAUNCHER),
        AppItem("hi_theme", "Hi Theme", "com.transsion.theme", AppCategory.SYSTEM, Icons.Default.Tune, "Hologram theme customization", SubSystemType.GENERIC_LAUNCHER),
        
        AppItem("maps", "Maps", "com.google.android.apps.maps", AppCategory.SYSTEM, Icons.Default.Map, "Satellite GPS trajectory locator", SubSystemType.MAPS_NAV),
        AppItem("location_checker", "Location Checker", "com.location.checker", AppCategory.SYSTEM, Icons.Default.LocationOn, "Geo-spatial coordinate verify", SubSystemType.MAPS_NAV),
        AppItem("gmail", "Gmail", "com.google.android.gm", AppCategory.COMMUNICATION, Icons.AutoMirrored.Filled.Message, "Stark mission transmission inbox", SubSystemType.GENERIC_LAUNCHER),
        AppItem("google", "Google", "com.google.android.googlequicksearchbox", AppCategory.AI_TOOLS, Icons.Default.Language, "Omni-search satellite query", SubSystemType.GENERIC_LAUNCHER),
        AppItem("play_store", "Play Store", "com.android.vending", AppCategory.SYSTEM, Icons.Default.ShoppingBag, "Module and app installer", SubSystemType.GENERIC_LAUNCHER),
        AppItem("gpay", "GPay", "com.google.android.apps.nbu.paisa.user", AppCategory.SYSTEM, Icons.Default.Payment, "Financial quantum transaction", SubSystemType.GENERIC_LAUNCHER),
        AppItem("phonepe", "PhonePe", "com.phonepe.app", AppCategory.SYSTEM, Icons.Default.Payment, "UPI payment relay gateway", SubSystemType.GENERIC_LAUNCHER),
        AppItem("flipkart", "Flipkart", "com.flipkart.android", AppCategory.SYSTEM, Icons.Default.ShoppingCart, "Supply procurement terminal", SubSystemType.GENERIC_LAUNCHER),
        AppItem("vi_app", "Vi App", "com.mventus.selfcare.activity", AppCategory.SYSTEM, Icons.Default.Tune, "Cellular carrier balance & recharge", SubSystemType.GENERIC_LAUNCHER),
        AppItem("laxasfit", "Laxasfit", "com.laxasfit.app", AppCategory.SYSTEM, Icons.Default.Speed, "Biometric fitness tracker", SubSystemType.BATTERY_AMPERE),
        
        AppItem("free_fire", "Free Fire", "com.dts.freefireth", AppCategory.GAMING, Icons.Default.SportsEsports, "Combat simulation tactical training", SubSystemType.GAME_BOOSTER)
    )
}
