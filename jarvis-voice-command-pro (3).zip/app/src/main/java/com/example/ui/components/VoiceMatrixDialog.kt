package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.HoloTheme
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.StatusNormal
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun VoiceMatrixDialog(
    initialVoiceId: String,
    initialApiKey: String,
    isHindi: Boolean,
    theme: HoloTheme,
    onDismiss: () -> Unit,
    onSave: (voiceId: String, apiKey: String, isHindi: Boolean) -> Unit,
    onTestVoice: (voiceId: String, isHindi: Boolean) -> Unit
) {
    var voiceIdInput by remember { mutableStateOf(initialVoiceId) }
    var apiKeyInput by remember { mutableStateOf(initialApiKey) }
    var selectedHindi by remember { mutableStateOf(isHindi) }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(12.dp))
                .background(JarvisSurface)
                .border(1.5.dp, theme.primary, CutCornerShape(12.dp))
                .padding(16.dp)
                .testTag("voice_matrix_dialog")
        ) {
            Column {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = theme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "VOICE MATRIX CONFIGURATION",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = theme.primary,
                            letterSpacing = 1.sp
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Voice Identity Badge
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(CutCornerShape(6.dp))
                        .background(theme.primary.copy(alpha = 0.1f))
                        .border(0.8.dp, theme.primary.copy(alpha = 0.4f), CutCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "ACTIVE VOICE: GEORGE",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = theme.primary
                            )
                            Text(
                                text = "BRITISH NARRATOR",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                color = theme.secondary
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "ElevenLabs Voice ID: JBFqnCBsd6RMkjVDRZzb",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Language Selection Mode
                Column {
                    Text(
                        text = "VOICE LANGUAGE // भाषा",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = theme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(CutCornerShape(4.dp))
                                .background(
                                    if (selectedHindi) theme.primary.copy(alpha = 0.25f)
                                    else JarvisSurface
                                )
                                .border(
                                    1.dp,
                                    if (selectedHindi) theme.primary else theme.primary.copy(alpha = 0.3f),
                                    CutCornerShape(4.dp)
                                )
                                .clickable { selectedHindi = true }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "🇮🇳 HINDI (हिन्दी)",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (selectedHindi) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 10.sp,
                                color = if (selectedHindi) TextPrimary else TextSecondary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(CutCornerShape(4.dp))
                                .background(
                                    if (!selectedHindi) theme.secondary.copy(alpha = 0.25f)
                                    else JarvisSurface
                                )
                                .border(
                                    1.dp,
                                    if (!selectedHindi) theme.secondary else theme.secondary.copy(alpha = 0.3f),
                                    CutCornerShape(4.dp)
                                )
                                .clickable { selectedHindi = false }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "🇬🇧 ENGLISH (UK)",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (!selectedHindi) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 10.sp,
                                color = if (!selectedHindi) TextPrimary else TextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Voice ID Input Field
                OutlinedTextField(
                    value = voiceIdInput,
                    onValueChange = { voiceIdInput = it },
                    label = { Text("ElevenLabs Voice ID", fontSize = 10.sp, color = theme.primary) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = theme.primary,
                        unfocusedBorderColor = theme.primary.copy(alpha = 0.4f),
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = CutCornerShape(4.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Optional API Key Input Field
                OutlinedTextField(
                    value = apiKeyInput,
                    onValueChange = { apiKeyInput = it },
                    label = { Text("ElevenLabs API Key (Optional)", fontSize = 10.sp, color = theme.primary) },
                    placeholder = { Text("Optional for cloud neural voice", fontSize = 10.sp, color = TextMuted) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = theme.primary,
                        unfocusedBorderColor = theme.primary.copy(alpha = 0.4f),
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = CutCornerShape(4.dp)
                )

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (selectedHindi) {
                        "Hindi voice active: J.A.R.V.I.S. speaks and recognizes Hindi commands with polite Stark cadence."
                    } else {
                        "Without a cloud key, JARVIS uses the local British George acoustic model with tuned pitch and cadence automatically."
                    },
                    fontFamily = FontFamily.Monospace,
                    fontSize = 8.5.sp,
                    color = TextMuted,
                    lineHeight = 12.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Action buttons: Test Voice & Save
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            val testVoiceId = voiceIdInput.trim()
                            onTestVoice(if (testVoiceId.isNotBlank()) testVoiceId else "JBFqnCBsd6RMkjVDRZzb", selectedHindi)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = theme.secondary.copy(alpha = 0.2f)),
                        shape = CutCornerShape(4.dp),
                        modifier = Modifier.border(1.dp, theme.secondary, CutCornerShape(4.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = theme.secondary,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "PREVIEW",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = theme.secondary
                        )
                    }

                    Button(
                        onClick = {
                            onSave(voiceIdInput, apiKeyInput, selectedHindi)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
                        shape = CutCornerShape(4.dp),
                        modifier = Modifier.testTag("save_voice_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "APPLY VOICE",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = Color.Black
                        )
                    }
                }
            }
        }
    }
}
