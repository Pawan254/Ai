package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Stark Industries Holographic Palette
val JarvisBackground = Color(0xFF060913)
val JarvisSurface = Color(0xFF0B1224)
val JarvisSurfaceVariant = Color(0xFF111D38)

// Default Theme: Mark 85 Classic Hologram (Cyan & Gold)
val CyanPrimary = Color(0xFF00F0FF)
val CyanSecondary = Color(0xFF00A2FF)
val CyanGlow = Color(0x3300F0FF)
val GoldAccent = Color(0xFFFFD700)

// Theme: Mark 42 / Hotrod (Red & Gold)
val RedPrimary = Color(0xFFFF2A2A)
val RedSecondary = Color(0xFFFF7A00)
val RedGlow = Color(0x33FF2A2A)

// Theme: Mark 17 Heartbreaker (Emerald Neon)
val EmeraldPrimary = Color(0xFF00FF88)
val EmeraldSecondary = Color(0xFF00D4AA)
val EmeraldGlow = Color(0x3300FF88)

// Theme: Rescue Protocol (Violet)
val VioletPrimary = Color(0xFFB026FF)
val VioletSecondary = Color(0xFF7928CA)
val VioletGlow = Color(0x33B026FF)

// Theme: War Machine (Tactical Amber)
val AmberPrimary = Color(0xFFFF9900)
val AmberSecondary = Color(0xFFFF5500)
val AmberGlow = Color(0x33FF9900)

// System status colors
val StatusNormal = Color(0xFF00FF88)
val StatusWarning = Color(0xFFFFB700)
val StatusAlert = Color(0xFFFF3366)
val StatusListening = Color(0xFF00F0FF)
val StatusSpeaking = Color(0xFFFFD700)
val StatusThinking = Color(0xFFB026FF)

val TextPrimary = Color(0xFFE8F4FF)
val TextSecondary = Color(0xFF88A0C0)
val TextMuted = Color(0xFF4A6080)
