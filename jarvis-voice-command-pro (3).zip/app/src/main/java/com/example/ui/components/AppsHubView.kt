package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppCategory
import com.example.model.AppItem
import com.example.model.AppRegistry
import com.example.model.HoloTheme
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.StatusAlert
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AppsHubView(
    theme: HoloTheme,
    onSelectAppSubsystem: (AppItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(AppCategory.ALL) }

    val filteredApps = remember(searchQuery, selectedCategory) {
        AppRegistry.allApps.filter { app ->
            val matchesCategory = selectedCategory == AppCategory.ALL || app.category == selectedCategory
            val matchesSearch = searchQuery.isBlank() ||
                    app.name.contains(searchQuery, ignoreCase = true) ||
                    app.description.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    fun launchRealApp(app: AppItem) {
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(app.packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            Toast.makeText(context, "Opening ${app.name}...", Toast.LENGTH_SHORT).show()
        } else {
            try {
                val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${app.packageName}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(marketIntent)
            } catch (_: Exception) {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${app.packageName}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("apps_hub_panel")
    ) {
        // Hero Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(8.dp))
                .background(JarvisSurface)
                .border(0.8.dp, theme.primary.copy(alpha = 0.5f), CutCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Apps,
                            contentDescription = null,
                            tint = theme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "APP AUTOMATION MATRIX // 50+ APPS",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = theme.primary,
                            letterSpacing = 1.sp
                        )
                    }

                    Text(
                        text = "${filteredApps.size}/${AppRegistry.allApps.size} APPS",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = theme.secondary
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "Boliye ya tap karein: kisi bhi app ke andar ghus kar kaam karein ya directly phone me launch/close karein.",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 8.5.sp,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search WhatsApp, YouTube, Instagram, Phone...", fontSize = 10.sp, color = TextMuted) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = theme.primary, modifier = Modifier.size(16.dp)) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, null, tint = TextMuted, modifier = Modifier.size(14.dp))
                    }
                }
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = theme.primary,
                unfocusedBorderColor = theme.primary.copy(alpha = 0.35f),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            shape = CutCornerShape(4.dp)
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Category Filter Chips
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
            items(AppCategory.entries) { cat ->
                val isSel = cat == selectedCategory
                Box(
                    modifier = Modifier
                        .clip(CutCornerShape(3.dp))
                        .background(if (isSel) theme.primary.copy(alpha = 0.22f) else JarvisSurface)
                        .border(
                            0.8.dp,
                            if (isSel) theme.primary else theme.primary.copy(alpha = 0.25f),
                            CutCornerShape(3.dp)
                        )
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = cat.title,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.sp,
                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSel) TextPrimary else TextMuted
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Apps List
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("apps_grid_list"),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredApps, key = { it.id }) { app ->
                AppCardItem(
                    app = app,
                    theme = theme,
                    onOpenSubsystem = { onSelectAppSubsystem(app) },
                    onDirectLaunch = { launchRealApp(app) }
                )
            }
        }
    }
}

@Composable
private fun AppCardItem(
    app: AppItem,
    theme: HoloTheme,
    onOpenSubsystem: () -> Unit,
    onDirectLaunch: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(CutCornerShape(6.dp))
            .background(JarvisSurface)
            .border(0.7.dp, theme.primary.copy(alpha = 0.35f), CutCornerShape(6.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Icon
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CutCornerShape(6.dp))
                .background(theme.primary.copy(alpha = 0.12f))
                .border(0.8.dp, theme.primary.copy(alpha = 0.4f), CutCornerShape(6.dp))
                .clickable(onClick = onOpenSubsystem),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = app.iconVector,
                contentDescription = null,
                tint = theme.primary,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        // Info
        Column(
            modifier = Modifier
                .weight(1f)
                .clickable(onClick = onOpenSubsystem)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = app.name,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.5.sp,
                    color = TextPrimary
                )
                Text(
                    text = app.category.name,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 7.5.sp,
                    color = theme.secondary
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = app.description,
                fontFamily = FontFamily.Monospace,
                fontSize = 8.5.sp,
                color = TextSecondary,
                maxLines = 1
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // 2 Action Buttons: [GHUS KAR KAAM KARO] & [LAUNCH]
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            // Interactive In-App Subsystem ("Ghus ke kaam karne wala")
            Button(
                onClick = onOpenSubsystem,
                colors = ButtonDefaults.buttonColors(containerColor = theme.secondary.copy(alpha = 0.18f)),
                shape = CutCornerShape(3.dp),
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                modifier = Modifier
                    .border(0.8.dp, theme.secondary, CutCornerShape(3.dp))
                    .height(30.dp)
            ) {
                Icon(Icons.Default.Build, null, tint = theme.secondary, modifier = Modifier.size(11.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text("OPEN IN-APP", fontSize = 8.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = theme.secondary)
            }

            // Real External Launch Button
            Button(
                onClick = onDirectLaunch,
                colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
                shape = CutCornerShape(3.dp),
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Icon(Icons.Default.OpenInNew, null, tint = Color.Black, modifier = Modifier.size(11.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text("LAUNCH", fontSize = 8.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.Black)
            }
        }
    }
}
