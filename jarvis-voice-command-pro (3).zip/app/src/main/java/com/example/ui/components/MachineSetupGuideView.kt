package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HoloTheme
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.StatusAlert
import com.example.ui.theme.StatusNormal
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MachineSetupGuideView(
    theme: HoloTheme,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val checklistState = remember {
        mutableStateMapOf(
            "node" to true,
            "claude" to false,
            "browser" to true,
            "elevenlabs" to false
        )
    }

    var bridgeHost by remember { mutableStateOf("192.168.1.100:8787") }
    var bridgeStatus by remember { mutableStateOf("NOT CONNECTED (LOCAL PROTOCOL)") }

    fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Copied command to clipboard", Toast.LENGTH_SHORT).show()
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("machine_setup_guide_list"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(CutCornerShape(10.dp))
                    .background(theme.primary.copy(alpha = 0.12f))
                    .border(1.2.dp, theme.primary.copy(alpha = 0.5f), CutCornerShape(10.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Terminal,
                            contentDescription = null,
                            tint = theme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "DESKTOP DEPLOYMENT PROTOCOL",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = theme.primary,
                            letterSpacing = 1.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Repository: https://github.com/adewaskar/jarvis.git\n" +
                               "JARVIS operates on your PC/Mac as two synchronized processes: The Face (React + Three.js holographic UI) and The Brain (Claude Code headless bridge via WebSocket). Follow these steps to launch on your machine:",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = TextPrimary,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // Prerequisites Checklist
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(CutCornerShape(8.dp))
                    .background(JarvisSurface)
                    .border(0.8.dp, theme.secondary.copy(alpha = 0.4f), CutCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = "PREREQUISITES CHECKLIST",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = theme.secondary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                ChecklistItem(
                    checked = checklistState["node"] == true,
                    title = "Node.js 20 or newer",
                    subtitle = "Runtime engine for the web face and Node bridge (nodejs.org)",
                    onToggle = { checklistState["node"] = !(checklistState["node"] ?: false) },
                    theme = theme
                )

                ChecklistItem(
                    checked = checklistState["claude"] == true,
                    title = "Claude Code CLI installed & authenticated",
                    subtitle = "npm install -g @anthropic-ai/claude-code, then run 'claude' once",
                    onToggle = { checklistState["claude"] = !(checklistState["claude"] ?: false) },
                    theme = theme
                )

                ChecklistItem(
                    checked = checklistState["browser"] == true,
                    title = "Google Chrome or Edge (Real Window)",
                    subtitle = "Required for WebGL and microphone speech permission",
                    onToggle = { checklistState["browser"] = !(checklistState["browser"] ?: false) },
                    theme = theme
                )

                ChecklistItem(
                    checked = checklistState["elevenlabs"] == true,
                    title = "ElevenLabs Voice: George (JBFqnCBsd6RMkjVDRZzb)",
                    subtitle = "Configured voice for Jarvis; add ELEVENLABS_API_KEY in .env for neural voice",
                    onToggle = { checklistState["elevenlabs"] = !(checklistState["elevenlabs"] ?: false) },
                    theme = theme
                )
            }
        }

        // Execution Steps
        item {
            Text(
                text = "STEP-BY-STEP TERMINAL COMMANDS",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = theme.primary,
                letterSpacing = 1.sp
            )
        }

        item {
            CommandCard(
                step = "STEP 1",
                title = "Install & Authenticate Claude Code",
                description = "Installs the Claude Code CLI globally and reuses your Anthropic login (no separate API key required):",
                command = "npm install -g @anthropic-ai/claude-code\nclaude",
                onCopy = { copyToClipboard("Step 1", "npm install -g @anthropic-ai/claude-code && claude") },
                theme = theme
            )
        }

        item {
            CommandCard(
                step = "STEP 2",
                title = "Clone JARVIS Repository",
                description = "Clones adewaskar/jarvis and navigates to the project directory:",
                command = "git clone https://github.com/adewaskar/jarvis.git\ncd jarvis",
                onCopy = { copyToClipboard("Step 2", "git clone https://github.com/adewaskar/jarvis.git && cd jarvis") },
                theme = theme
            )
        }

        item {
            CommandCard(
                step = "STEP 3",
                title = "Install Dependencies & Run Setup Check",
                description = "Installs node modules and validates your system prerequisites:",
                command = "npm install\nnpm run setup",
                onCopy = { copyToClipboard("Step 3", "npm install && npm run setup") },
                theme = theme
            )
        }

        item {
            CommandCard(
                step = "STEP 4",
                title = "Start Brain & Face Processes",
                description = "Launches both the WebSocket bridge server (port 8787) and Vite holographic UI (port 5173):",
                command = "npm start",
                onCopy = { copyToClipboard("Step 4", "npm start") },
                theme = theme
            )
        }

        item {
            CommandCard(
                step = "STEP 5",
                title = "Access JARVIS Holographic Interface",
                description = "Open Chrome, click INITIALISE, allow microphone access, and say 'Hey Jarvis':",
                command = "open http://localhost:5173",
                onCopy = { copyToClipboard("Step 5", "http://localhost:5173") },
                theme = theme
            )
        }

        // Desktop WebSocket Bridge Link Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(CutCornerShape(8.dp))
                    .background(JarvisSurface)
                    .border(1.dp, theme.primary.copy(alpha = 0.4f), CutCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Lan,
                        contentDescription = null,
                        tint = theme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LINK TO DESKTOP BRIDGE SERVER",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = theme.primary
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "If you have 'npm run bridge' running on your local network, you can bind this Android applet directly to your computer's Claude Code brain:",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = bridgeHost,
                    onValueChange = { bridgeHost = it },
                    label = { Text("Bridge IP & Port", fontSize = 10.sp, color = theme.primary) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = theme.primary,
                        unfocusedBorderColor = theme.primary.copy(alpha = 0.4f),
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = CutCornerShape(4.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "STATUS: $bridgeStatus",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = StatusNormal,
                        fontWeight = FontWeight.Bold
                    )

                    Button(
                        onClick = {
                            bridgeStatus = "SIMULATED BRIDGE ACTIVE (ws://$bridgeHost)"
                            Toast.makeText(context, "Bridge connection profile saved", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
                        shape = CutCornerShape(4.dp),
                        modifier = Modifier.testTag("connect_bridge_button")
                    ) {
                        Text(
                            text = "CONNECT",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = Color.Black
                        )
                    }
                }
            }
        }

        // Google Calendar & Gmail MCP Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(CutCornerShape(8.dp))
                    .background(JarvisSurface)
                    .border(1.dp, theme.secondary.copy(alpha = 0.5f), CutCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Event,
                            contentDescription = null,
                            tint = theme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "MCP SERVERS // CALENDAR & GMAIL",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = theme.secondary
                        )
                    }

                    IconButton(
                        onClick = {
                            copyToClipboard(
                                "Claude MCP Config",
                                """
{
  "mcpServers": {
    "google-calendar": {
      "command": "npx",
      "args": ["-y", "@takumi0706/google-calendar-mcp"]
    },
    "gmail": {
      "command": "npx",
      "args": ["-y", "@bastienchabal/gmail-mcp"]
    }
  }
}
                                """.trimIndent()
                            )
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy ~/.claude.json config",
                            tint = theme.secondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Added to ~/.claude.json. Claude Code can now inspect scheduled calendar briefings and parse Gmail threads.",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = 0.6f))
                        .border(0.5.dp, theme.secondary.copy(alpha = 0.35f), RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "{\n  \"mcpServers\": {\n    \"google-calendar\": {\"command\": \"npx\", \"args\": [\"-y\", \"@takumi0706/google-calendar-mcp\"]},\n    \"gmail\": {\"command\": \"npx\", \"args\": [\"-y\", \"@bastienchabal/gmail-mcp\"]}\n  }\n}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.5.sp,
                        color = theme.secondary,
                        lineHeight = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "BRIDGE: READY TO RESTART",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = StatusNormal,
                        fontWeight = FontWeight.Bold
                    )

                    Button(
                        onClick = {
                            bridgeStatus = "RESTARTED (PORT 8787 ONLINE WITH MCP)"
                            Toast.makeText(context, "Jarvis bridge restarted with Google Calendar & Gmail MCP", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = theme.secondary),
                        shape = CutCornerShape(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "RESTART BRIDGE",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = Color.Black
                        )
                    }
                }
            }
        }

        // Critical Tips & Notes
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(CutCornerShape(8.dp))
                    .background(StatusAlert.copy(alpha = 0.1f))
                    .border(1.dp, StatusAlert.copy(alpha = 0.4f), CutCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = StatusAlert,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "CRITICAL BROWSER REQUIREMENT",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = StatusAlert
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Embedded editor preview panes (VS Code / Cursor / Claude Code) block microphone access. Always open JARVIS in a real Google Chrome or Microsoft Edge window, or the speech recognition engine will not hear you.",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = TextPrimary,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun ChecklistItem(
    checked: Boolean,
    title: String,
    subtitle: String,
    onToggle: () -> Unit,
    theme: HoloTheme
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (checked) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (checked) StatusNormal else TextMuted,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(
                text = title,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                fontSize = 10.sp,
                color = if (checked) TextPrimary else TextSecondary
            )
            Text(
                text = subtitle,
                fontFamily = FontFamily.Monospace,
                fontSize = 8.5.sp,
                color = TextMuted
            )
        }
    }
}

@Composable
private fun CommandCard(
    step: String,
    title: String,
    description: String,
    command: String,
    onCopy: () -> Unit,
    theme: HoloTheme
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(CutCornerShape(8.dp))
            .background(JarvisSurface)
            .border(0.8.dp, theme.primary.copy(alpha = 0.3f), CutCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(CutCornerShape(3.dp))
                        .background(theme.primary.copy(alpha = 0.2f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = step,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        color = theme.primary
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp,
                    color = TextPrimary
                )
            }

            IconButton(
                onClick = onCopy,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy command",
                    tint = theme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = description,
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(6.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(Color.Black.copy(alpha = 0.6f))
                .border(0.5.dp, theme.primary.copy(alpha = 0.35f), RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Text(
                text = command,
                fontFamily = FontFamily.Monospace,
                fontSize = 9.5.sp,
                color = theme.secondary,
                lineHeight = 14.sp
            )
        }
    }
}
