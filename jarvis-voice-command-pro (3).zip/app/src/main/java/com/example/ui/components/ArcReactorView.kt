package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.AssistantState
import com.example.model.HoloTheme
import com.example.model.ReactorStyle
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

@Composable
fun ArcReactorView(
    state: AssistantState,
    theme: HoloTheme,
    style: ReactorStyle,
    isOverdrive: Boolean,
    onReactorClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "reactor_anim")

    // Dynamic rotation speeds based on permanent voice state
    val spinDuration = when {
        isOverdrive -> 2200
        state == AssistantState.LISTENING -> 4000
        state == AssistantState.SPEAKING -> 6000
        else -> 9000
    }

    val rotationClockwise by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(spinDuration, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin_cw"
    )

    val rotationCounterClockwise by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween((spinDuration * 1.5).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin_ccw"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = if (isOverdrive) 1.25f else 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isOverdrive) 400 else 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val waveAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_alpha"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .padding(16.dp)
            .testTag("arc_reactor_container"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .testTag("arc_reactor_canvas")
        ) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = min(size.width, size.height) * 0.44f

            // 1. Ambient outer glow aura
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        theme.primary.copy(alpha = if (isOverdrive) 0.35f else 0.18f),
                        theme.glow,
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.15f * pulseScale
                ),
                radius = baseRadius * 1.15f * pulseScale,
                center = center
            )

            // 2. Radiating energy rings for permanent listening / speaking
            drawCircle(
                color = theme.primary.copy(alpha = waveAlpha * 0.45f),
                radius = baseRadius * (0.8f + (1f - waveAlpha) * 0.35f),
                center = center,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )

            // 3. Render according to geometry style
            when (style) {
                ReactorStyle.RING -> drawRingGeometry(center, baseRadius, rotationClockwise, rotationCounterClockwise, theme)
                ReactorStyle.SPHERE -> drawSphereGeometry(center, baseRadius, rotationClockwise, theme)
                ReactorStyle.WIREFRAME -> drawWireframeGeometry(center, baseRadius, rotationClockwise, theme)
            }

            // 4. Central Glowing Core
            drawCentralCore(center, baseRadius * 0.32f * pulseScale, theme)
        }
    }
}

private fun DrawScope.drawRingGeometry(
    center: Offset,
    radius: Float,
    rotCw: Float,
    rotCcw: Float,
    theme: HoloTheme
) {
    drawCircle(
        color = theme.primary.copy(alpha = 0.25f),
        radius = radius,
        center = center,
        style = Stroke(width = 2.dp.toPx())
    )

    rotate(rotCw * 0.3f, pivot = center) {
        val triPath = Path()
        val triRadius = radius * 0.98f
        for (i in 0..2) {
            val angle = (i * 120.0 - 90.0) * (PI / 180.0)
            val x = center.x + (triRadius * cos(angle)).toFloat()
            val y = center.y + (triRadius * sin(angle)).toFloat()
            if (i == 0) triPath.moveTo(x, y) else triPath.lineTo(x, y)
        }
        triPath.close()
        drawPath(
            path = triPath,
            color = theme.secondary.copy(alpha = 0.45f),
            style = Stroke(width = 2.5.dp.toPx())
        )
    }

    rotate(rotCw, pivot = center) {
        val bladeRadius = radius * 0.82f
        val segments = 12
        val sweepAngle = 20f
        for (i in 0 until segments) {
            val startAngle = i * (360f / segments)
            drawArc(
                color = if (i % 2 == 0) theme.primary else theme.secondary,
                startAngle = startAngle,
                sweepAngle = sweepAngle,
                useCenter = false,
                topLeft = Offset(center.x - bladeRadius, center.y - bladeRadius),
                size = Size(bladeRadius * 2, bladeRadius * 2),
                style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Butt)
            )
        }
    }

    rotate(rotCcw, pivot = center) {
        val innerRingRadius = radius * 0.62f
        drawCircle(
            color = theme.primary.copy(alpha = 0.65f),
            radius = innerRingRadius,
            center = center,
            style = Stroke(width = 3.dp.toPx())
        )
        val numTicks = 24
        for (i in 0 until numTicks) {
            val angleRad = (i * (360.0 / numTicks)) * (PI / 180.0)
            val innerPoint = Offset(
                center.x + ((innerRingRadius - 8.dp.toPx()) * cos(angleRad)).toFloat(),
                center.y + ((innerRingRadius - 8.dp.toPx()) * sin(angleRad)).toFloat()
            )
            val outerPoint = Offset(
                center.x + ((innerRingRadius + 4.dp.toPx()) * cos(angleRad)).toFloat(),
                center.y + ((innerRingRadius + 4.dp.toPx()) * sin(angleRad)).toFloat()
            )
            drawLine(
                color = if (i % 4 == 0) theme.secondary else theme.primary.copy(alpha = 0.4f),
                start = innerPoint,
                end = outerPoint,
                strokeWidth = if (i % 4 == 0) 2.5.dp.toPx() else 1.5.dp.toPx()
            )
        }
    }
}

private fun DrawScope.drawSphereGeometry(
    center: Offset,
    radius: Float,
    rotCw: Float,
    theme: HoloTheme
) {
    rotate(rotCw * 0.5f, pivot = center) {
        val tilts = listOf(0.25f, 0.55f, 0.85f, 1f)
        tilts.forEach { factor ->
            drawOval(
                color = theme.primary.copy(alpha = 0.35f),
                topLeft = Offset(center.x - radius, center.y - radius * factor),
                size = Size(radius * 2, radius * 2 * factor),
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
    rotate(-rotCw * 0.7f, pivot = center) {
        val tilts = listOf(0.35f, 0.7f)
        tilts.forEach { factor ->
            drawOval(
                color = theme.secondary.copy(alpha = 0.5f),
                topLeft = Offset(center.x - radius * factor, center.y - radius),
                size = Size(radius * 2 * factor, radius * 2),
                style = Stroke(width = 2.5.dp.toPx())
            )
        }
    }
}

private fun DrawScope.drawWireframeGeometry(
    center: Offset,
    radius: Float,
    rotCw: Float,
    theme: HoloTheme
) {
    rotate(rotCw * 0.4f, pivot = center) {
        val hexPath = Path()
        val numSides = 6
        for (i in 0 until numSides) {
            val angle = (i * (360.0 / numSides)) * (PI / 180.0)
            val x = center.x + (radius * 0.9f * cos(angle)).toFloat()
            val y = center.y + (radius * 0.9f * sin(angle)).toFloat()
            if (i == 0) hexPath.moveTo(x, y) else hexPath.lineTo(x, y)
        }
        hexPath.close()
        drawPath(path = hexPath, color = theme.primary.copy(alpha = 0.5f), style = Stroke(width = 2.5.dp.toPx()))

        for (i in 0 until numSides) {
            val angle = (i * (360.0 / numSides)) * (PI / 180.0)
            val px = center.x + (radius * 0.9f * cos(angle)).toFloat()
            val py = center.y + (radius * 0.9f * sin(angle)).toFloat()
            drawLine(
                color = theme.secondary.copy(alpha = 0.35f),
                start = center,
                end = Offset(px, py),
                strokeWidth = 1.5.dp.toPx()
            )
        }
    }
}

private fun DrawScope.drawCentralCore(
    center: Offset,
    coreRadius: Float,
    theme: HoloTheme
) {
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                Color.White,
                theme.primary,
                theme.secondary,
                Color.Transparent
            ),
            center = center,
            radius = coreRadius * 1.3f
        ),
        radius = coreRadius * 1.3f,
        center = center
    )

    drawCircle(
        color = Color.White.copy(alpha = 0.9f),
        radius = coreRadius * 0.55f,
        center = center,
        style = Stroke(width = 3.dp.toPx())
    )

    drawCircle(
        color = Color.White,
        radius = coreRadius * 0.28f,
        center = center
    )
}
