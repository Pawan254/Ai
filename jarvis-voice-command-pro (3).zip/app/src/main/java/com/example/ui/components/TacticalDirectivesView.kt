package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.memory.ConversationHistoryEntry
import com.example.memory.MemoryEntry
import com.example.model.DirectivePriority
import com.example.model.HoloTheme
import com.example.model.TacticalDirective
import com.example.tasks.JarvisTask
import com.example.tasks.TaskExecutionStatus
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.StatusAlert
import com.example.ui.theme.StatusListening
import com.example.ui.theme.StatusNormal
import com.example.ui.theme.StatusSpeaking
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Combined Voice-Driven Hub for:
 * 1) Parallel Task Queue & Multi-Task Execution Tracking
 * 2) Permanent Long-Term Memory Bank (Name, Preferences, Habits, Past Conversations)
 * 3) Voice-Logged Tactical Directives (Zero manual typing)
 */
@Composable
fun TacticalDirectivesView(
    directives: List<TacticalDirective>,
    theme: HoloTheme,
    onAddDirective: (String, String, DirectivePriority) -> Unit,
    onToggleComplete: (String) -> Unit,
    onDeleteDirective: (String) -> Unit,
    memories: List<MemoryEntry> = emptyList(),
    historyEntries: List<ConversationHistoryEntry> = emptyList(),
    tasks: List<JarvisTask> = emptyList(),
    onDeleteMemory: (String) -> Unit = {},
    onClearCompletedTasks: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var activeSubTab by remember { mutableIntStateOf(0) } // 0: Parallel Tasks, 1: Permanent Memory, 2: Directives & History

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("directives_panel")
    ) {
        // Sub-Tab Selector Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SubSectionTab(
                title = "PARALLEL TASKS (${tasks.size})",
                icon = Icons.Default.Speed,
                isSelected = activeSubTab == 0,
                theme = theme,
                onClick = { activeSubTab = 0 },
                modifier = Modifier.weight(1f)
            )
            SubSectionTab(
                title = "MEMORY (${memories.size})",
                icon = Icons.Default.Memory,
                isSelected = activeSubTab == 1,
                theme = theme,
                onClick = { activeSubTab = 1 },
                modifier = Modifier.weight(1f)
            )
            SubSectionTab(
                title = "DIRECTIVES (${directives.size})",
                icon = Icons.Default.Security,
                isSelected = activeSubTab == 2,
                theme = theme,
                onClick = { activeSubTab = 2 },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (activeSubTab) {
            0 -> ParallelTasksSection(
                tasks = tasks,
                theme = theme,
                onClearCompleted = onClearCompletedTasks,
                modifier = Modifier.weight(1f)
            )
            1 -> PermanentMemorySection(
                memories = memories,
                historyEntries = historyEntries,
                theme = theme,
                onDeleteMemory = onDeleteMemory,
                modifier = Modifier.weight(1f)
            )
            2 -> DirectivesListSection(
                directives = directives,
                theme = theme,
                onToggleComplete = onToggleComplete,
                onDeleteDirective = onDeleteDirective,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun SubSectionTab(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    theme: HoloTheme,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(CutCornerShape(5.dp))
            .background(if (isSelected) theme.primary.copy(alpha = 0.22f) else JarvisSurface)
            .border(
                1.dp,
                if (isSelected) theme.primary else theme.primary.copy(alpha = 0.28f),
                CutCornerShape(5.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) theme.primary else TextMuted,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = title,
                fontFamily = FontFamily.Monospace,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                fontSize = 8.5.sp,
                color = if (isSelected) TextPrimary else TextMuted
            )
        }
    }
}

@Composable
private fun ParallelTasksSection(
    tasks: List<JarvisTask>,
    theme: HoloTheme,
    onClearCompleted: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(8.dp))
                .background(JarvisSurface)
                .border(0.8.dp, theme.primary.copy(alpha = 0.4f), CutCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "MULTI-TASK PARALLEL EXECUTION QUEUE",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.5.sp,
                        color = theme.primary
                    )
                    Text(
                        text = "Speak multiple commands (e.g., 'YouTube kholo aur Rahul ko call lagao') — Jarvis executes them concurrently with automatic error recovery.",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.5.sp,
                        color = TextSecondary,
                        lineHeight = 12.sp
                    )
                }
                if (tasks.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .clip(CutCornerShape(4.dp))
                            .background(theme.secondary.copy(alpha = 0.18f))
                            .border(0.8.dp, theme.secondary, CutCornerShape(4.dp))
                            .clickable(onClick = onClearCompleted)
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "PURGE DONE",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = theme.secondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (tasks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(CutCornerShape(8.dp))
                    .background(JarvisSurface.copy(alpha = 0.5f))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = theme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "PARALLEL TASK DISPATCHER IDLE",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = theme.primary
                    )
                    Text(
                        text = "Say 'Jarvis, YouTube kholo' followed by 'Ab Rahul ko call lagao' to see parallel task execution.",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = TextSecondary
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("tasks_queue_list"),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tasks, key = { it.id }) { task ->
                    val statusColor = when (task.status) {
                        TaskExecutionStatus.RUNNING -> StatusListening
                        TaskExecutionStatus.COMPLETED -> StatusNormal
                        TaskExecutionStatus.CANCELLED -> TextMuted
                        TaskExecutionStatus.RECOVERING -> StatusSpeaking
                        TaskExecutionStatus.FAILED -> StatusAlert
                        TaskExecutionStatus.QUEUED -> theme.secondary
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(CutCornerShape(6.dp))
                            .background(JarvisSurface)
                            .border(0.8.dp, statusColor.copy(alpha = 0.5f), CutCornerShape(6.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = task.title.uppercase(),
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.5.sp,
                                    color = TextPrimary
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(CutCornerShape(3.dp))
                                        .background(statusColor.copy(alpha = 0.18f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${task.status.label} • ${task.priority.name}",
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 7.5.sp,
                                        color = statusColor
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "Voice Command: \"${task.commandText}\"",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.5.sp,
                                color = theme.secondary
                            )
                            Text(
                                text = "Status: ${task.statusDetail}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.5.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermanentMemorySection(
    memories: List<MemoryEntry>,
    historyEntries: List<ConversationHistoryEntry>,
    theme: HoloTheme,
    onDeleteMemory: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(8.dp))
                .background(JarvisSurface)
                .border(0.8.dp, theme.secondary.copy(alpha = 0.5f), CutCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = theme.secondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "PERMANENT LONG-TERM MEMORY (ROOM SQLITE)",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.5.sp,
                        color = theme.secondary
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "Jarvis automatically remembers your name, likes, habits, and instructions across app restarts. Speak: 'Jarvis, mera naam [Name] hai' or 'Jarvis, yaad rakhna ki...'",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 8.5.sp,
                    color = TextSecondary,
                    lineHeight = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("permanent_memory_list"),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(memories, key = { it.key }) { mem ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(CutCornerShape(6.dp))
                        .background(JarvisSurface)
                        .border(0.8.dp, theme.primary.copy(alpha = 0.4f), CutCornerShape(6.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = mem.label.uppercase(),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = theme.primary
                            )
                            Text(
                                text = mem.category,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 7.5.sp,
                                color = theme.secondary
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = mem.value,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.5.sp,
                            color = TextPrimary
                        )
                    }
                    IconButton(
                        onClick = { onDeleteMemory(mem.key) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Memory",
                            tint = TextMuted,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }

            if (historyEntries.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            tint = theme.primary,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "REMEMBERED PAST CONVERSATIONS & ACTIONS",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.5.sp,
                            color = theme.primary
                        )
                    }
                }
                items(historyEntries.take(10), key = { it.id }) { hist ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(CutCornerShape(5.dp))
                            .background(Color.Black.copy(alpha = 0.45f))
                            .border(0.6.dp, theme.primary.copy(alpha = 0.25f), CutCornerShape(5.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "You Spoke: \"${hist.userSpoken}\"",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 8.5.sp,
                            color = theme.secondary
                        )
                        Text(
                            text = "Jarvis: \"${hist.jarvisSpoken}\"",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.5.sp,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DirectivesListSection(
    directives: List<TacticalDirective>,
    theme: HoloTheme,
    onToggleComplete: (String) -> Unit,
    onDeleteDirective: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(8.dp))
                .background(JarvisSurface)
                .border(0.8.dp, theme.primary.copy(alpha = 0.4f), CutCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Text(
                text = "VOICE-LOGGED TACTICAL DIRECTIVES // Say 'Jarvis, yaad dilao...' or 'New directive...' to log hands-free.",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = TextSecondary
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("directives_list"),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(directives, key = { it.id }) { dir ->
                DirectiveCard(
                    directive = dir,
                    theme = theme,
                    onToggle = { onToggleComplete(dir.id) },
                    onDelete = { onDeleteDirective(dir.id) }
                )
            }
        }
    }
}

@Composable
private fun DirectiveCard(
    directive: TacticalDirective,
    theme: HoloTheme,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    val dateStr = remember(directive.timestamp) {
        val sdf = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
        sdf.format(Date(directive.timestamp))
    }

    val priorityColor = when (directive.priority) {
        DirectivePriority.CRITICAL -> StatusAlert
        DirectivePriority.HIGH -> theme.secondary
        DirectivePriority.NORMAL -> theme.primary
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(CutCornerShape(6.dp))
            .background(JarvisSurface)
            .border(
                0.8.dp,
                if (directive.isCompleted) TextMuted.copy(alpha = 0.3f) else priorityColor.copy(alpha = 0.45f),
                CutCornerShape(6.dp)
            )
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onToggle,
            modifier = Modifier.size(32.dp)
        ) {
            Icon(
                imageVector = if (directive.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                contentDescription = "Toggle completion",
                tint = if (directive.isCompleted) StatusNormal else priorityColor,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(6.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = directive.title,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = if (directive.isCompleted) TextMuted else TextPrimary,
                    textDecoration = if (directive.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                )
                Box(
                    modifier = Modifier
                        .clip(CutCornerShape(2.dp))
                        .background(priorityColor.copy(alpha = 0.15f))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = directive.priority.name,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 7.5.sp,
                        color = priorityColor,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = directive.detail,
                fontFamily = FontFamily.Monospace,
                fontSize = 9.5.sp,
                color = if (directive.isCompleted) TextMuted else TextSecondary,
                lineHeight = 13.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = dateStr,
                fontFamily = FontFamily.Monospace,
                fontSize = 8.sp,
                color = TextMuted
            )
        }

        IconButton(
            onClick = onDelete,
            modifier = Modifier.size(32.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = "Delete directive",
                tint = TextMuted,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
