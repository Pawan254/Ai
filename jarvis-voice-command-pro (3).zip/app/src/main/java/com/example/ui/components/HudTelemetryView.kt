package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AssistantState
import com.example.model.HoloTheme
import com.example.model.ReactorStyle
import com.example.model.TelemetryData
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.StatusAlert
import com.example.ui.theme.StatusListening
import com.example.ui.theme.StatusNormal
import com.example.ui.theme.StatusSpeaking
import com.example.ui.theme.StatusThinking
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HudHeader(
    theme: HoloTheme,
    state: AssistantState,
    isOverdrive: Boolean,
    telemetry: TelemetryData,
    voiceId: String = "JBFqnCBsd6RMk/VDRZzb",
    modifier: Modifier = Modifier
) {
    val statusColor = when {
        isOverdrive -> StatusAlert
        state == AssistantState.LISTENING -> StatusListening
        state == AssistantState.THINKING -> StatusThinking
        state == AssistantState.SPEAKING -> StatusSpeaking
        else -> StatusNormal
    }

    val statusColorAnimated by animateColorAsState(targetValue = statusColor, label = "status_color")

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("hud_header")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(theme.primary)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "STARK IND. // DEFENSE SYS",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = theme.primary,
                        letterSpacing = 1.5.sp
                    )
                }
                Text(
                    text = "${theme.title} • ${theme.codename.uppercase()} • VOICE: GEORGE ($voiceId)",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = TextSecondary
                )
            }

            // Status Badge
            Box(
                modifier = Modifier
                    .clip(CutCornerShape(topStart = 6.dp, bottomEnd = 6.dp))
                    .background(statusColorAnimated.copy(alpha = 0.15f))
                    .border(1.dp, statusColorAnimated, CutCornerShape(topStart = 6.dp, bottomEnd = 6.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                    .testTag("status_badge")
            ) {
                Text(
                    text = if (isOverdrive) "OVERDRIVE" else state.label,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = statusColorAnimated,
                    letterSpacing = 1.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Audio Frequency Waveform Visualizer
        AudioWaveVisualizer(
            state = state,
            theme = theme,
            isOverdrive = isOverdrive
        )
    }
}

@Composable
fun AudioWaveVisualizer(
    state: AssistantState,
    theme: HoloTheme,
    isOverdrive: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave_anim")
    val waveStep by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isOverdrive) 250 else 700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave_step"
    )

    val barCount = 28
    val isActive = state == AssistantState.SPEAKING || state == AssistantState.LISTENING || isOverdrive

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(26.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(JarvisSurface.copy(alpha = 0.5f))
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .testTag("audio_wave_visualizer"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until barCount) {
            val centerDist = kotlin.math.abs(i - barCount / 2f) / (barCount / 2f)
            val bellFactor = 1f - (centerDist * 0.7f)
            val dynamicFactor = if (isActive) {
                val seed = ((i * 7 + (waveStep * 20).toInt()) % 10) / 10f
                (0.2f + seed * 0.8f) * bellFactor
            } else {
                0.15f * bellFactor
            }

            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height((20.dp * dynamicFactor.coerceIn(0.15f, 1f)))
                    .clip(RoundedCornerShape(1.dp))
                    .background(
                        if (isActive) {
                            if (i % 3 == 0) theme.secondary else theme.primary
                        } else {
                            theme.primary.copy(alpha = 0.3f)
                        }
                    )
            )
        }
    }
}

@Composable
fun HudTelemetryBar(
    telemetry: TelemetryData,
    theme: HoloTheme,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        TelemetryCell(
            icon = if (telemetry.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
            label = "POWER CELL",
            value = "${telemetry.batteryPct}%",
            color = theme.primary
        )
        TelemetryCell(
            icon = Icons.Default.Bolt,
            label = "ARC OUTPUT",
            value = "${telemetry.coreOutputMw} GW",
            color = theme.secondary
        )
        TelemetryCell(
            icon = Icons.Default.Speed,
            label = "TURBINE",
            value = "${telemetry.rpm} RPM",
            color = theme.primary
        )
        TelemetryCell(
            icon = Icons.Default.ViewInAr,
            label = "QUANTUM FLUX",
            value = "${telemetry.coreTempC}°C",
            color = theme.secondary
        )
    }
}

@Composable
private fun TelemetryCell(
    icon: ImageVector,
    label: String,
    value: String,
    color: Color
) {
    Column(
        modifier = Modifier
            .clip(CutCornerShape(4.dp))
            .background(JarvisSurface.copy(alpha = 0.8f))
            .border(0.5.dp, color.copy(alpha = 0.4f), CutCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(11.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = label,
                fontFamily = FontFamily.Monospace,
                fontSize = 8.sp,
                color = TextMuted,
                letterSpacing = 0.5.sp
            )
        }
        Text(
            text = value,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = TextPrimary
        )
    }
}

@Composable
fun QuickActionsBar(
    theme: HoloTheme,
    style: ReactorStyle,
    isOverdrive: Boolean,
    onCycleTheme: () -> Unit,
    onCycleStyle: () -> Unit,
    onToggleOverdrive: () -> Unit,
    onRunDiagnostics: () -> Unit,
    onOpenVoiceSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        ActionChip(
            icon = Icons.Default.Palette,
            label = theme.codename,
            color = theme.primary,
            tag = "action_theme_chip",
            onClick = onCycleTheme
        )
        ActionChip(
            icon = Icons.Default.ViewInAr,
            label = style.label.split(" ").first(),
            color = theme.secondary,
            tag = "action_style_chip",
            onClick = onCycleStyle
        )
        ActionChip(
            icon = Icons.Default.Bolt,
            label = if (isOverdrive) "OVERDRIVE ON" else "STANDBY",
            color = if (isOverdrive) StatusAlert else theme.primary,
            tag = "action_overdrive_chip",
            onClick = onToggleOverdrive
        )
        ActionChip(
            icon = Icons.Default.RecordVoiceOver,
            label = "VOICE",
            color = theme.primary,
            tag = "action_voice_chip",
            onClick = onOpenVoiceSettings
        )
    }
}

@Composable
private fun ActionChip(
    icon: ImageVector,
    label: String,
    color: Color,
    tag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(CutCornerShape(4.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.5f), CutCornerShape(4.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 7.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(13.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            fontSize = 9.sp,
            color = color,
            letterSpacing = 0.5.sp
        )
    }
}
