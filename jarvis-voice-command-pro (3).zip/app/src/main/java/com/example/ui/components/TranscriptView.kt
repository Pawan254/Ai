package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AssistantState
import com.example.model.ChatMessage
import com.example.model.HoloTheme
import com.example.tasks.JarvisTask
import com.example.tasks.TaskExecutionStatus
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.StatusAlert
import com.example.ui.theme.StatusListening
import com.example.ui.theme.StatusNormal
import com.example.ui.theme.StatusSpeaking
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.voice.WakeListeningPhase
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Compact Voice Assistant Status Interface (ZERO Chat / ZERO Typing / ZERO Manual ON-OFF Button).
 * Controlled exclusively by two voice commands:
 * - SYSTEM ON: "Hey Jarvis" -> "जी, बताइए।"
 * - SYSTEM OFF: "Jarvis System Off" -> Standby Wake Word Mode
 */
@Composable
fun TranscriptView(
    messages: List<ChatMessage>,
    theme: HoloTheme,
    state: AssistantState,
    listState: LazyListState,
    onSimulateVoicePhrase: (String) -> Unit,
    partialSpeechText: String = "",
    wakePhase: WakeListeningPhase = WakeListeningPhase.AWAITING_COMMAND,
    activeTasks: List<JarvisTask> = emptyList(),
    userName: String = "Sir",
    modifier: Modifier = Modifier
) {
    // All 15 Master Test Commands available for instant verification in emulator or voice
    val spokenPhrasesForTesting = listOf(
        "Hey Jarvis",
        "Jarvis, ek funny joke sunao",
        "Aaj mera mood off hai",
        "Tum bahut drama karti ho",
        "Jarvis, YouTube par Bhojpuri gana search karo",
        "Ye gana chalao",
        "Isko band karo",
        "Kuchh aur search karo",
        "Boss, Amit ko message bhejo ki main kal aaunga",
        "Haan",
        "WhatsApp par Rahul ko dhundo",
        "Instagram kholo",
        "Instagram par kisne like kiya",
        "Google Maps kholo",
        "Camera chalao",
        "मेरा नाम क्या है?",
        "Jarvis System Off"
    )

    val latestJarvisSpoken = remember(messages.size) {
        messages.lastOrNull { it.sender == "JARVIS" }
    }
    val latestUserSpoken = remember(messages.size) {
        messages.lastOrNull { it.sender == "USER" }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val isSystemActive = wakePhase != WakeListeningPhase.STANDBY_WAKE_WORD

    val statusAccent by animateColorAsState(
        targetValue = when {
            !isSystemActive -> StatusAlert
            state == AssistantState.SPEAKING -> StatusSpeaking
            wakePhase == WakeListeningPhase.AWAITING_COMMAND -> StatusNormal
            else -> StatusListening
        },
        label = "wake_status_color"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
            .background(JarvisSurface.copy(alpha = 0.96f))
            .border(
                1.2.dp,
                theme.primary.copy(alpha = 0.35f),
                RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
            )
            .padding(12.dp)
            .testTag("transcript_panel"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // 1. Header: Single Voice Control System Status (Non-clickable, no manual ON/OFF toggle)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = null,
                    tint = statusAccent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "VOICE OPERATING STATUS // NO CHAT",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = theme.primary,
                    letterSpacing = 1.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(
                modifier = Modifier
                    .clip(CutCornerShape(4.dp))
                    .background(statusAccent.copy(alpha = 0.15f))
                    .border(0.8.dp, statusAccent, CutCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .testTag("permanent_listening_badge"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.VerifiedUser,
                    contentDescription = "System Voice State",
                    tint = statusAccent,
                    modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isSystemActive) "SYSTEM ON (ACTIVE)" else "SYSTEM OFF (WAKE STANDBY)",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 8.sp,
                    color = statusAccent
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 2. Live Spoken Recognition & Jarvis Voice Response Monitor
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(CutCornerShape(8.dp))
                .background(Color.Black.copy(alpha = 0.55f))
                .border(0.8.dp, theme.primary.copy(alpha = 0.3f), CutCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (partialSpeechText.isNotBlank()) {
                            "HEARING ($userName): \"$partialSpeechText\""
                        } else if (!isSystemActive) {
                            "STANDBY MODE: Say \"Hey Jarvis\" to turn System ON"
                        } else if (latestUserSpoken != null) {
                            "YOU SPOKE: \"${latestUserSpoken.text}\""
                        } else {
                            "ACTIVE MODE: Speak naturally or say \"Jarvis System Off\""
                        },
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isSystemActive) StatusNormal else StatusAlert,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    latestJarvisSpoken?.actionBadge?.let { badge ->
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(CutCornerShape(3.dp))
                                .background(theme.secondary.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = badge,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 7.5.sp,
                                color = theme.secondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("messages_list"),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(messages.takeLast(6), key = { it.id }) { msg ->
                        VoiceLogRow(message = msg, theme = theme)
                    }
                }

                // Parallel Running Tasks Ticker
                if (activeTasks.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(CutCornerShape(4.dp))
                            .background(theme.primary.copy(alpha = 0.1f))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Memory,
                                contentDescription = null,
                                tint = theme.primary,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "PARALLEL TASK: ${activeTasks.first().title}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = theme.primary,
                                maxLines = 1
                            )
                        }
                        Text(
                            text = "${activeTasks.count { it.status == TaskExecutionStatus.RUNNING || it.status == TaskExecutionStatus.COMPLETED }} EXECUTED",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.sp,
                            color = StatusNormal
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 3. Voice Phrase Verification Row (All 15 Master Commands)
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("suggestion_chips_row"),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp)
        ) {
            items(spokenPhrasesForTesting) { phrase ->
                Box(
                    modifier = Modifier
                        .clip(CutCornerShape(4.dp))
                        .background(theme.primary.copy(alpha = 0.08f))
                        .border(0.8.dp, theme.primary.copy(alpha = 0.35f), CutCornerShape(4.dp))
                        .clickable { onSimulateVoicePhrase(phrase) }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "🗣 \"$phrase\"",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.5.sp,
                        color = theme.primary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 4. Passive Single Voice Control Banner (NO Manual ON/OFF Button)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(10.dp))
                .background(statusAccent.copy(alpha = 0.14f))
                .border(1.2.dp, statusAccent.copy(alpha = 0.7f), CutCornerShape(10.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .testTag("wake_word_status_banner"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CutCornerShape(6.dp))
                        .background(statusAccent.copy(alpha = 0.25f))
                        .border(1.dp, statusAccent, CutCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.RadioButtonChecked,
                        contentDescription = "Voice Status Indicator",
                        tint = statusAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = when (wakePhase) {
                            WakeListeningPhase.AWAITING_COMMAND -> "SYSTEM ON: \"जी, बताइए।\" (Say 'Jarvis System Off' to standby)"
                            WakeListeningPhase.EXECUTING -> "EXECUTING & LISTENING IN PARALLEL..."
                            WakeListeningPhase.STANDBY_WAKE_WORD -> "SYSTEM OFF (STANDBY): Say \"Hey Jarvis\" to activate"
                        },
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = "ON: \"Hey Jarvis\" • OFF: \"Jarvis System Off\" • Silent Mic (No Beep/Echo)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 7.8.sp,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun VoiceLogRow(
    message: ChatMessage,
    theme: HoloTheme
) {
    val isJarvis = message.sender == "JARVIS"
    val timeStr = remember(message.timestamp) {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        sdf.format(Date(message.timestamp))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(CutCornerShape(4.dp))
            .background(
                if (isJarvis) theme.primary.copy(alpha = 0.08f)
                else theme.secondary.copy(alpha = 0.08f)
            )
            .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = if (isJarvis) "JARVIS 🔊" else "VOICE 🎙",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 8.5.sp,
            color = if (isJarvis) theme.primary else theme.secondary,
            modifier = Modifier.width(62.dp)
        )
        Text(
            text = message.text,
            fontFamily = FontFamily.Monospace,
            fontSize = 9.5.sp,
            color = TextPrimary,
            lineHeight = 13.sp,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = timeStr,
            fontFamily = FontFamily.Monospace,
            fontSize = 7.5.sp,
            color = TextMuted
        )
    }
}
