package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppItem
import com.example.model.HoloTheme
import com.example.model.SubSystemType
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.StatusAlert
import com.example.ui.theme.StatusNormal
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AppSubsystemSheet(
    app: AppItem,
    theme: HoloTheme,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    fun launchRealApp() {
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(app.packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            Toast.makeText(context, "Opening ${app.name}...", Toast.LENGTH_SHORT).show()
        } else {
            // Fallback: Open Google Play Store page
            try {
                val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${app.packageName}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(marketIntent)
            } catch (_: Exception) {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${app.packageName}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.88f))
            .padding(14.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(12.dp))
                .background(JarvisSurface)
                .border(1.5.dp, theme.primary, CutCornerShape(12.dp))
                .padding(16.dp)
                .testTag("app_subsystem_container")
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CutCornerShape(6.dp))
                            .background(theme.primary.copy(alpha = 0.15f))
                            .border(1.dp, theme.primary, CutCornerShape(6.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = app.iconVector,
                            contentDescription = null,
                            tint = theme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = app.name.uppercase(),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = theme.primary,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "STARK PROTOCOL // ${app.category.title}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 8.5.sp,
                            color = TextSecondary
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Launch External Real App Button
                    IconButton(
                        onClick = { launchRealApp() },
                        modifier = Modifier.size(32.dp).testTag("launch_external_app_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.OpenInNew,
                            contentDescription = "Open App",
                            tint = theme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Close Subsystem Button ("App close karne ka option")
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(32.dp).testTag("close_subsystem_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = StatusAlert,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Subsystem Workspace Body ("Ghus ke kaam karne wala")
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false)
            ) {
                when (app.subSystemType) {
                    SubSystemType.WHATSAPP_COMPOSER -> WhatsAppComposer(app, theme, context)
                    SubSystemType.PHONE_DIALER -> PhoneDialerWorkspace(app, theme, context)
                    SubSystemType.CALCULATOR -> QuantumCalculatorWorkspace(theme)
                    SubSystemType.YOUTUBE_SEARCH -> YouTubeSearchWorkspace(app, theme, context)
                    SubSystemType.AI_TERMINAL -> AiTerminalWorkspace(app, theme)
                    SubSystemType.CAMERA_SCANNER -> CameraScannerWorkspace(theme, context)
                    SubSystemType.BATTERY_AMPERE -> BatteryAmpereWorkspace(theme, context)
                    SubSystemType.GAME_BOOSTER -> GameBoosterWorkspace(app, theme, ::launchRealApp)
                    SubSystemType.MAPS_NAV -> MapsNavWorkspace(theme, context)
                    SubSystemType.NOTES_PAD -> NotesPadWorkspace(theme, context)
                    SubSystemType.SOUND_RECORDER -> SoundRecorderWorkspace(theme, context)
                    SubSystemType.GENERIC_LAUNCHER -> GenericAppWorkspace(app, theme, ::launchRealApp)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Bottom Command Footer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = StatusAlert.copy(alpha = 0.2f)),
                    shape = CutCornerShape(4.dp),
                    modifier = Modifier.border(1.dp, StatusAlert, CutCornerShape(4.dp))
                ) {
                    Text(
                        text = "CLOSE / EXIT APP",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = StatusAlert
                    )
                }

                Button(
                    onClick = { launchRealApp() },
                    colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
                    shape = CutCornerShape(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "LAUNCH ${app.name.uppercase()}",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = Color.Black
                    )
                }
            }
        }
    }
}

// 1. WhatsApp / Messenger In-App Workspace
@Composable
private fun WhatsAppComposer(app: AppItem, theme: HoloTheme, context: Context) {
    var phoneInput by remember { mutableStateOf("") }
    var msgInput by remember { mutableStateOf("") }
    var statusText by remember { mutableStateOf("READY TO DISPATCH") }

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "DIRECT COMMUNICATION PROTOCOL",
            fontFamily = FontFamily.Monospace,
            fontSize = 9.5.sp,
            color = theme.secondary,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
            value = phoneInput,
            onValueChange = { phoneInput = it },
            label = { Text("Recipient Phone / Target ID", fontSize = 10.sp, color = theme.primary) },
            placeholder = { Text("+91 9876543210", fontSize = 10.sp, color = TextMuted) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = theme.primary,
                unfocusedBorderColor = theme.primary.copy(alpha = 0.4f),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            shape = CutCornerShape(4.dp)
        )

        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
            value = msgInput,
            onValueChange = { msgInput = it },
            label = { Text("Message / Tactical Transmission", fontSize = 10.sp, color = theme.primary) },
            placeholder = { Text("Type directive to transmit...", fontSize = 10.sp, color = TextMuted) },
            modifier = Modifier.fillMaxWidth().height(80.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = theme.primary,
                unfocusedBorderColor = theme.primary.copy(alpha = 0.4f),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            shape = CutCornerShape(4.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "STATUS: $statusText",
                fontFamily = FontFamily.Monospace,
                fontSize = 8.5.sp,
                color = StatusNormal
            )

            Button(
                onClick = {
                    if (msgInput.isNotBlank()) {
                        val cleanPhone = phoneInput.replace("[^0-9+]".toRegex(), "")
                        val uri = if (cleanPhone.isNotBlank()) {
                            Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encode(msgInput)}")
                        } else {
                            Uri.parse("https://api.whatsapp.com/send?text=${Uri.encode(msgInput)}")
                        }
                        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        try {
                            context.startActivity(intent)
                            statusText = "DISPATCHED TO WHATSAPP"
                        } catch (_: Exception) {
                            statusText = "TRANSMITTED (SIMULATED)"
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
                shape = CutCornerShape(4.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, null, tint = Color.Black, modifier = Modifier.size(13.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("SEND DIRECTIVE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            }
        }
    }
}

// 2. Phone Dialer Workspace
@Composable
private fun PhoneDialerWorkspace(app: AppItem, theme: HoloTheme, context: Context) {
    var dialNumber by remember { mutableStateOf("") }

    val digits = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("*", "0", "#")
    )

    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(4.dp))
                .background(Color.Black.copy(alpha = 0.6f))
                .border(0.8.dp, theme.primary.copy(alpha = 0.5f), CutCornerShape(4.dp))
                .padding(vertical = 8.dp, horizontal = 12.dp)
        ) {
            Text(
                text = if (dialNumber.isEmpty()) "ENTER FREQUENCY / NUMBER" else dialNumber,
                fontFamily = FontFamily.Monospace,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = if (dialNumber.isEmpty()) TextMuted else theme.primary
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Keypad grid
        digits.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                row.forEach { digit ->
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CutCornerShape(4.dp))
                            .background(JarvisSurface)
                            .border(0.6.dp, theme.primary.copy(alpha = 0.35f), CutCornerShape(4.dp))
                            .clickable { dialNumber += digit },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = digit,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TextPrimary
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(
                onClick = { if (dialNumber.isNotEmpty()) dialNumber = dialNumber.dropLast(1) },
                colors = ButtonDefaults.buttonColors(containerColor = TextMuted.copy(alpha = 0.3f)),
                shape = CutCornerShape(4.dp)
            ) {
                Text("DEL", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }

            Button(
                onClick = {
                    if (dialNumber.isNotBlank()) {
                        val callIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(dialNumber)}")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(callIntent)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = StatusNormal),
                shape = CutCornerShape(4.dp)
            ) {
                Icon(Icons.Default.Call, null, tint = Color.Black, modifier = Modifier.size(13.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("CALL SATELLITE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            }
        }
    }
}

// 3. Quantum Calculator Workspace
@Composable
private fun QuantumCalculatorWorkspace(theme: HoloTheme) {
    var display by remember { mutableStateOf("0") }
    var expression by remember { mutableStateOf("") }

    val buttons = listOf(
        listOf("C", "DEL", "%", "/"),
        listOf("7", "8", "9", "*"),
        listOf("4", "5", "6", "-"),
        listOf("1", "2", "3", "+"),
        listOf("0", ".", "=", "^")
    )

    fun onButtonClick(btn: String) {
        when (btn) {
            "C" -> {
                display = "0"
                expression = ""
            }
            "DEL" -> {
                if (display.length > 1) display = display.dropLast(1) else display = "0"
            }
            "=" -> {
                try {
                    val full = expression + display
                    val res = evaluateSimpleMath(full)
                    display = res
                    expression = ""
                } catch (_: Exception) {
                    display = "ERROR"
                }
            }
            "+", "-", "*", "/", "%", "^" -> {
                expression = "$display $btn "
                display = "0"
            }
            else -> {
                display = if (display == "0") btn else display + btn
            }
        }
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(4.dp))
                .background(Color.Black.copy(alpha = 0.7f))
                .border(0.8.dp, theme.primary.copy(alpha = 0.5f), CutCornerShape(4.dp))
                .padding(10.dp)
        ) {
            Column(horizontalAlignment = Alignment.End, modifier = Modifier.fillMaxWidth()) {
                Text(text = expression, fontSize = 10.sp, color = TextMuted, fontFamily = FontFamily.Monospace)
                Text(text = display, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = theme.primary, fontFamily = FontFamily.Monospace)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        buttons.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                row.forEach { b ->
                    val isOp = b in listOf("+", "-", "*", "/", "=", "^", "%", "C", "DEL")
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CutCornerShape(4.dp))
                            .background(if (isOp) theme.primary.copy(alpha = 0.18f) else JarvisSurface)
                            .border(0.6.dp, if (isOp) theme.secondary else theme.primary.copy(alpha = 0.3f), CutCornerShape(4.dp))
                            .clickable { onButtonClick(b) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = b,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (isOp) theme.secondary else TextPrimary
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
        }
    }
}

private fun evaluateSimpleMath(expr: String): String {
    val tokens = expr.trim().split(" ")
    if (tokens.size >= 3) {
        val a = tokens[0].toDoubleOrNull() ?: 0.0
        val op = tokens[1]
        val b = tokens[2].toDoubleOrNull() ?: 0.0
        val result = when (op) {
            "+" -> a + b
            "-" -> a - b
            "*" -> a * b
            "/" -> if (b != 0.0) a / b else Double.NaN
            "%" -> a % b
            "^" -> Math.pow(a, b)
            else -> a
        }
        return if (result % 1.0 == 0.0) result.toInt().toString() else "%.3f".format(result)
    }
    return tokens.firstOrNull() ?: "0"
}

// 4. YouTube Search Workspace
@Composable
private fun YouTubeSearchWorkspace(app: AppItem, theme: HoloTheme, context: Context) {
    var query by remember { mutableStateOf("") }
    val quickTopics = listOf("Iron Man Arc Reactor", "Mark 85 Armor", "JARVIS Voice AI", "Free Fire Best Gameplay", "Stark Tech")

    Column(modifier = Modifier.fillMaxWidth()) {
        Text("VISUAL RECONNAISSANCE // YOUTUBE FEED", fontSize = 9.sp, color = theme.primary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search YouTube Archives", fontSize = 10.sp, color = theme.primary) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = theme.primary,
                unfocusedBorderColor = theme.primary.copy(alpha = 0.4f),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            shape = CutCornerShape(4.dp)
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            quickTopics.take(3).forEach { topic ->
                Box(
                    modifier = Modifier
                        .clip(CutCornerShape(3.dp))
                        .background(theme.secondary.copy(alpha = 0.15f))
                        .border(0.6.dp, theme.secondary, CutCornerShape(3.dp))
                        .clickable { query = topic }
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(topic, fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = theme.secondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                val searchUrl = "https://www.youtube.com/results?search_query=${Uri.encode(if (query.isNotBlank()) query else "JARVIS Iron Man")}"
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(searchUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            },
            colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
            shape = CutCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Search, null, tint = Color.Black, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("STREAM TRANSMISSION ON YOUTUBE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        }
    }
}

// 5. AI Terminal Workspace (ChatGPT / Claude / Cortex / Assistant)
@Composable
private fun AiTerminalWorkspace(app: AppItem, theme: HoloTheme) {
    var prompt by remember { mutableStateOf("") }
    var response by remember { mutableStateOf("Sub-system neural core initialized. Standing by for query...") }

    Column(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
                .clip(CutCornerShape(4.dp))
                .background(Color.Black.copy(alpha = 0.7f))
                .border(0.8.dp, theme.primary.copy(alpha = 0.4f), CutCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Text(response, fontFamily = FontFamily.Monospace, fontSize = 9.5.sp, color = TextPrimary, lineHeight = 13.sp)
        }

        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
            value = prompt,
            onValueChange = { prompt = it },
            label = { Text("Prompt ${app.name} Agent", fontSize = 9.sp, color = theme.primary) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = theme.primary,
                unfocusedBorderColor = theme.primary.copy(alpha = 0.4f),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            shape = CutCornerShape(4.dp)
        )

        Spacer(modifier = Modifier.height(6.dp))

        Button(
            onClick = {
                if (prompt.isNotBlank()) {
                    response = "Processed by ${app.name} Core: Analysis of '$prompt' complete. Parameters confirmed nominal for Stark tactical matrix, Sir."
                    prompt = ""
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = theme.secondary),
            shape = CutCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("QUERY NEURAL AGENT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        }
    }
}

// 6. Camera Scanner Workspace
@Composable
private fun CameraScannerWorkspace(theme: HoloTheme, context: Context) {
    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .clip(CutCornerShape(6.dp))
                .background(Color.Black.copy(alpha = 0.8f))
                .border(1.dp, theme.primary, CutCornerShape(6.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.CameraAlt, null, tint = theme.primary, modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.height(4.dp))
                Text("OPTICAL RETICLE ACTIVE", fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = theme.primary)
                Text("SCAN RESOLUTION: 4K ULTRA TELEMETRY", fontFamily = FontFamily.Monospace, fontSize = 7.5.sp, color = TextMuted)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(cameraIntent)
                } catch (_: Exception) {
                    Toast.makeText(context, "Camera launched in optical mode", Toast.LENGTH_SHORT).show()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
            shape = CutCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("OPEN OPTICAL SCANNER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        }
    }
}

// 7. Battery Ampere Workspace
@Composable
private fun BatteryAmpereWorkspace(theme: HoloTheme, context: Context) {
    var isOptimized by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            AmpereCell("CURRENT DRAW", if (isOptimized) "180 mA" else "420 mA", theme.primary)
            AmpereCell("VOLTAGE", "4.18 V", theme.secondary)
            AmpereCell("TEMP", if (isOptimized) "31.2°C" else "36.5°C", StatusNormal)
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                isOptimized = true
                Toast.makeText(context, "RAM purged. Thermal throttling cleared.", Toast.LENGTH_SHORT).show()
            },
            colors = ButtonDefaults.buttonColors(containerColor = if (isOptimized) StatusNormal else theme.primary),
            shape = CutCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Speed, null, tint = Color.Black, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(if (isOptimized) "SYSTEM THERMALS OPTIMAL" else "PURGE RAM & BOOST FLUX", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        }
    }
}

@Composable
private fun AmpereCell(label: String, value: String, color: Color) {
    Column(
        modifier = Modifier
            .clip(CutCornerShape(4.dp))
            .background(Color.Black.copy(alpha = 0.6f))
            .border(0.6.dp, color.copy(alpha = 0.5f), CutCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, fontSize = 7.5.sp, fontFamily = FontFamily.Monospace, color = TextMuted)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = color)
    }
}

// 8. Game Booster (Free Fire / STAN)
@Composable
private fun GameBoosterWorkspace(app: AppItem, theme: HoloTheme, onLaunch: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(6.dp))
                .background(StatusAlert.copy(alpha = 0.12f))
                .border(1.dp, StatusAlert.copy(alpha = 0.5f), CutCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Column {
                Text("COMBAT TACTICAL BOOST MODE", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = StatusAlert)
                Text("CPU Core allocation: MAXIMUM (8 Cores)\nTouch Sampling Rate: 360Hz Override\nBackground telemetry: SILENCED", fontFamily = FontFamily.Monospace, fontSize = 8.5.sp, color = TextPrimary)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = onLaunch,
            colors = ButtonDefaults.buttonColors(containerColor = StatusAlert),
            shape = CutCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.FlashOn, null, tint = Color.White, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("BOOST & LAUNCH ${app.name.uppercase()}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

// 9. Maps Nav Workspace
@Composable
private fun MapsNavWorkspace(theme: HoloTheme, context: Context) {
    var locationQuery by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = locationQuery,
            onValueChange = { locationQuery = it },
            label = { Text("Destination / GPS Target", fontSize = 10.sp, color = theme.primary) },
            placeholder = { Text("Stark Tower, New York", fontSize = 10.sp, color = TextMuted) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = theme.primary,
                unfocusedBorderColor = theme.primary.copy(alpha = 0.4f),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            shape = CutCornerShape(4.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                val q = if (locationQuery.isNotBlank()) locationQuery else "Stark Tower"
                val mapIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(q)}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(mapIntent)
                } catch (_: Exception) {
                    val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=${Uri.encode(q)}")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(browserIntent)
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
            shape = CutCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("ENGAGE SATELLITE NAVIGATION", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        }
    }
}

// 10. Notes Pad Workspace
@Composable
private fun NotesPadWorkspace(theme: HoloTheme, context: Context) {
    var memoText by remember { mutableStateOf("Stark Protocol Directive #847:\nCheck arc reactor containment ring tolerances before orbital re-entry.") }

    Column(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = memoText,
            onValueChange = { memoText = it },
            modifier = Modifier.fillMaxWidth().height(100.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = theme.primary,
                unfocusedBorderColor = theme.primary.copy(alpha = 0.4f),
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            shape = CutCornerShape(4.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                Toast.makeText(context, "Memo logged to secure Stark archive", Toast.LENGTH_SHORT).show()
            },
            colors = ButtonDefaults.buttonColors(containerColor = theme.secondary),
            shape = CutCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("SAVE TACTICAL DIRECTIVE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        }
    }
}

// 11. Sound Recorder Workspace
@Composable
private fun SoundRecorderWorkspace(theme: HoloTheme, context: Context) {
    var isRecording by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(if (isRecording) "RECORDING ACOUSTIC TELEMETRY..." else "ACOUSTIC SENSOR STANDBY", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = if (isRecording) StatusAlert else theme.primary)
        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                isRecording = !isRecording
                Toast.makeText(context, if (isRecording) "Recording started" else "Recording saved to audio cache", Toast.LENGTH_SHORT).show()
            },
            colors = ButtonDefaults.buttonColors(containerColor = if (isRecording) StatusAlert else theme.primary),
            shape = CutCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isRecording) "STOP & SAVE AUDIO" else "CAPTURE AUDIO TELEMETRY", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = if (isRecording) Color.White else Color.Black)
        }
    }
}

// 12. Generic Launcher Workspace
@Composable
private fun GenericAppWorkspace(app: AppItem, theme: HoloTheme, onLaunch: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(app.description, fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextSecondary, lineHeight = 14.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text("Package: ${app.packageName}", fontFamily = FontFamily.Monospace, fontSize = 8.sp, color = TextMuted)
        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = onLaunch,
            colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
            shape = CutCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.OpenInNew, null, tint = Color.Black, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("OPEN ${app.name.uppercase()}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        }
    }
}
