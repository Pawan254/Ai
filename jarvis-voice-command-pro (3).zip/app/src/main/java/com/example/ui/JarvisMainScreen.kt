package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.audio.JarvisSoundManager
import com.example.brain.ContactMatch
import com.example.brain.YouTubeVideoItem
import com.example.model.ChatMessage
import com.example.model.DirectivePriority
import com.example.model.HoloTheme
import com.example.model.ReactorStyle
import com.example.model.TacticalDirective
import com.example.service.JarvisBackgroundService
import com.example.ui.components.AppSubsystemSheet
import com.example.ui.components.AppsHubView
import com.example.ui.components.ArcReactorView
import com.example.ui.components.HudHeader
import com.example.ui.components.HudTelemetryBar
import com.example.ui.components.MachineSetupGuideView
import com.example.ui.components.QuickActionsBar
import com.example.ui.components.TacticalDirectivesView
import com.example.ui.components.TranscriptView
import com.example.ui.components.VoiceMatrixDialog
import com.example.ui.theme.JarvisBackground
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.StatusAlert
import com.example.ui.theme.StatusNormal
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun JarvisMainScreen(
    onRequestAudioPermission: () -> Unit,
    hasAudioPermission: Boolean,
    hasContactsPermission: Boolean = false,
    hasCallPermission: Boolean = false,
    onRequestCallPermissions: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: HUD, 1: Apps Hub, 2: Tasks & Memory, 3: Setup Guide
    var showVoiceDialog by remember { mutableStateOf(false) }

    val soundManager = remember { JarvisSoundManager(context) }
    val brain = remember { JarvisBackgroundService.getOrCreateSharedBrain(context) }
    var telemetry by remember { mutableStateOf(brain.getLiveTelemetry()) }

    val assistantState by JarvisBackgroundService.assistantState.collectAsStateWithLifecycle()
    val wakePhase by JarvisBackgroundService.wakePhase.collectAsStateWithLifecycle()
    val partialSpeechText by JarvisBackgroundService.partialSpeech.collectAsStateWithLifecycle()
    val currentTheme by JarvisBackgroundService.currentTheme.collectAsStateWithLifecycle()
    val reactorStyle by JarvisBackgroundService.reactorStyle.collectAsStateWithLifecycle()
    val isOverdrive by JarvisBackgroundService.isOverdrive.collectAsStateWithLifecycle()
    val requestedTab by JarvisBackgroundService.requestedTab.collectAsStateWithLifecycle()
    val activeSubsystemApp by JarvisBackgroundService.activeSubsystemApp.collectAsStateWithLifecycle()
    val disambiguationMatches by JarvisBackgroundService.disambiguationMatches.collectAsStateWithLifecycle()
    val youtubeResults by JarvisBackgroundService.youtubeSearchResults.collectAsStateWithLifecycle()
    val messages by JarvisBackgroundService.messages.collectAsStateWithLifecycle()

    val memories by brain.memoryRepository.allMemories.collectAsStateWithLifecycle(initialValue = emptyList())
    val historyEntries by brain.memoryRepository.recentHistory.collectAsStateWithLifecycle(initialValue = emptyList())
    val activeTasks by brain.taskManager.tasks.collectAsStateWithLifecycle()

    val rememberedUserName = remember(memories) {
        memories.firstOrNull { it.key == "user_name" }?.value ?: "Pawan"
    }

    LaunchedEffect(requestedTab) {
        requestedTab?.let { tab ->
            selectedTab = tab
            JarvisBackgroundService.clearRequestedTab()
        }
    }

    BackHandler(enabled = activeSubsystemApp != null) {
        JarvisBackgroundService.setActiveSubsystemApp(null)
    }
    BackHandler(enabled = activeSubsystemApp == null && selectedTab != 0) {
        selectedTab = 0
    }

    val directives = remember {
        mutableStateListOf(
            TacticalDirective(
                title = "YouTube Voice Search & Playback",
                detail = "Say 'Jarvis, YouTube par Bhojpuri gana search karo' -> Select result by number or title.",
                priority = DirectivePriority.CRITICAL,
                isCompleted = true
            ),
            TacticalDirective(
                title = "WhatsApp & Instagram Automation",
                detail = "Say 'Boss, Amit ko message bhejo ki main kal aaunga' or 'Instagram par Rahul ko dhundo'.",
                priority = DirectivePriority.HIGH,
                isCompleted = true
            ),
            TacticalDirective(
                title = "Natural Female Voice // Boss Pawan",
                detail = "Pleasant female Hindi/Hinglish voice addressing Boss Pawan with confirmation security.",
                priority = DirectivePriority.NORMAL,
                isCompleted = true
            )
        )
    }

    val transcriptListState = rememberLazyListState()

    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            telemetry = brain.getLiveTelemetry()
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisBackground),
        containerColor = JarvisBackground,
        topBar = {
            Column {
                HudHeader(
                    theme = currentTheme,
                    state = assistantState,
                    isOverdrive = isOverdrive,
                    telemetry = telemetry,
                    voiceId = "FEMALE AI // BOSS ${rememberedUserName.uppercase()}"
                )
                HudTelemetryBar(
                    telemetry = telemetry,
                    theme = currentTheme
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    NavTabButton(
                        icon = Icons.Default.DeveloperBoard,
                        label = "VOICE HUD",
                        isSelected = selectedTab == 0,
                        theme = currentTheme,
                        onClick = { selectedTab = 0 }
                    )
                    NavTabButton(
                        icon = Icons.Default.Apps,
                        label = "APPS (50+)",
                        isSelected = selectedTab == 1,
                        theme = currentTheme,
                        onClick = { selectedTab = 1 }
                    )
                    NavTabButton(
                        icon = Icons.Default.Memory,
                        label = "TASKS & MEMORY (${memories.size})",
                        isSelected = selectedTab == 2,
                        theme = currentTheme,
                        onClick = { selectedTab = 2 }
                    )
                    NavTabButton(
                        icon = Icons.Default.Terminal,
                        label = "SETUP",
                        isSelected = selectedTab == 3,
                        theme = currentTheme,
                        onClick = { selectedTab = 3 }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        QuickActionsBar(
                            theme = currentTheme,
                            style = reactorStyle,
                            isOverdrive = isOverdrive,
                            onCycleTheme = {
                                val themes = HoloTheme.entries
                                val nextIdx = (themes.indexOf(currentTheme) + 1) % themes.size
                                JarvisBackgroundService.setTheme(themes[nextIdx])
                                soundManager.playAcknowledgeChirp()
                            },
                            onCycleStyle = {
                                val styles = ReactorStyle.entries
                                val nextIdx = (styles.indexOf(reactorStyle) + 1) % styles.size
                                JarvisBackgroundService.setReactorStyle(styles[nextIdx])
                                soundManager.playAcknowledgeChirp()
                            },
                            onToggleOverdrive = {
                                val nextOverdrive = !isOverdrive
                                JarvisBackgroundService.setOverdrive(nextOverdrive)
                                soundManager.playReactorOverdrive()
                            },
                            onRunDiagnostics = {
                                JarvisBackgroundService.dispatchVoiceCommand(context, "diagnostic check")
                            },
                            onOpenVoiceSettings = {
                                showVoiceDialog = true
                            }
                        )

                        if (!hasAudioPermission) {
                            OneTimePermissionCard(
                                theme = currentTheme,
                                onGrantPermissions = onRequestAudioPermission
                            )
                        }

                        // YouTube Voice Search Results Card ("Boss, inmein se kaunsa play karna hai?")
                        if (youtubeResults.isNotEmpty()) {
                            YouTubeVoiceResultsBanner(
                                results = youtubeResults,
                                theme = currentTheme,
                                onSelectVideo = { item ->
                                    JarvisBackgroundService.dispatchVoiceCommand(context, "पहला")
                                    brain.youTubeController.playVideoItem(item)
                                },
                                onDismiss = {
                                    JarvisBackgroundService.clearYouTubeResults()
                                    brain.youTubeController.clearSearchSession()
                                }
                            )
                        }

                        // Contact Disambiguation Banner
                        if (disambiguationMatches.isNotEmpty()) {
                            ContactDisambiguationBanner(
                                matches = disambiguationMatches,
                                theme = currentTheme,
                                onSelectContact = { contact ->
                                    JarvisBackgroundService.clearDisambiguation()
                                    brain.callSystem.clearPendingDisambiguation()
                                    brain.callSystem.placePhoneCall(contact.phoneNumber)
                                    val msg = "Calling ${contact.name} (${contact.phoneNumber}) now, Boss $rememberedUserName."
                                    JarvisBackgroundService.appendMessage(
                                        ChatMessage(sender = "JARVIS", text = msg, actionBadge = "CALLING")
                                    )
                                },
                                onDismiss = {
                                    JarvisBackgroundService.clearDisambiguation()
                                    brain.callSystem.clearPendingDisambiguation()
                                }
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1.0f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            ArcReactorView(
                                state = assistantState,
                                theme = currentTheme,
                                style = reactorStyle,
                                isOverdrive = isOverdrive
                            )
                        }

                        TranscriptView(
                            messages = messages,
                            theme = currentTheme,
                            state = assistantState,
                            listState = transcriptListState,
                            onSimulateVoicePhrase = { phrase ->
                                JarvisBackgroundService.dispatchVoiceCommand(context, phrase)
                            },
                            partialSpeechText = partialSpeechText,
                            wakePhase = wakePhase,
                            activeTasks = activeTasks,
                            userName = "Boss $rememberedUserName",
                            modifier = Modifier.weight(1.38f)
                        )
                    }
                }
                1 -> {
                    AppsHubView(
                        theme = currentTheme,
                        onSelectAppSubsystem = { app ->
                            JarvisBackgroundService.setActiveSubsystemApp(app)
                            soundManager.playAcknowledgeChirp()
                        }
                    )
                }
                2 -> {
                    TacticalDirectivesView(
                        directives = directives,
                        theme = currentTheme,
                        onAddDirective = { title, detail, priority ->
                            directives.add(
                                0,
                                TacticalDirective(
                                    title = title,
                                    detail = detail,
                                    priority = priority
                                )
                            )
                            soundManager.playAcknowledgeChirp()
                        },
                        onToggleComplete = { id ->
                            val idx = directives.indexOfFirst { it.id == id }
                            if (idx != -1) {
                                val current = directives[idx]
                                directives[idx] = current.copy(isCompleted = !current.isCompleted)
                                soundManager.playAcknowledgeChirp()
                            }
                        },
                        onDeleteDirective = { id ->
                            directives.removeAll { it.id == id }
                            soundManager.playAlert()
                        },
                        memories = memories,
                        historyEntries = historyEntries,
                        tasks = activeTasks,
                        onDeleteMemory = { key ->
                            scope.launch {
                                brain.memoryRepository.deleteMemory(key)
                            }
                        },
                        onClearCompletedTasks = {
                            brain.taskManager.clearCompletedTasks()
                        }
                    )
                }
                3 -> {
                    MachineSetupGuideView(
                        theme = currentTheme
                    )
                }
            }
        }

        activeSubsystemApp?.let { app ->
            AppSubsystemSheet(
                app = app,
                theme = currentTheme,
                onClose = {
                    JarvisBackgroundService.setActiveSubsystemApp(null)
                    soundManager.playAcknowledgeChirp()
                }
            )
        }

        if (showVoiceDialog) {
            val prefs = context.getSharedPreferences("jarvis_voice_prefs", android.content.Context.MODE_PRIVATE)
            val savedVoiceId = prefs.getString("elevenlabs_voice_id", "EXAVITQu4vr4xnSDxMaL") ?: "EXAVITQu4vr4xnSDxMaL"
            val savedKey = prefs.getString("elevenlabs_api_key", "") ?: ""
            val savedHindi = prefs.getBoolean("is_hindi_lang", true)

            VoiceMatrixDialog(
                initialVoiceId = savedVoiceId,
                initialApiKey = savedKey,
                isHindi = savedHindi,
                theme = currentTheme,
                onDismiss = { showVoiceDialog = false },
                onSave = { vId, key, hindi ->
                    prefs.edit()
                        .putString("elevenlabs_voice_id", vId.trim())
                        .putString("elevenlabs_api_key", key.trim())
                        .putBoolean("is_hindi_lang", hindi)
                        .apply()
                    soundManager.playAcknowledgeChirp()
                },
                onTestVoice = { _, _ ->
                    JarvisBackgroundService.dispatchVoiceCommand(context, "Hey Jarvis")
                }
            )
        }
    }
}

@Composable
private fun YouTubeVoiceResultsBanner(
    results: List<YouTubeVideoItem>,
    theme: HoloTheme,
    onSelectVideo: (YouTubeVideoItem) -> Unit,
    onDismiss: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(CutCornerShape(8.dp))
            .background(JarvisSurface)
            .border(1.2.dp, theme.primary, CutCornerShape(8.dp))
            .padding(10.dp)
            .testTag("youtube_voice_results_banner")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = theme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "BOSS, INMEIN SE KAUNSA PLAY KARNA HAI?",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.5.sp,
                    color = theme.primary
                )
            }
            Text(
                text = "CLOSE",
                fontFamily = FontFamily.Monospace,
                fontSize = 8.sp,
                color = TextMuted,
                modifier = Modifier.clickable(onClick = onDismiss)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        results.take(3).forEach { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
                    .clip(CutCornerShape(4.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .clickable { onSelectVideo(item) }
                    .padding(horizontal = 8.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${item.index}. ${item.title}",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        color = TextPrimary,
                        maxLines = 1
                    )
                    Text(
                        text = item.channelName,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 7.5.sp,
                        color = theme.secondary,
                        maxLines = 1
                    )
                }
                Text(
                    text = "SAY '${item.index}'",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 8.sp,
                    color = StatusNormal
                )
            }
        }
    }
}

@Composable
private fun OneTimePermissionCard(
    theme: HoloTheme,
    onGrantPermissions: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(CutCornerShape(8.dp))
            .background(StatusAlert.copy(alpha = 0.14f))
            .border(1.2.dp, StatusAlert, CutCornerShape(8.dp))
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = null,
                tint = StatusAlert,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "ONE-TIME PERMISSION SETUP REQUIRED",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.5.sp,
                    color = StatusAlert
                )
                Text(
                    text = "Grant Microphone, Contacts & Phone once to enable permanent 24/7 'Hey Jarvis' wake word.",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 8.sp,
                    color = TextPrimary
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Button(
            onClick = onGrantPermissions,
            colors = ButtonDefaults.buttonColors(containerColor = theme.primary),
            shape = CutCornerShape(4.dp)
        ) {
            Text(
                text = "GRANT ONCE",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                color = Color.Black
            )
        }
    }
}

@Composable
private fun ContactDisambiguationBanner(
    matches: List<ContactMatch>,
    theme: HoloTheme,
    onSelectContact: (ContactMatch) -> Unit,
    onDismiss: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(CutCornerShape(8.dp))
            .background(JarvisSurface)
            .border(1.2.dp, theme.secondary, CutCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = null,
                    tint = theme.secondary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "MULTIPLE CONTACTS FOUND // SPEAK CHOICE",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = theme.secondary
                )
            }
            Text(
                text = "CANCEL",
                fontFamily = FontFamily.Monospace,
                fontSize = 8.5.sp,
                color = TextMuted,
                modifier = Modifier.clickable(onClick = onDismiss)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        matches.forEachIndexed { idx, contact ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
                    .clip(CutCornerShape(4.dp))
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable { onSelectContact(contact) }
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${idx + 1}. ${contact.name}",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.5.sp,
                    color = TextPrimary
                )
                Text(
                    text = contact.phoneNumber,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = StatusNormal
                )
            }
        }
    }
}

@Composable
private fun NavTabButton(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    theme: HoloTheme,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(CutCornerShape(4.dp))
            .background(
                if (isSelected) theme.primary.copy(alpha = 0.22f)
                else JarvisSurface
            )
            .border(
                1.dp,
                if (isSelected) theme.primary else theme.primary.copy(alpha = 0.25f),
                CutCornerShape(4.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) theme.primary else TextMuted,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontFamily = FontFamily.Monospace,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                fontSize = 9.sp,
                color = if (isSelected) TextPrimary else TextMuted,
                letterSpacing = 0.5.sp
            )
        }
    }
}
