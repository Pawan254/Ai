package com.example.tasks

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

enum class TaskPriority(val weight: Int, val label: String) {
    CRITICAL(3, "CRITICAL // IMMEDIATE"),
    HIGH(2, "HIGH PRIORITY"),
    NORMAL(1, "BACKGROUND")
}

enum class TaskExecutionStatus(val label: String) {
    QUEUED("QUEUED"),
    RUNNING("RUNNING IN PARALLEL"),
    COMPLETED("COMPLETED"),
    CANCELLED("CANCELLED BY VOICE"),
    RECOVERING("AUTO-RECOVERING"),
    FAILED("ERROR HANDLED")
}

data class JarvisTask(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val commandText: String,
    val category: String, // "APP_LAUNCH", "PHONE_CALL", "MEMORY_OP", "SYSTEM_CONTROL", "KNOWLEDGE_QUERY"
    val priority: TaskPriority = TaskPriority.HIGH,
    val status: TaskExecutionStatus = TaskExecutionStatus.QUEUED,
    val statusDetail: String = "Queued in parallel dispatcher",
    val retryCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Modules 8, 9 & 14: Task Manager, Parallel Execution Engine & Error Recovery Engine.
 * Supports:
 * - Parallel Task Execution (non-blocking)
 * - Multiple Task Queue & Priority ordering
 * - Background Processing
 * - Task Status Tracking & Task Cancellation
 * - Error Recovery with exponential retry
 */
class JarvisTaskManager {
    private val taskScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val activeJobs = ConcurrentHashMap<String, Job>()

    private val _tasks = MutableStateFlow<List<JarvisTask>>(emptyList())
    val tasks: StateFlow<List<JarvisTask>> = _tasks.asStateFlow()

    fun submitParallelTask(
        title: String,
        commandText: String,
        category: String,
        priority: TaskPriority,
        action: suspend () -> String
    ): JarvisTask {
        val newTask = JarvisTask(
            title = title,
            commandText = commandText,
            category = category,
            priority = priority,
            status = TaskExecutionStatus.QUEUED,
            statusDetail = "Initializing parallel execution..."
        )

        _tasks.update { current ->
            (listOf(newTask) + current)
                .sortedWith(compareByDescending<JarvisTask> {
                    it.status == TaskExecutionStatus.RUNNING || it.status == TaskExecutionStatus.QUEUED
                }.thenByDescending { it.priority.weight }.thenByDescending { it.createdAt })
                .take(30)
        }

        val job = taskScope.launch {
            executeWithAutoRecovery(newTask.id, action)
        }
        activeJobs[newTask.id] = job

        return newTask
    }

    fun cancelTask(taskId: String) {
        activeJobs.remove(taskId)?.cancel()
        updateTaskStatus(
            taskId = taskId,
            status = TaskExecutionStatus.CANCELLED,
            detail = "Cancelled by user directive"
        )
    }

    fun cancelLatestRunningTask(): JarvisTask? {
        val running = _tasks.value.firstOrNull {
            it.status == TaskExecutionStatus.RUNNING || it.status == TaskExecutionStatus.QUEUED
        } ?: _tasks.value.firstOrNull()
        if (running != null) {
            cancelTask(running.id)
        }
        return running
    }

    private suspend fun executeWithAutoRecovery(taskId: String, action: suspend () -> String) {
        updateTaskStatus(
            taskId = taskId,
            status = TaskExecutionStatus.RUNNING,
            detail = "Executing on parallel thread..."
        )

        var attempt = 0
        val maxRetries = 2
        while (attempt <= maxRetries) {
            try {
                val outcome = action()
                updateTaskStatus(
                    taskId = taskId,
                    status = TaskExecutionStatus.COMPLETED,
                    detail = outcome,
                    retries = attempt
                )
                activeJobs.remove(taskId)
                return
            } catch (e: kotlinx.coroutines.CancellationException) {
                updateTaskStatus(
                    taskId = taskId,
                    status = TaskExecutionStatus.CANCELLED,
                    detail = "Cancelled safely",
                    retries = attempt
                )
                activeJobs.remove(taskId)
                throw e
            } catch (e: Exception) {
                attempt++
                if (attempt <= maxRetries) {
                    updateTaskStatus(
                        taskId = taskId,
                        status = TaskExecutionStatus.RECOVERING,
                        detail = "Auto-recovery attempt $attempt/$maxRetries: ${e.localizedMessage ?: "Retrying protocol"}",
                        retries = attempt
                    )
                    delay(250L * attempt)
                } else {
                    updateTaskStatus(
                        taskId = taskId,
                        status = TaskExecutionStatus.FAILED,
                        detail = "Fallback recovery applied: ${e.localizedMessage ?: "Task isolated safely"}",
                        retries = attempt
                    )
                    activeJobs.remove(taskId)
                }
            }
        }
    }

    private fun updateTaskStatus(
        taskId: String,
        status: TaskExecutionStatus,
        detail: String,
        retries: Int = 0
    ) {
        _tasks.update { list ->
            list.map { task ->
                if (task.id == taskId) {
                    task.copy(
                        status = status,
                        statusDetail = detail,
                        retryCount = retries,
                        updatedAt = System.currentTimeMillis()
                    )
                } else {
                    task
                }
            }
        }
    }

    fun clearCompletedTasks() {
        _tasks.update { list ->
            list.filter { it.status == TaskExecutionStatus.RUNNING || it.status == TaskExecutionStatus.QUEUED }
        }
    }
}
