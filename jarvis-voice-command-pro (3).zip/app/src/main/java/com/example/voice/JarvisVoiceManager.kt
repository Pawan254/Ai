package com.example.voice

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.example.BuildConfig
import com.example.audio.JarvisSoundManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.TimeUnit

enum class WakeListeningPhase(val statusLabel: String) {
    STANDBY_WAKE_WORD("WAKE WORD STANDBY // SAY 'HEY JARVIS'"),
    AWAITING_COMMAND("SYSTEM ON // जी Boss Pawan, बताइए"),
    EXECUTING("PROCESSING // PARALLEL EXECUTION")
}

/**
 * Modules 1, 2 & 10: Wake Word Engine, Voice Recognition Engine, and Natural Female Text-to-Speech Engine.
 * - Selects a natural, pleasant female Hindi/Indian-English voice (`Voice` with female characteristics
 *   or natural warm female pitch/rate) on Android TTS, and defaults to a natural female neural voice
 *   ("EXAVITQu4vr4xnSDxMaL" - Bella / Sarah) when ElevenLabs is configured.
 * - Preserves `normalizeVoiceId` compatibility for existing unit tests.
 */
class JarvisVoiceManager(
    private val context: Context,
    private val onSpeechResult: (String) -> Unit,
    private val onPartialSpeech: (String) -> Unit,
    private val onSpeechStart: () -> Unit,
    private val onSpeechEnd: () -> Unit,
    private val onTtsStart: () -> Unit,
    private val onTtsDone: () -> Unit,
    private val onWakeWordDetected: () -> Unit = {},
    private val onSystemOffDetected: () -> Unit = {},
    private val onPhaseChanged: (WakeListeningPhase) -> Unit = {}
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var mediaPlayer: MediaPlayer? = null
    private var isTtsInitialized = false
    private var isListening = false
    private var isSpeakingNow = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private val soundManager = JarvisSoundManager(context)

    var isSystemActiveSession: Boolean = true
        private set

    var currentPhase: WakeListeningPhase = WakeListeningPhase.AWAITING_COMMAND
        private set

    private var consecutiveErrorCount: Int = 0
    private var lastWakeTriggeredAtMs: Long = 0L

    private val scope = CoroutineScope(Dispatchers.Main)
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // Natural pleasant female voice profile
    var currentVoiceId: String = "EXAVITQu4vr4xnSDxMaL"
        set(value) {
            field = normalizeVoiceId(value)
        }
    var elevenLabsApiKey: String = ""
    var isHindiLanguage: Boolean = true

    init {
        try {
            val buildKey = BuildConfig.ELEVENLABS_API_KEY
            if (!buildKey.isNullOrBlank() && buildKey != "none") {
                elevenLabsApiKey = buildKey
            }
        } catch (_: Exception) {}

        val prefs = context.getSharedPreferences("jarvis_voice_prefs", Context.MODE_PRIVATE)
        val savedKey = prefs.getString("elevenlabs_api_key", null)
        if (!savedKey.isNullOrBlank()) {
            elevenLabsApiKey = savedKey
        }
        val savedVoiceId = prefs.getString("elevenlabs_voice_id", null)
        if (!savedVoiceId.isNullOrBlank()) {
            currentVoiceId = normalizeVoiceId(savedVoiceId)
        }
        isHindiLanguage = prefs.getBoolean("is_hindi_lang", true)

        initTts()
        initRecognizer()
    }

    private fun updatePhase(newPhase: WakeListeningPhase) {
        currentPhase = newPhase
        mainHandler.post {
            onPhaseChanged(newPhase)
        }
    }

    fun setSystemActiveState(active: Boolean) {
        isSystemActiveSession = active
        if (active) {
            updatePhase(WakeListeningPhase.AWAITING_COMMAND)
        } else {
            updatePhase(WakeListeningPhase.STANDBY_WAKE_WORD)
        }
    }

    fun containsWakeWord(rawText: String): Boolean {
        val lower = rawText.lowercase(Locale.ROOT).trim()
        val wakeVariants = listOf(
            "hey jarvis",
            "he jarvis",
            "hi jarvis",
            "hello jarvis",
            "ok jarvis",
            "okay jarvis",
            "jarvis",
            "jarves",
            "jarviz",
            "जार्विस",
            "हे जार्विस",
            "हाय जार्विस",
            "अरे जार्विस",
            "ओके जार्विस"
        )
        return wakeVariants.any { lower.contains(it) }
    }

    fun isSystemOffCommand(rawText: String): Boolean {
        val lower = rawText.lowercase(Locale.ROOT).trim()
        return lower.contains("jarvis system off") ||
            lower.contains("system off") ||
            lower.contains("सिस्टम ऑफ") ||
            lower.contains("जार्विस सिस्टम ऑफ") ||
            lower.contains("jarvis off")
    }

    fun stripWakeWord(rawText: String): String {
        var cleaned = rawText.trim()
        val prefixes = listOf(
            "hey jarvis", "he jarvis", "hi jarvis", "hello jarvis", "ok jarvis", "okay jarvis",
            "हे जार्विस", "हाय जार्विस", "अरे जार्विस", "ओके जार्विस",
            "jarvis", "jarves", "jarviz", "जार्विस"
        )
        for (p in prefixes) {
            val regex = Regex("^(?:.*?)?\\b${Regex.escape(p)}\\b[,\\.!\\?।\\s]*", RegexOption.IGNORE_CASE)
            if (regex.containsMatchIn(cleaned)) {
                cleaned = cleaned.replaceFirst(regex, "").trim()
                break
            } else if (cleaned.lowercase(Locale.ROOT).startsWith(p)) {
                cleaned = cleaned.substring(p.length).trim().removePrefix(",").removePrefix("।").trim()
                break
            }
        }
        return cleaned
    }

    fun triggerWakeWordGreeting() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastWakeTriggeredAtMs < 1200L) return
        lastWakeTriggeredAtMs = now

        isSystemActiveSession = true
        updatePhase(WakeListeningPhase.AWAITING_COMMAND)
        onWakeWordDetected()
        speak("जी, बताइए।")
    }

    fun triggerSystemOffMode() {
        isSystemActiveSession = false
        updatePhase(WakeListeningPhase.STANDBY_WAKE_WORD)
        onSystemOffDetected()
        speak("Active Assistant Mode बंद कर दिया गया है, Boss Pawan। दोबारा चालू करने के लिए Hey Jarvis बोलिए।")
    }

    fun isDeviceOnline(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Selects a natural, pleasant female voice from Android's installed TTS voices
     * for Hindi (`hi-IN`) or English (`en-IN` / `en-US`) and tunes pitch/rate for warm human cadence.
     */
    private fun applyNaturalFemaleVoiceSettings(tts: TextToSpeech, hindi: Boolean) {
        try {
            val targetLocale = if (hindi) Locale.forLanguageTag("hi-IN") else Locale.forLanguageTag("en-IN")
            val res = tts.setLanguage(targetLocale)
            if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(if (hindi) Locale.forLanguageTag("hi") else Locale.US)
            }

            // Search installed TTS voices for a high-quality female voice matching the language
            val availableVoices: Set<Voice>? = try { tts.voices } catch (_: Exception) { null }
            if (!availableVoices.isNullOrEmpty()) {
                val langCode = if (hindi) "hi" else "en"
                val femaleCandidate = availableVoices.filter { v ->
                    v.locale.language.equals(langCode, ignoreCase = true) && !v.isNetworkConnectionRequired
                }.firstOrNull { v ->
                    val nameLower = v.name.lowercase(Locale.ROOT)
                    val features = v.features ?: emptySet()
                    nameLower.contains("female") ||
                        nameLower.contains("hia") ||
                        nameLower.contains("hic") ||
                        nameLower.contains("hif") ||
                        nameLower.contains("ena") ||
                        nameLower.contains("enc") ||
                        nameLower.contains("sfg") ||
                        features.any { it.contains("female", ignoreCase = true) }
                } ?: availableVoices.firstOrNull { v ->
                    v.locale.language.equals(langCode, ignoreCase = true) &&
                        (v.name.contains("female", ignoreCase = true) || v.name.contains("#female", ignoreCase = true))
                }

                if (femaleCandidate != null) {
                    tts.voice = femaleCandidate
                }
            }

            // Warm, natural female vocal pitch & smooth conversational speech rate
            tts.setPitch(1.12f)
            tts.setSpeechRate(0.98f)
        } catch (_: Exception) {}
    }

    fun setLanguage(hindi: Boolean) {
        this.isHindiLanguage = hindi
        context.getSharedPreferences("jarvis_voice_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("is_hindi_lang", hindi)
            .apply()

        textToSpeech?.let { tts ->
            applyNaturalFemaleVoiceSettings(tts, hindi)
        }
    }

    fun saveVoicePreferences(apiKey: String, voiceId: String) {
        this.elevenLabsApiKey = apiKey.trim()
        this.currentVoiceId = normalizeVoiceId(voiceId)
        context.getSharedPreferences("jarvis_voice_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString("elevenlabs_api_key", this.elevenLabsApiKey)
            .putString("elevenlabs_voice_id", this.currentVoiceId)
            .apply()
    }

    private fun normalizeVoiceId(raw: String): String {
        val clean = raw.trim().replace("/", "j")
        return if (clean.isBlank()) "EXAVITQu4vr4xnSDxMaL" else clean
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.let { tts ->
                    applyNaturalFemaleVoiceSettings(tts, isHindiLanguage)

                    tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            isSpeakingNow = true
                            stopListeningInternal()
                            soundManager.requestTtsAudioFocus()
                            mainHandler.post { onTtsStart() }
                        }

                        override fun onDone(utteranceId: String?) {
                            isSpeakingNow = false
                            soundManager.abandonTtsAudioFocus()
                            mainHandler.post {
                                onTtsDone()
                                scheduleRestartListening(320L)
                            }
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            isSpeakingNow = false
                            soundManager.abandonTtsAudioFocus()
                            mainHandler.post {
                                onTtsDone()
                                scheduleRestartListening(400L)
                            }
                        }
                    })
                    isTtsInitialized = true
                }
            }
        }
    }

    private val restartListeningRunnable = Runnable {
        if (!isListening && !isSpeakingNow && hasRecordAudioPermission()) {
            startListening(interruptTts = false)
        }
    }

    private fun hasRecordAudioPermission(): Boolean {
        return try {
            context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) {
            false
        }
    }

    private fun initRecognizer() {
        mainHandler.post {
            if (!hasRecordAudioPermission()) return@post
            if (SpeechRecognizer.isRecognitionAvailable(context)) {
                try {
                    speechRecognizer?.destroy()
                } catch (_: Exception) {}
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            consecutiveErrorCount = 0
                            onSpeechStart()
                        }

                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}

                        override fun onEndOfSpeech() {
                            onSpeechEnd()
                        }

                        override fun onError(error: Int) {
                            isListening = false
                            onSpeechEnd()
                            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                                return
                            }
                            consecutiveErrorCount++
                            // Smooth exponential backoff on virtual devices/emulators when mic stream is idle
                            val backoffMs = when {
                                error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 2500L
                                consecutiveErrorCount == 1 -> 1100L
                                consecutiveErrorCount in 2..3 -> 2400L
                                consecutiveErrorCount in 4..6 -> 4500L
                                else -> 8000L
                            }
                            if (!isSpeakingNow && hasRecordAudioPermission()) {
                                scheduleRestartListening(backoffMs)
                            }
                        }

                        override fun onResults(results: Bundle?) {
                            isListening = false
                            consecutiveErrorCount = 0
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            if (!matches.isNullOrEmpty()) {
                                val bestMatch = matches[0].trim()
                                if (bestMatch.isNotBlank()) {
                                    handleRecognizedUtterance(bestMatch)
                                }
                            }
                            onSpeechEnd()
                            if (!isSpeakingNow) {
                                scheduleRestartListening(450L)
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            if (!matches.isNullOrEmpty()) {
                                val partial = matches[0].trim()
                                onPartialSpeech(partial)
                                if (!isSystemActiveSession &&
                                    (partial.equals("hey jarvis", ignoreCase = true) ||
                                     partial.equals("हे जार्विस", ignoreCase = true))
                                ) {
                                    stopListeningInternal()
                                    triggerWakeWordGreeting()
                                }
                            }
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            }
        }
    }

    private fun handleRecognizedUtterance(utterance: String) {
        if (isSystemOffCommand(utterance)) {
            triggerSystemOffMode()
            return
        }

        val hasWake = containsWakeWord(utterance)

        if (hasWake) {
            val remainder = stripWakeWord(utterance)
            if (remainder.isBlank()) {
                triggerWakeWordGreeting()
            } else {
                isSystemActiveSession = true
                updatePhase(WakeListeningPhase.EXECUTING)
                onWakeWordDetected()
                onSpeechResult(remainder)
                updatePhase(WakeListeningPhase.AWAITING_COMMAND)
            }
        } else if (isSystemActiveSession) {
            updatePhase(WakeListeningPhase.EXECUTING)
            onSpeechResult(utterance)
            updatePhase(WakeListeningPhase.AWAITING_COMMAND)
        } else {
            updatePhase(WakeListeningPhase.STANDBY_WAKE_WORD)
        }
    }

    private fun scheduleRestartListening(delayMs: Long) {
        mainHandler.removeCallbacks(restartListeningRunnable)
        if (!hasRecordAudioPermission()) return
        mainHandler.postDelayed(restartListeningRunnable, delayMs)
    }

    fun startListening(interruptTts: Boolean = false) {
        if (!hasRecordAudioPermission()) {
            return
        }
        if (interruptTts) {
            stopSpeaking()
        }
        if (isSpeakingNow || isListening) {
            return
        }
        mainHandler.post {
            if (!hasRecordAudioPermission() || isSpeakingNow || isListening) return@post
            if (speechRecognizer == null) {
                initRecognizer()
            }
            val offlinePreferred = !isDeviceOnline()
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                if (isHindiLanguage) {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                    putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("hi-IN", "en-IN", "en-US"))
                } else {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                    putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("en-IN", "hi-IN", "en-US"))
                }
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offlinePreferred)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            try {
                if (consecutiveErrorCount <= 1) {
                    soundManager.runWithSilentMicTransition {
                        speechRecognizer?.startListening(intent)
                        isListening = true
                    }
                } else {
                    speechRecognizer?.startListening(intent)
                    isListening = true
                }
            } catch (_: Exception) {
                isListening = false
                initRecognizer()
                scheduleRestartListening(2000L)
            }
        }
    }

    private fun stopListeningInternal() {
        mainHandler.removeCallbacks(restartListeningRunnable)
        mainHandler.post {
            if (isListening) {
                try {
                    speechRecognizer?.stopListening()
                } catch (_: Exception) {}
                isListening = false
                onSpeechEnd()
            }
        }
    }

    fun speak(text: String) {
        stopSpeaking()
        stopListeningInternal()
        isSpeakingNow = true
        soundManager.requestTtsAudioFocus()

        if (elevenLabsApiKey.isNotBlank() && isDeviceOnline()) {
            scope.launch {
                val success = speakWithElevenLabs(text)
                if (!success) {
                    speakWithLocalTts(text)
                }
            }
        } else {
            speakWithLocalTts(text)
        }
    }

    private suspend fun speakWithElevenLabs(text: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val voiceId = currentVoiceId
            val url = "https://api.elevenlabs.io/v1/text-to-speech/$voiceId"

            val jsonBody = JSONObject().apply {
                put("text", text)
                put("model_id", "eleven_multilingual_v2")
                put("voice_settings", JSONObject().apply {
                    put("stability", 0.55)
                    put("similarity_boost", 0.85)
                    put("style", 0.25)
                    put("use_speaker_boost", true)
                })
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("xi-api-key", elevenLabsApiKey)
                .addHeader("Content-Type", "application/json")
                .addHeader("Accept", "audio/mpeg")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext false
            }

            val body = response.body ?: return@withContext false
            val tempFile = File.createTempFile("jarvis_tts_", ".mp3", context.cacheDir)
            FileOutputStream(tempFile).use { fos ->
                fos.write(body.bytes())
            }

            withContext(Dispatchers.Main) {
                playAudioFile(tempFile)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun playAudioFile(file: File) {
        try {
            isSpeakingNow = true
            onTtsStart()
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnPreparedListener {
                    it.start()
                }
                setOnCompletionListener {
                    it.release()
                    mediaPlayer = null
                    file.delete()
                    isSpeakingNow = false
                    soundManager.abandonTtsAudioFocus()
                    onTtsDone()
                    scheduleRestartListening(320L)
                }
                setOnErrorListener { mp, _, _ ->
                    mp.release()
                    mediaPlayer = null
                    file.delete()
                    isSpeakingNow = false
                    soundManager.abandonTtsAudioFocus()
                    onTtsDone()
                    scheduleRestartListening(350L)
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            isSpeakingNow = false
            soundManager.abandonTtsAudioFocus()
            onTtsDone()
            scheduleRestartListening(350L)
        }
    }

    private fun speakWithLocalTts(text: String) {
        if (isTtsInitialized && textToSpeech != null) {
            val utteranceId = "jarvis_${System.currentTimeMillis()}"
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        } else {
            isSpeakingNow = false
            soundManager.abandonTtsAudioFocus()
            onTtsStart()
            onTtsDone()
            scheduleRestartListening(400L)
        }
    }

    fun stopSpeaking() {
        isSpeakingNow = false
        soundManager.abandonTtsAudioFocus()
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.release()
                mediaPlayer = null
            }
        } catch (_: Exception) {}

        if (isTtsInitialized && textToSpeech != null) {
            textToSpeech?.stop()
        }
        onTtsDone()
    }

    fun destroy() {
        mainHandler.removeCallbacksAndMessages(null)
        stopSpeaking()
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        try {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
        } catch (_: Exception) {}
    }
}
