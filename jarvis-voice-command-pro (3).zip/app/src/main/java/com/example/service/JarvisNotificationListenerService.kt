package com.example.service

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.Locale

data class CapturedAppNotification(
    val packageName: String,
    val senderOrTitle: String,
    val textContent: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Real Android NotificationListenerService that captures incoming WhatsApp messages
 * and Instagram like/message notifications when the user has granted Notification Access.
 * Never fabricates private data if permission is not enabled or if no notifications have arrived.
 */
class JarvisNotificationListenerService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val notification = sbn?.notification ?: return
        val pkg = sbn.packageName ?: return
        val extras = notification.extras ?: return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim() ?: ""

        if (title.isBlank() && text.isBlank()) return

        when (pkg) {
            "com.whatsapp", "com.whatsapp.w4b" -> {
                val entry = CapturedAppNotification(
                    packageName = pkg,
                    senderOrTitle = title.ifBlank { "WhatsApp Contact" },
                    textContent = text
                )
                _whatsappNotifications.update { current ->
                    (listOf(entry) + current).distinctBy { "${it.senderOrTitle}_${it.textContent}" }.take(25)
                }
            }
            "com.instagram.android" -> {
                val entry = CapturedAppNotification(
                    packageName = pkg,
                    senderOrTitle = title.ifBlank { "Instagram" },
                    textContent = text
                )
                _instagramNotifications.update { current ->
                    (listOf(entry) + current).distinctBy { "${it.senderOrTitle}_${it.textContent}" }.take(25)
                }
            }
        }
    }

    companion object {
        private val _whatsappNotifications = MutableStateFlow<List<CapturedAppNotification>>(emptyList())
        val whatsappNotifications: StateFlow<List<CapturedAppNotification>> = _whatsappNotifications.asStateFlow()

        private val _instagramNotifications = MutableStateFlow<List<CapturedAppNotification>>(emptyList())
        val instagramNotifications: StateFlow<List<CapturedAppNotification>> = _instagramNotifications.asStateFlow()

        fun isNotificationAccessEnabled(context: Context): Boolean {
            return try {
                val flat = Settings.Secure.getString(
                    context.contentResolver,
                    "enabled_notification_listeners"
                ) ?: return false
                val cn = ComponentName(context, JarvisNotificationListenerService::class.java)
                flat.contains(cn.flattenToString()) || flat.contains(context.packageName)
            } catch (_: Exception) {
                false
            }
        }

        fun getInstagramLikersSummary(): List<String> {
            return _instagramNotifications.value
                .filter {
                    val lower = "${it.senderOrTitle} ${it.textContent}".lowercase(Locale.ROOT)
                    lower.contains("liked your") || lower.contains("liked") || lower.contains("पसंद")
                }
                .map { "${it.senderOrTitle}: ${it.textContent}" }
        }

        fun getInstagramMessagesSummary(): List<String> {
            return _instagramNotifications.value
                .filter {
                    val lower = "${it.senderOrTitle} ${it.textContent}".lowercase(Locale.ROOT)
                    !lower.contains("liked your")
                }
                .map { "${it.senderOrTitle}: ${it.textContent}" }
        }

        fun getWhatsAppMessagesSummary(): List<String> {
            return _whatsappNotifications.value.map { "${it.senderOrTitle}: ${it.textContent}" }
        }
    }
}
