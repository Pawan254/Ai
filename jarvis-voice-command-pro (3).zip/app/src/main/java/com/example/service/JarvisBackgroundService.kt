package com.example.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.audio.JarvisSoundManager
import com.example.brain.CallResolutionResult
import com.example.brain.ContactMatch
import com.example.brain.JarvisBrain
import com.example.brain.JarvisCommandResult
import com.example.brain.YouTubeVideoItem
import com.example.model.AppItem
import com.example.model.AssistantState
import com.example.model.ChatMessage
import com.example.model.HoloTheme
import com.example.model.ReactorStyle
import com.example.voice.JarvisVoiceManager
import com.example.voice.WakeListeningPhase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class JarvisBackgroundService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        val appContext = applicationContext
        createSilentNotificationChannel()

        if (!hasRecordAudioPermission(appContext)) {
            stopSelf()
            return
        }

        if (!startJarvisForeground("System ON: Boss Pawan — Say \"Hey Jarvis\" or speak any command")) {
            stopSelf()
            return
        }

        acquireLowPowerWakeLock()
        _isServiceRunning.value = true
        ensureVoiceEngineReady(appContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val appContext = applicationContext
        createSilentNotificationChannel()

        // Android O+ requires startForeground() on EVERY startForegroundService() invocation
        if (!hasRecordAudioPermission(appContext)) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (!startJarvisForeground(_wakePhase.value.statusLabel)) {
            stopSelf()
            return START_NOT_STICKY
        }

        _isServiceRunning.value = true
        ensureVoiceEngineReady(appContext)
        sharedVoiceManager?.startListening(interruptTts = false)

        intent?.getStringExtra(EXTRA_SIMULATED_VOICE_COMMAND)?.let { simulatedCmd ->
            if (simulatedCmd.isNotBlank()) {
                executeVoiceDirectiveInternal(appContext, simulatedCmd)
            }
        }

        return START_STICKY
    }

    private fun acquireLowPowerWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = pm?.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "Jarvis::PermanentWakeWordLock"
            )?.apply {
                setReferenceCounted(false)
                acquire(10 * 60 * 1000L) // Safe 10-minute renewable lock
            }
        } catch (_: Exception) {}
    }

    private fun createSilentNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS Silent Voice Service",
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "Silent persistent notification for Android Microphone Privacy compliance."
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    private fun buildPersistentNotification(statusText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("J.A.R.V.I.S. // BOSS PAWAN VOICE AI")
            .setContentText(statusText)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(pendingOpen)
            .build()
    }

    private fun startJarvisForeground(statusText: String): Boolean {
        val notification = buildPersistentNotification(statusText)
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    override fun onDestroy() {
        _isServiceRunning.value = false
        try {
            wakeLock?.let {
                if (it.isHeld) it.release()
            }
        } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "jarvis_silent_voice_channel_v2"
        private const val NOTIFICATION_ID = 8501
        private const val EXTRA_SIMULATED_VOICE_COMMAND = "extra_simulated_voice_command"

        private val companionScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

        @Volatile
        private var sharedBrainInstance: JarvisBrain? = null

        @Volatile
        private var sharedVoiceManager: JarvisVoiceManager? = null

        fun getOrCreateSharedBrain(context: Context): JarvisBrain {
            return sharedBrainInstance ?: synchronized(this) {
                val instance = JarvisBrain(context.applicationContext)
                sharedBrainInstance = instance
                instance
            }
        }

        private fun hasRecordAudioPermission(context: Context): Boolean {
            return try {
                ContextCompat.checkSelfPermission(
                    context.applicationContext,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
            } catch (_: Exception) {
                false
            }
        }

        fun ensureVoiceEngineReady(context: Context): JarvisVoiceManager {
            val appContext = context.applicationContext
            getOrCreateSharedBrain(appContext)
            val existing = sharedVoiceManager
            if (existing != null) {
                if (hasRecordAudioPermission(appContext)) {
                    existing.startListening(interruptTts = false)
                }
                return existing
            }
            return synchronized(this) {
                sharedVoiceManager ?: JarvisVoiceManager(
                    context = appContext,
                    onSpeechResult = { recognizedText ->
                        _partialSpeech.value = ""
                        executeVoiceDirectiveInternal(appContext, recognizedText)
                    },
                    onPartialSpeech = { partial ->
                        _partialSpeech.value = partial
                    },
                    onSpeechStart = {
                        _isMicListening.value = true
                        if (_assistantState.value != AssistantState.SPEAKING) {
                            _assistantState.value = AssistantState.LISTENING
                        }
                    },
                    onSpeechEnd = {
                        _isMicListening.value = false
                    },
                    onTtsStart = {
                        _assistantState.value = AssistantState.SPEAKING
                    },
                    onTtsDone = {
                        _assistantState.value = if (_isOverdrive.value) AssistantState.OVERDRIVE else AssistantState.LISTENING
                    },
                    onWakeWordDetected = {
                        appendMessage(ChatMessage(sender = "USER", text = "Hey Jarvis"))
                        appendMessage(
                            ChatMessage(
                                sender = "JARVIS",
                                text = "जी, बताइए।",
                                actionBadge = "SYSTEM ON // जी, बताइए"
                            )
                        )
                    },
                    onSystemOffDetected = {
                        appendMessage(ChatMessage(sender = "USER", text = "Jarvis System Off"))
                        appendMessage(
                            ChatMessage(
                                sender = "JARVIS",
                                text = "Active Assistant Mode बंद कर दिया गया है, Boss Pawan। दोबारा चालू करने के लिए 'Hey Jarvis' बोलिए।",
                                actionBadge = "SYSTEM OFF // STANDBY"
                            )
                        )
                    },
                    onPhaseChanged = { phase ->
                        _wakePhase.value = phase
                    }
                ).also { vm ->
                    sharedVoiceManager = vm
                    if (hasRecordAudioPermission(appContext)) {
                        vm.startListening(interruptTts = false)
                    }
                }
            }
        }

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

        private val _wakePhase = MutableStateFlow(WakeListeningPhase.AWAITING_COMMAND)
        val wakePhase: StateFlow<WakeListeningPhase> = _wakePhase.asStateFlow()

        private val _assistantState = MutableStateFlow(AssistantState.LISTENING)
        val assistantState: StateFlow<AssistantState> = _assistantState.asStateFlow()

        private val _isMicListening = MutableStateFlow(true)
        val isMicListening: StateFlow<Boolean> = _isMicListening.asStateFlow()

        private val _partialSpeech = MutableStateFlow("")
        val partialSpeech: StateFlow<String> = _partialSpeech.asStateFlow()

        private val _currentTheme = MutableStateFlow(HoloTheme.CYAN)
        val currentTheme: StateFlow<HoloTheme> = _currentTheme.asStateFlow()

        private val _reactorStyle = MutableStateFlow(ReactorStyle.RING)
        val reactorStyle: StateFlow<ReactorStyle> = _reactorStyle.asStateFlow()

        private val _isOverdrive = MutableStateFlow(false)
        val isOverdrive: StateFlow<Boolean> = _isOverdrive.asStateFlow()

        private val _requestedTab = MutableStateFlow<Int?>(null)
        val requestedTab: StateFlow<Int?> = _requestedTab.asStateFlow()

        private val _activeSubsystemApp = MutableStateFlow<AppItem?>(null)
        val activeSubsystemApp: StateFlow<AppItem?> = _activeSubsystemApp.asStateFlow()

        private val _disambiguationMatches = MutableStateFlow<List<ContactMatch>>(emptyList())
        val disambiguationMatches: StateFlow<List<ContactMatch>> = _disambiguationMatches.asStateFlow()

        private val _youtubeSearchResults = MutableStateFlow<List<YouTubeVideoItem>>(emptyList())
        val youtubeSearchResults: StateFlow<List<YouTubeVideoItem>> = _youtubeSearchResults.asStateFlow()

        private val _messages = MutableStateFlow(
            listOf(
                ChatMessage(
                    sender = "JARVIS",
                    text = "नमस्ते Boss Pawan! हीही, आपकी बेस्ट फ्रेंड और पर्सनल AI असिस्टेंट जार्विस एकदम रेडी है! बताइए, आज YouTube चलाना है, WhatsApp-Instagram देखना है या कोई मज़ेदार जोक सुनना है?",
                    actionBadge = "BOSS PAWAN // WITTY FEMALE AI"
                )
            )
        )
        val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

        fun appendMessage(msg: ChatMessage) {
            _messages.update { current -> (current + msg).takeLast(60) }
        }

        fun setTheme(theme: HoloTheme) {
            _currentTheme.value = theme
        }

        fun setReactorStyle(style: ReactorStyle) {
            _reactorStyle.value = style
        }

        fun setOverdrive(enabled: Boolean) {
            _isOverdrive.value = enabled
            _assistantState.value = if (enabled) AssistantState.OVERDRIVE else AssistantState.LISTENING
        }

        fun clearRequestedTab() {
            _requestedTab.value = null
        }

        fun setActiveSubsystemApp(app: AppItem?) {
            _activeSubsystemApp.value = app
        }

        fun clearDisambiguation() {
            _disambiguationMatches.value = emptyList()
        }

        fun clearYouTubeResults() {
            _youtubeSearchResults.value = emptyList()
        }

        fun startPermanentService(context: Context) {
            val appContext = context.applicationContext
            ensureVoiceEngineReady(appContext)
            if (!hasRecordAudioPermission(appContext)) {
                return
            }
            if (_isServiceRunning.value) {
                sharedVoiceManager?.startListening(interruptTts = false)
                return
            }
            try {
                val intent = Intent(appContext, JarvisBackgroundService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    appContext.startForegroundService(intent)
                } else {
                    appContext.startService(intent)
                }
            } catch (_: Exception) {}
        }

        /**
         * Executes any voice command or tapped test phrase immediately in-process without
         * triggering redundant startForegroundService() calls that could fail on Android 14+
         * when mic permissions are pending on the virtual device.
         */
        fun dispatchVoiceCommand(context: Context, command: String) {
            val appContext = context.applicationContext
            ensureVoiceEngineReady(appContext)
            executeVoiceDirectiveInternal(appContext, command)
        }

        private fun executeVoiceDirectiveInternal(appContext: Context, rawCommand: String) {
            val brain = getOrCreateSharedBrain(appContext)
            val vm = ensureVoiceEngineReady(appContext)

            if (vm.isSystemOffCommand(rawCommand)) {
                vm.triggerSystemOffMode()
                return
            }

            if (vm.containsWakeWord(rawCommand) && vm.stripWakeWord(rawCommand).isBlank()) {
                vm.triggerWakeWordGreeting()
                return
            }

            if (!vm.isSystemActiveSession && !vm.containsWakeWord(rawCommand)) {
                return
            }

            if (vm.containsWakeWord(rawCommand)) {
                vm.setSystemActiveState(true)
                _wakePhase.value = WakeListeningPhase.AWAITING_COMMAND
            }

            appendMessage(ChatMessage(sender = "USER", text = rawCommand))
            _assistantState.value = AssistantState.THINKING

            companionScope.launch {
                val result = brain.processVoiceCommandWithMemoryAndTasks(
                    rawInput = rawCommand,
                    currentTheme = _currentTheme.value,
                    isHindi = vm.isHindiLanguage
                )
                applyCommandResultToState(vm, result)
            }
        }

        private fun applyCommandResultToState(vm: JarvisVoiceManager, result: JarvisCommandResult) {
            when (result) {
                is JarvisCommandResult.Response -> {
                    appendMessage(ChatMessage(sender = "JARVIS", text = result.text, actionBadge = result.badge))
                    vm.speak(result.text)
                }
                is JarvisCommandResult.SystemModeChanged -> {
                    vm.setSystemActiveState(result.isSystemActive)
                    _wakePhase.value = if (result.isSystemActive) {
                        WakeListeningPhase.AWAITING_COMMAND
                    } else {
                        WakeListeningPhase.STANDBY_WAKE_WORD
                    }
                    appendMessage(ChatMessage(sender = "JARVIS", text = result.text, actionBadge = result.badge))
                    vm.speak(result.text)
                }
                is JarvisCommandResult.ChangeTheme -> {
                    _currentTheme.value = result.theme
                    appendMessage(ChatMessage(sender = "JARVIS", text = result.text, actionBadge = result.theme.codename))
                    vm.speak(result.text)
                }
                is JarvisCommandResult.ChangeReactorStyle -> {
                    _reactorStyle.value = result.style
                    appendMessage(ChatMessage(sender = "JARVIS", text = result.text, actionBadge = result.style.name))
                    vm.speak(result.text)
                }
                is JarvisCommandResult.SetOverdrive -> {
                    _isOverdrive.value = result.enabled
                    appendMessage(ChatMessage(sender = "JARVIS", text = result.text, actionBadge = if (result.enabled) "OVERDRIVE ON" else "STANDBY"))
                    vm.speak(result.text)
                }
                is JarvisCommandResult.AddDirective -> {
                    appendMessage(ChatMessage(sender = "JARVIS", text = result.text, actionBadge = "DIRECTIVE LOGGED"))
                    vm.speak(result.text)
                }
                is JarvisCommandResult.OpenTab -> {
                    _requestedTab.value = result.tabIndex
                    appendMessage(ChatMessage(sender = "JARVIS", text = result.text, actionBadge = "NAVIGATION"))
                    vm.speak(result.text)
                }
                is JarvisCommandResult.OpenAppSubsystem -> {
                    // Always open the interactive in-HUD AppSubsystemSheet so the virtual device stays responsive
                    _activeSubsystemApp.value = result.app
                    appendMessage(ChatMessage(sender = "JARVIS", text = result.text, actionBadge = "LAUNCHED: ${result.app.name.uppercase()}"))
                    vm.speak(result.text)
                }
                is JarvisCommandResult.CloseActiveApp -> {
                    _activeSubsystemApp.value = null
                    _youtubeSearchResults.value = emptyList()
                    appendMessage(ChatMessage(sender = "JARVIS", text = result.text, actionBadge = "APP CLOSED"))
                    vm.speak(result.text)
                }
                is JarvisCommandResult.CallResult -> {
                    if (result.resolution is CallResolutionResult.DisambiguationNeeded) {
                        _disambiguationMatches.value = result.resolution.matches
                    } else {
                        _disambiguationMatches.value = emptyList()
                    }
                    appendMessage(ChatMessage(sender = "JARVIS", text = result.text, actionBadge = result.badge))
                    vm.speak(result.text)
                }
                is JarvisCommandResult.MessageConfirmationPrompt -> {
                    appendMessage(ChatMessage(sender = "JARVIS", text = result.text, actionBadge = result.badge))
                    vm.speak(result.text)
                }
                is JarvisCommandResult.YouTubeSearchResults -> {
                    _youtubeSearchResults.value = result.items
                    appendMessage(ChatMessage(sender = "JARVIS", text = result.text, actionBadge = result.badge))
                    vm.speak(result.text)
                }
                is JarvisCommandResult.MultiCommandBatch -> {
                    result.subResults.forEach { sub ->
                        when (sub) {
                            is JarvisCommandResult.ChangeTheme -> _currentTheme.value = sub.theme
                            is JarvisCommandResult.ChangeReactorStyle -> _reactorStyle.value = sub.style
                            is JarvisCommandResult.SetOverdrive -> _isOverdrive.value = sub.enabled
                            is JarvisCommandResult.OpenTab -> _requestedTab.value = sub.tabIndex
                            is JarvisCommandResult.OpenAppSubsystem -> _activeSubsystemApp.value = sub.app
                            is JarvisCommandResult.CloseActiveApp -> {
                                _activeSubsystemApp.value = null
                                _youtubeSearchResults.value = emptyList()
                            }
                            is JarvisCommandResult.YouTubeSearchResults -> {
                                _youtubeSearchResults.value = sub.items
                            }
                            is JarvisCommandResult.CallResult -> {
                                if (sub.resolution is CallResolutionResult.DisambiguationNeeded) {
                                    _disambiguationMatches.value = sub.resolution.matches
                                }
                            }
                            else -> {}
                        }
                    }
                    appendMessage(ChatMessage(sender = "JARVIS", text = result.combinedSpeech, actionBadge = result.badge))
                    vm.speak(result.combinedSpeech)
                }
            }
        }

        fun scheduleImmediateServiceRecovery(context: Context) {
            if (hasRecordAudioPermission(context)) {
                startPermanentService(context)
            }
        }
    }
}
