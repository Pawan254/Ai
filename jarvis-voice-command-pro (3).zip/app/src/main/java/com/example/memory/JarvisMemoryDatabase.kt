package com.example.memory

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "jarvis_memories")
data class MemoryEntry(
    @PrimaryKey val key: String,
    val category: String, // "IDENTITY", "PREFERENCE", "HABIT", "DIRECTIVE", "CONVERSATION"
    val label: String,
    val value: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "jarvis_history")
data class ConversationHistoryEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userSpoken: String,
    val jarvisSpoken: String,
    val actionTaken: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface JarvisMemoryDao {
    @Query("SELECT * FROM jarvis_memories ORDER BY updatedAt DESC")
    fun observeMemories(): Flow<List<MemoryEntry>>

    @Query("SELECT * FROM jarvis_memories ORDER BY updatedAt DESC")
    suspend fun getAllMemories(): List<MemoryEntry>

    @Query("SELECT * FROM jarvis_memories WHERE `key` = :key LIMIT 1")
    suspend fun getMemoryByKey(key: String): MemoryEntry?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMemory(entry: MemoryEntry)

    @Query("DELETE FROM jarvis_memories WHERE `key` = :key")
    suspend fun deleteMemory(key: String)

    @Query("DELETE FROM jarvis_memories")
    suspend fun clearAllMemories()

    @Query("SELECT * FROM jarvis_history ORDER BY timestamp DESC LIMIT 100")
    fun observeHistory(): Flow<List<ConversationHistoryEntry>>

    @Query("SELECT * FROM jarvis_history ORDER BY timestamp DESC LIMIT 25")
    suspend fun getRecentHistory(): List<ConversationHistoryEntry>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(entry: ConversationHistoryEntry)
}

@Database(
    entities = [MemoryEntry::class, ConversationHistoryEntry::class],
    version = 1,
    exportSchema = false
)
abstract class JarvisMemoryDatabase : RoomDatabase() {
    abstract fun memoryDao(): JarvisMemoryDao

    companion object {
        @Volatile
        private var INSTANCE: JarvisMemoryDatabase? = null

        fun getInstance(context: Context): JarvisMemoryDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    JarvisMemoryDatabase::class.java,
                    "jarvis_permanent_memory.db"
                ).fallbackToDestructiveMigration(true).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
