package com.example.memory

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.util.Locale

data class MemorySaveOutcome(
    val entry: MemoryEntry,
    val wasUpdated: Boolean,
    val wasDuplicate: Boolean,
    val requiresSensitiveConfirmation: Boolean = false
)

class JarvisMemoryRepository(context: Context) {
    private val dao = JarvisMemoryDatabase.getInstance(context).memoryDao()
    private val repoScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val allMemories: Flow<List<MemoryEntry>> = dao.observeMemories()
    val recentHistory: Flow<List<ConversationHistoryEntry>> = dao.observeHistory()

    init {
        repoScope.launch {
            val existingName = dao.getMemoryByKey("user_name")
            if (existingName == null) {
                // Pre-seed Boss's name as Pawan as instructed ("Aur boss ka naam Pawan")
                dao.upsertMemory(
                    MemoryEntry(
                        key = "user_name",
                        category = "IDENTITY",
                        label = "Boss Name",
                        value = "Pawan"
                    )
                )
            }
            val existingWake = dao.getMemoryByKey("wake_word")
            if (existingWake == null) {
                dao.upsertMemory(
                    MemoryEntry(
                        key = "wake_word",
                        category = "DIRECTIVE",
                        label = "System Control Commands",
                        value = "ON: 'Hey Jarvis' | OFF: 'Jarvis System Off' | Voice: Natural Female"
                    )
                )
            }
        }
    }

    suspend fun getAllMemoriesNow(): List<MemoryEntry> = dao.getAllMemories()

    suspend fun getRecentHistoryNow(): List<ConversationHistoryEntry> = dao.getRecentHistory()

    suspend fun getUserName(): String {
        return dao.getMemoryByKey("user_name")?.value ?: "Pawan"
    }

    suspend fun recordFavoriteAppUsage(appName: String) {
        val existing = dao.getMemoryByKey("favorite_apps")?.value ?: ""
        val currentList = existing.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableList()
        currentList.remove(appName)
        currentList.add(0, appName)
        val updatedValue = currentList.take(5).joinToString(", ")
        dao.upsertMemory(
            MemoryEntry(
                key = "favorite_apps",
                category = "PREFERENCE",
                label = "Frequently Used Apps",
                value = updatedValue,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun saveOrUpdateMemory(key: String, category: String, label: String, value: String): MemorySaveOutcome {
        val cleanKey = key.lowercase(Locale.ROOT).trim()
        val cleanVal = value.trim()
        val existing = dao.getMemoryByKey(cleanKey)

        if (existing != null && existing.value.equals(cleanVal, ignoreCase = true)) {
            return MemorySaveOutcome(existing, wasUpdated = false, wasDuplicate = true)
        }

        val entry = MemoryEntry(
            key = cleanKey,
            category = category,
            label = label,
            value = cleanVal,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertMemory(entry)
        return MemorySaveOutcome(entry, wasUpdated = existing != null, wasDuplicate = false)
    }

    suspend fun deleteMemory(key: String) {
        dao.deleteMemory(key)
    }

    suspend fun logInteraction(userSpoken: String, jarvisSpoken: String, actionTaken: String) {
        dao.insertHistory(
            ConversationHistoryEntry(
                userSpoken = userSpoken,
                jarvisSpoken = jarvisSpoken,
                actionTaken = actionTaken
            )
        )
    }

    fun containsSensitiveData(rawSpeech: String): Boolean {
        val lower = rawSpeech.lowercase(Locale.ROOT)
        val sensitiveKeywords = listOf("password", "otp", "cvv", "pin code", "atm pin", "credit card", "bank account", "पासवर्ड", "ओटीपी", "पिन")
        return sensitiveKeywords.any { lower.contains(it) }
    }

    suspend fun autoExtractAndSaveMemory(rawSpeech: String): MemoryEntry? {
        if (containsSensitiveData(rawSpeech)) {
            return null
        }

        val clean = rawSpeech.trim()
        val lower = clean.lowercase(Locale.ROOT)
            .removePrefix("hey jarvis")
            .removePrefix("jarvis")
            .trim()

        if (lower.contains("kya hai") || lower.contains("क्या है") || lower.contains("kya bataya") || lower.contains("क्या बताया") || lower.startsWith("what ") || lower.startsWith("who ")) {
            return null
        }

        val namePatterns = listOf(
            Regex("(?:मेरा नाम|mera naam|my name is|boss ka naam|i am|main hoon|mujhe)\\s+([^\\s,.?!]+(?:\\s+[^\\s,.?!]+)?)(?:\\s+है|\\s+hai|\\s+bulao|\\s+bulana|\\s+kehna|$)", RegexOption.IGNORE_CASE),
            Regex("(?:call me)\\s+([a-zA-Z\\s]{2,25})$", RegexOption.IGNORE_CASE)
        )
        for (pattern in namePatterns) {
            val match = pattern.find(lower)
            if (match != null) {
                val extractedName = match.groupValues[1].trim()
                    .replace("है", "")
                    .replace("hai", "")
                    .trim()
                    .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
                if (extractedName.isNotBlank() && extractedName.lowercase(Locale.ROOT) !in listOf("jarvis", "kya", "kaun", "what", "who", "क्या")) {
                    val outcome = saveOrUpdateMemory(
                        key = "user_name",
                        category = "IDENTITY",
                        label = "Boss Name",
                        value = extractedName
                    )
                    return outcome.entry
                }
            }
        }

        val prefPatterns = listOf(
            Regex("(?:मुझे|mujhe|meri pasand)\\s+(.+?)\\s+(?:पसंद है|pasand hai|acha lagta hai|accha lagta hai)", RegexOption.IGNORE_CASE),
            Regex("(?:i like|i love|my favorite is|my favourite is)\\s+(.+)", RegexOption.IGNORE_CASE)
        )
        for (pattern in prefPatterns) {
            val match = pattern.find(lower)
            if (match != null) {
                val prefValue = match.groupValues[1].trim()
                if (prefValue.isNotBlank()) {
                    val allExisting = dao.getAllMemories()
                    val duplicate = allExisting.firstOrNull { it.category == "PREFERENCE" && it.value.equals(prefValue, ignoreCase = true) }
                    if (duplicate != null) return duplicate

                    val key = "pref_${prefValue.take(18).replace("\\s+".toRegex(), "_")}"
                    val outcome = saveOrUpdateMemory(
                        key = key,
                        category = "PREFERENCE",
                        label = "User Preference",
                        value = prefValue
                    )
                    return outcome.entry
                }
            }
        }

        if (lower.contains("आदत") || lower.contains("aadat") || lower.contains("roz ") || lower.contains("रोज़") || lower.contains("habit") || lower.contains("routine")) {
            val allExisting = dao.getAllMemories()
            val duplicate = allExisting.firstOrNull { it.category == "HABIT" && it.value.equals(clean, ignoreCase = true) }
            if (duplicate != null) return duplicate

            val key = "habit_${(lower.hashCode() and 0x7fffffff) % 1000}"
            val outcome = saveOrUpdateMemory(
                key = key,
                category = "HABIT",
                label = "Habit & Work Style",
                value = clean
            )
            return outcome.entry
        }

        val rememberTriggers = listOf(
            "याद रखना कि", "याद रखना", "याद रखो कि", "याद रखो",
            "yaad rakhna ki", "yaad rakhna", "yaad rakho ki", "yaad rakho",
            "hamesha yaad", "remember that", "remember to", "remember ",
            "memory update karo", "update memory", "save in memory", "note kar lo"
        )
        for (trigger in rememberTriggers) {
            if (lower.contains(trigger)) {
                val fact = lower.substringAfter(trigger).trim().removePrefix("ki ").removePrefix("कि ").trim()
                if (fact.length > 2 && !fact.startsWith("kya") && !fact.startsWith("what")) {
                    val existing = dao.getAllMemories()
                    val exactDup = existing.firstOrNull { it.value.equals(fact, ignoreCase = true) }
                    if (exactDup != null) return exactDup

                    val matchedExisting = existing.firstOrNull { mem ->
                        val words = mem.value.lowercase(Locale.ROOT).split(" ").filter { it.length > 3 }
                        words.any { w -> fact.contains(w) } && mem.key.startsWith("fact_")
                    }
                    val key = matchedExisting?.key ?: "fact_${System.currentTimeMillis() % 100000}"
                    val outcome = saveOrUpdateMemory(
                        key = key,
                        category = "DIRECTIVE",
                        label = if (matchedExisting != null) "Updated Memory Fact" else "Saved Memory Fact",
                        value = fact.replaceFirstChar { it.uppercase() }
                    )
                    return outcome.entry
                }
            }
        }

        return null
    }
}
