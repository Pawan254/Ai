package com.example.brain

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import java.util.Locale

data class ContactMatch(
    val id: String,
    val name: String,
    val phoneNumber: String
)

data class PendingOutgoingMessage(
    val recipientName: String,
    val phoneNumber: String,
    val messageBody: String,
    val isWhatsApp: Boolean
)

sealed class CallResolutionResult {
    data class CallConfirmationNeeded(val contact: ContactMatch) : CallResolutionResult()
    data class CallStarted(val contact: ContactMatch, val directCall: Boolean) : CallResolutionResult()
    data class DisambiguationNeeded(val queryName: String, val matches: List<ContactMatch>, val forWhatsAppMessageBody: String? = null) : CallResolutionResult()
    data class ContactNotFound(val queryName: String) : CallResolutionResult()
    data class PermissionMissing(val missingContacts: Boolean, val missingCall: Boolean) : CallResolutionResult()
}

class JarvisCallSystem(private val context: Context) {

    // Stores pending disambiguation options when multiple contacts match a spoken name
    var pendingDisambiguation: List<ContactMatch> = emptyList()
        private set

    // If disambiguation was triggered for a WhatsApp message, stores the dictated message body
    var pendingDisambiguationMessageBody: String? = null
        private set

    // Stores a prepared WhatsApp or SMS message awaiting user's voice confirmation ("Haan" / "Nahi")
    var pendingMessageConfirmation: PendingOutgoingMessage? = null
        private set

    // Stores a prepared outgoing phone call awaiting user's voice confirmation ("Haan" / "Nahi")
    var pendingCallConfirmation: ContactMatch? = null
        private set

    fun clearPendingDisambiguation() {
        pendingDisambiguation = emptyList()
        pendingDisambiguationMessageBody = null
    }

    fun clearPendingMessage() {
        pendingMessageConfirmation = null
    }

    fun clearPendingCall() {
        pendingCallConfirmation = null
    }

    val hasAnyPendingConfirmation: Boolean
        get() = pendingMessageConfirmation != null || pendingCallConfirmation != null

    fun stagePendingMessage(recipientName: String, messageBody: String, isWhatsApp: Boolean): CallResolutionResult {
        val matches = searchContactsByName(recipientName)
        if (matches.size > 1) {
            val exactMatches = matches.filter { it.name.equals(recipientName, ignoreCase = true) }
            if (exactMatches.size != 1) {
                pendingDisambiguation = matches.take(4)
                pendingDisambiguationMessageBody = messageBody
                return CallResolutionResult.DisambiguationNeeded(
                    queryName = recipientName,
                    matches = pendingDisambiguation,
                    forWhatsAppMessageBody = messageBody
                )
            }
        }

        val matchedContact = matches.firstOrNull()
        val phone = matchedContact?.phoneNumber ?: ""
        val displayRecipient = matchedContact?.name ?: recipientName.replaceFirstChar { it.uppercase() }
        val staged = PendingOutgoingMessage(
            recipientName = displayRecipient,
            phoneNumber = phone,
            messageBody = messageBody,
            isWhatsApp = isWhatsApp
        )
        pendingMessageConfirmation = staged
        return CallResolutionResult.CallStarted(
            contact = matchedContact ?: ContactMatch("staged", displayRecipient, phone),
            directCall = false
        )
    }

    fun executeConfirmedPendingMessage(): PendingOutgoingMessage? {
        val pending = pendingMessageConfirmation ?: return null
        pendingMessageConfirmation = null
        try {
            if (pending.isWhatsApp) {
                val cleanPhone = pending.phoneNumber.replace("[^0-9+]".toRegex(), "")
                val uri = if (cleanPhone.isNotBlank()) {
                    Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encode(pending.messageBody)}")
                } else {
                    Uri.parse("https://api.whatsapp.com/send?text=${Uri.encode(pending.messageBody)}")
                }
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } else {
                val smsUri = Uri.parse("smsto:${Uri.encode(pending.phoneNumber)}")
                val intent = Intent(Intent.ACTION_SENDTO, smsUri).apply {
                    putExtra("sms_body", pending.messageBody)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        } catch (_: Exception) {}
        return pending
    }

    fun executeConfirmedPendingCall(): ContactMatch? {
        val contact = pendingCallConfirmation ?: return null
        pendingCallConfirmation = null
        placePhoneCall(contact.phoneNumber)
        return contact
    }

    fun openWhatsAppChatForContact(contactName: String): CallResolutionResult {
        val matches = searchContactsByName(contactName)
        return when {
            matches.isEmpty() -> {
                // Open WhatsApp main screen if specific contact not in address book
                try {
                    val pm = context.packageManager
                    val launch = pm.getLaunchIntentForPackage("com.whatsapp")
                    if (launch != null) {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(launch)
                    }
                } catch (_: Exception) {}
                CallResolutionResult.ContactNotFound(contactName)
            }
            matches.size == 1 -> {
                val c = matches.first()
                openWhatsAppDirectChat(c.phoneNumber)
                CallResolutionResult.CallStarted(c, directCall = true)
            }
            else -> {
                pendingDisambiguation = matches.take(4)
                CallResolutionResult.DisambiguationNeeded(contactName, pendingDisambiguation)
            }
        }
    }

    private fun openWhatsAppDirectChat(phoneNumber: String) {
        val cleanPhone = phoneNumber.replace("[^0-9+]".toRegex(), "")
        try {
            val uri = Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    fun hasContactsPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasCallPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun getCurrentCallStateDescription(isHindi: Boolean): String {
        return try {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            @Suppress("DEPRECATION")
            val state = tm?.callState ?: TelephonyManager.CALL_STATE_IDLE
            when (state) {
                TelephonyManager.CALL_STATE_RINGING -> if (isHindi) "INCOMING CALL RINGING (कॉल आ रही है)" else "INCOMING CALL RINGING"
                TelephonyManager.CALL_STATE_OFFHOOK -> if (isHindi) "ACTIVE CALL IN PROGRESS (कॉल चालू है)" else "ACTIVE CALL IN PROGRESS"
                else -> if (isHindi) "LINE IDLE // READY FOR CALLS" else "LINE IDLE // READY"
            }
        } catch (_: Exception) {
            "LINE READY"
        }
    }

    fun searchContactsByName(rawQuery: String): List<ContactMatch> {
        if (!hasContactsPermission()) return emptyList()
        val query = rawQuery.trim().lowercase(Locale.ROOT)
        if (query.isBlank()) return emptyList()

        val results = mutableListOf<ContactMatch>()
        val seenNumbers = mutableSetOf<String>()

        try {
            val cursor = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
            )

            cursor?.use { c ->
                val idIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

                while (c.moveToNext()) {
                    val id = if (idIdx >= 0) c.getString(idIdx) ?: "" else ""
                    val name = if (nameIdx >= 0) c.getString(nameIdx) ?: "" else ""
                    val rawNumber = if (numIdx >= 0) c.getString(numIdx) ?: "" else ""
                    val normalizedNum = rawNumber.replace("[^0-9+]".toRegex(), "")

                    if (name.isNotBlank() && normalizedNum.isNotBlank()) {
                        val nameLower = name.lowercase(Locale.ROOT)
                        if (nameLower.contains(query) || query.contains(nameLower) || isFuzzyNameMatch(nameLower, query)) {
                            val uniqueKey = "${nameLower}_$normalizedNum"
                            if (seenNumbers.add(uniqueKey)) {
                                results.add(ContactMatch(id = id, name = name, phoneNumber = rawNumber.trim()))
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        return results
    }

    private fun isFuzzyNameMatch(contactName: String, spokenQuery: String): Boolean {
        val contactTokens = contactName.split(" ")
        val queryTokens = spokenQuery.split(" ")
        for (ct in contactTokens) {
            for (qt in queryTokens) {
                if (ct.length >= 3 && qt.length >= 3) {
                    if (levenshteinDistance(ct, qt) <= 1) return true
                }
            }
        }
        return false
    }

    private fun levenshteinDistance(lhs: CharSequence, rhs: CharSequence): Int {
        val lhsLength = lhs.length
        val rhsLength = rhs.length
        var cost = IntArray(lhsLength + 1) { it }
        var newCost = IntArray(lhsLength + 1) { 0 }
        for (i in 1..rhsLength) {
            newCost[0] = i
            for (j in 1..lhsLength) {
                val match = if (lhs[j - 1] == rhs[i - 1]) 0 else 1
                val costReplace = cost[j - 1] + match
                val costInsert = cost[j] + 1
                val costDelete = newCost[j - 1] + 1
                newCost[j] = minOf(costInsert, costDelete, costReplace)
            }
            val swap = cost
            cost = newCost
            newCost = swap
        }
        return cost[lhsLength]
    }

    fun initiateCallByNameOrNumber(target: String, askConfirmationFirst: Boolean = true): CallResolutionResult {
        val cleanTarget = target.trim()
        val digitsOnly = cleanTarget.replace("[^0-9+]".toRegex(), "")

        // Check if user spoke a direct phone number
        if (digitsOnly.length >= 7 && digitsOnly.length >= cleanTarget.length / 2) {
            val match = ContactMatch(id = "direct", name = digitsOnly, phoneNumber = digitsOnly)
            if (askConfirmationFirst) {
                pendingCallConfirmation = match
                return CallResolutionResult.CallConfirmationNeeded(match)
            }
            val direct = placePhoneCall(digitsOnly)
            return CallResolutionResult.CallStarted(match, direct)
        }

        if (!hasContactsPermission()) {
            return CallResolutionResult.PermissionMissing(
                missingContacts = true,
                missingCall = !hasCallPermission()
            )
        }

        val matches = searchContactsByName(cleanTarget)
        return when {
            matches.isEmpty() -> CallResolutionResult.ContactNotFound(cleanTarget)
            matches.size == 1 -> {
                pendingDisambiguation = emptyList()
                val contact = matches.first()
                if (askConfirmationFirst) {
                    pendingCallConfirmation = contact
                    CallResolutionResult.CallConfirmationNeeded(contact)
                } else {
                    val direct = placePhoneCall(contact.phoneNumber)
                    CallResolutionResult.CallStarted(contact, direct)
                }
            }
            else -> {
                val exactMatches = matches.filter { it.name.equals(cleanTarget, ignoreCase = true) }
                if (exactMatches.size == 1) {
                    pendingDisambiguation = emptyList()
                    val contact = exactMatches.first()
                    if (askConfirmationFirst) {
                        pendingCallConfirmation = contact
                        CallResolutionResult.CallConfirmationNeeded(contact)
                    } else {
                        val direct = placePhoneCall(contact.phoneNumber)
                        CallResolutionResult.CallStarted(contact, direct)
                    }
                } else {
                    pendingDisambiguation = matches.take(4)
                    CallResolutionResult.DisambiguationNeeded(cleanTarget, pendingDisambiguation)
                }
            }
        }
    }

    fun resolveDisambiguationBySpokenChoice(spokenText: String): CallResolutionResult? {
        if (pendingDisambiguation.isEmpty()) return null
        val lower = spokenText.lowercase(Locale.ROOT)

        val selectedIndex = when {
            lower.contains("pehla") || lower.contains("पहला") || lower.contains("first") || lower.contains("ek") || lower.contains("one") || lower.contains("1") -> 0
            lower.contains("doosra") || lower.contains("dusra") || lower.contains("दूसरा") || lower.contains("second") || lower.contains("do") || lower.contains("two") || lower.contains("2") -> 1
            lower.contains("teesra") || lower.contains("tisra") || lower.contains("तीसरा") || lower.contains("third") || lower.contains("teen") || lower.contains("three") || lower.contains("3") -> 2
            else -> {
                pendingDisambiguation.indexOfFirst { contact ->
                    contact.name.lowercase(Locale.ROOT).split(" ").any { token ->
                        token.length > 2 && lower.contains(token)
                    } || contact.phoneNumber.takeLast(4).let { lower.contains(it) }
                }
            }
        }

        if (selectedIndex in pendingDisambiguation.indices) {
            val chosen = pendingDisambiguation[selectedIndex]
            val msgBody = pendingDisambiguationMessageBody
            pendingDisambiguation = emptyList()
            pendingDisambiguationMessageBody = null

            if (msgBody != null) {
                pendingMessageConfirmation = PendingOutgoingMessage(
                    recipientName = chosen.name,
                    phoneNumber = chosen.phoneNumber,
                    messageBody = msgBody,
                    isWhatsApp = true
                )
                return CallResolutionResult.CallStarted(chosen, directCall = false)
            }

            pendingCallConfirmation = chosen
            return CallResolutionResult.CallConfirmationNeeded(chosen)
        }
        return null
    }

    fun placePhoneCall(phoneNumber: String): Boolean {
        val cleanNum = phoneNumber.replace("[^0-9+*#]".toRegex(), "")
        return try {
            if (hasCallPermission()) {
                val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(cleanNum)}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(callIntent)
                true
            } else {
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(cleanNum)}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(dialIntent)
                false
            }
        } catch (_: Exception) {
            try {
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(cleanNum)}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(dialIntent)
            } catch (_: Exception) {}
            false
        }
    }
}
