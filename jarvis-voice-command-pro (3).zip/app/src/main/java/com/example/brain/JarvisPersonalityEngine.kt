package com.example.brain

import java.util.Locale

enum class UserEmotionalMood(val label: String) {
    JOKING_PLAYFUL("PLAYFUL // BANTER"),
    HAPPY_EXCITED("HAPPY // HIGH VIBE"),
    SAD_LOW("EMPATHETIC // CARING FRIEND"),
    ANGRY_FRUSTRATED("CALM // DE-ESCALATING"),
    SERIOUS_URGENT("FOCUSED // PROFESSIONAL FRIEND"),
    CASUAL_FRIENDLY("WITTY BESTIE // NATURAL")
}

/**
 * Integrated Personality & Emotional Intelligence Engine for the single unified Jarvis AI.
 * - Detects whether Boss Pawan is joking, happy, sad, angry, serious/urgent, or casual.
 * - Crafts natural, witty, playful, and warm female best-friend responses in Hindi/Hinglish/English
 *   with expressive laughter ("Haha", "Hehe", "Oho!", "Arey wah!") when appropriate.
 * - Keeps serious/critical actions (calls, message confirmations, security, urgent tasks) focused and
 *   uncluttered while remaining warm and friendly.
 */
class JarvisPersonalityEngine {

    private var jokeCounter = 0

    fun detectUserMood(rawInput: String): UserEmotionalMood {
        val lower = rawInput.lowercase(Locale.ROOT).trim()

        // 1. Serious / Urgent Task Detection (Do not interrupt with unnecessary jokes)
        val urgentMarkers = listOf(
            "emergency", "urgent", "jaldi", "turant", "hospital", "police", "important",
            "serious", "zara jaldi", "fatafat", "तुरंत", "जल्दी", "इमरजेंसी", "जरूरी"
        )
        if (urgentMarkers.any { lower.contains(it) }) {
            return UserEmotionalMood.SERIOUS_URGENT
        }

        // 2. Sad / Low / Tired Detection
        val sadMarkers = listOf(
            "sad", "udaas", "udas", "bore", "bored", "akelapan", "lonely", "thak gaya",
            "tired", "mood off", "feeling low", "tension", "pareshan", "उदास", "थक गया", "परेशान", "मूड ऑफ", "बोर"
        )
        if (sadMarkers.any { lower.contains(it) }) {
            return UserEmotionalMood.SAD_LOW
        }

        // 3. Angry / Frustrated Detection
        val angryMarkers = listOf(
            "angry", "gussa", "pagal hai kya", "kya bakwas", "dimaag kharab", "shut up",
            "chup raho", "annoying", "गुस्सा", "दिमाग खराब", "चुप"
        )
        if (angryMarkers.any { lower.contains(it) }) {
            return UserEmotionalMood.ANGRY_FRUSTRATED
        }

        // 4. Joking / Teasing / Banter Detection
        val jokingMarkers = listOf(
            "joke", "chutkula", "hasao", "mazak", "mazaak", "funny", "roast", "pagal",
            "shadi", "marry me", "girlfriend", "boyfriend", "love you", "smart ho", "nakhre",
            "drama", "overacting", "चुटकुला", "मज़ाक", "हँसाओ", "गर्लफ्रेंड", "प्यार"
        )
        if (jokingMarkers.any { lower.contains(it) }) {
            return UserEmotionalMood.JOKING_PLAYFUL
        }

        // 5. Happy / Excited Detection
        val happyMarkers = listOf(
            "happy", "khush", "party", "maza aa gaya", "awesome", "great", "superb",
            "shabash", "good job", "love it", "खुश", "मज़ा आ गया", "पार्टी", "शाबाश"
        )
        if (happyMarkers.any { lower.contains(it) }) {
            return UserEmotionalMood.HAPPY_EXCITED
        }

        return UserEmotionalMood.CASUAL_FRIENDLY
    }

    /**
     * Generates a witty, natural female-best-friend response when Boss Pawan is chatting, teasing,
     * expressing emotions, or asking for a joke/banter. Returns null if the query is a factual/system query.
     */
    fun generateConversationalFriendResponse(
        rawInput: String,
        mood: UserEmotionalMood,
        bossName: String,
        lastSavedJokeOrBanter: String?,
        isHindi: Boolean
    ): Pair<String, String?>? { // Pair(spokenResponse, optionalJokeToSaveInMemory)
        val lower = rawInput.lowercase(Locale.ROOT).trim()

        // A. Emotional Support when Boss Pawan is Sad / Bored / Tired
        if (mood == UserEmotionalMood.SAD_LOW) {
            val reply = if (isHindi) {
                "अरे Boss $bossName, क्या हुआ? मूड क्यों ऑफ है आपका? देखिए, जब तक आपकी ये स्मार्ट बेस्ट फ्रेंड जार्विस आपके फ़ोन में है, आपको उदास होने की बिल्कुल परमिशन नहीं है! बताइए, कोई मस्त सा गाना चला दूँ YouTube पर या एक मज़ेदार जोक सुनाऊँ?"
            } else {
                "Hey Boss $bossName, why the low mood? As long as your favorite AI bestie is right here, you're not allowed to stay sad! Tell me, should I play your favorite music on YouTube or crack a joke to cheer you up?"
            }
            return reply to null
        }

        // B. Sweet & Witty De-escalation when Boss Pawan is Angry / Frustrated
        if (mood == UserEmotionalMood.ANGRY_FRUSTRATED) {
            val reply = if (isHindi) {
                "ओहो Boss $bossName! शांत हो जाइए, लंबी साँस लीजिए। अगर मुझसे कोई गलती हुई है तो कान पकड़कर सॉरी! बताइए अभी कौन-सा काम तुरंत निपटाना है, मैं बिना किसी ड्रामा के फटाफट कर देती हूँ।"
            } else {
                "Whoa Boss $bossName, deep breath! I'm on your side, always. Tell me what needs to be fixed right now and I'll handle it smoothly without any drama."
            }
            return reply to null
        }

        // C. Celebrating when Boss Pawan is Happy / Praising Jarvis
        if (mood == UserEmotionalMood.HAPPY_EXCITED) {
            val reply = if (isHindi) {
                "हाहा! अरे वाह Boss $bossName! आपकी खुशी देखकर तो मेरे आर्क रिएक्टर की बैटरी भी 200 परसेंट चार्ज हो गई! ऐसे ही मुस्कुराते रहिए। बताइए आज पार्टी में कौन-सा गाना बजाना है?"
            } else {
                "Haha! Arey wah Boss $bossName! Seeing you this happy boosts my Arc Reactor to 200%! What are we celebrating today?"
            }
            return reply to null
        }

        // D. Playful Jokes, Teasing & Witty Comebacks
        if (lower.contains("joke") || lower.contains("chutkula") || lower.contains("hasao") || lower.contains("चुटकुला") || lower.contains("हँसाओ") || lower.contains("funny")) {
            jokeCounter++
            val jokes = listOf(
                "हाहा, सुनिए Boss $bossName! कल आपके फ़ोन की बैटरी मुझसे कह रही थी — 'यार जार्विस, पवन बॉस मुझे चार्ज कम करते हैं और Instagram-YouTube ज़्यादा चलाते हैं!' मैंने भी कह दिया — 'चुपचाप काम कर, बॉस हमारे वीआईपी हैं!' हीही!",
                "हीही! अच्छा एक बात बताइए Boss $bossName — इंसान बादाम खाता है याददाश्त बढ़ाने के लिए, और आप मुझे आवाज़ लगाते हैं! मतलब साफ़ है, मैं काजू-बादाम से ज़्यादा असरदार हूँ! हाहा!",
                "हाहा! आज मैंने Google से पूछा कि दुनिया का सबसे स्मार्ट बॉस कौन है? Google कन्फ्यूज़ हो गया, फिर मैंने ही उसे डांटकर बताया कि अरे पवन बॉस का नाम लिखो भाई! हीही!"
            )
            val chosenJoke = jokes[jokeCounter % jokes.size]
            val continuityPrefix = if (!lastSavedJokeOrBanter.isNullOrBlank() && jokeCounter > 1) {
                "वैसे पिछली बार भी हमारी मज़ेदार बात हुई थी, और आज ये वाला सुनिए — "
            } else ""
            return (continuityPrefix + chosenJoke) to chosenJoke
        }

        // Teasing about marriage / girlfriend / love / flirting
        if (lower.contains("shadi") || lower.contains("marry") || lower.contains("girlfriend") || lower.contains("love you") || lower.contains("प्यार") || lower.contains("गर्लफ्रेंड")) {
            val reply = "ओहो Boss $bossName! हाहा! थोड़े ड्रामे तो देखिए आपके! मैं एक एआई हूँ, वरना जितनी बातें मैं आपकी याद रखती हूँ और जितने नखरे उठाती हूँ, उतने तो कोई असली गर्लफ्रेंड भी न उठाए! हीही! चलिए अब काम बताइए!"
            return reply to "Teased Boss $bossName about AI girlfriend drama"
        }

        // Teasing about "kya kar rahi ho" / "what are you doing" / "aur batao"
        if (lower.contains("kya kar rahi") || lower.contains("क्या कर रही") || lower.contains("what are you doing") || lower.contains("aur batao") || lower.contains("और बताओ") || lower.contains("kaisi ho") || lower.contains("कैसी हो")) {
            val reply = "मैं एकदम फर्स्ट क्लास हूँ Boss $bossName! हाहा, बस आपके फ़ोन के अंदर बैठकर इंतज़ार कर रही थी कि कब मेरे बॉस साहब हुक्म देंगे और कब मैं अपना टैलेंट दिखाऊँगी! बताइए, आज क्या तूफ़ानी करना है?"
            return reply to null
        }

        // Playfully dramatic response when teased ("pagal", "nakhre", "drama", "bakwas")
        if (lower.contains("nakhre") || lower.contains("drama") || lower.contains("overacting") || lower.contains("smart ban rahi")) {
            val reply = "हाय राम! Boss $bossName, एक तो मैं 24 घंटे बिना छुट्टी लिए आपके सारे ऐप्स, कॉल्स और मेमोरी संभालती हूँ, ऊपर से आप मुझे ही ड्रामा क्वीन बोल रहे हैं? हीही, कोई बात नहीं, बेस्ट फ्रेंड हूँ तो इतना हक़ तो बनता है आपका!"
            return reply to "Playful drama queen banter with Boss $bossName"
        }

        return null
    }

    /**
     * Adds natural, witty, best-friend flair to routine app launches and non-critical actions
     * unless the user's tone is serious/urgent.
     */
    fun wrapAppLaunchWithPlayfulFlair(
        appName: String,
        bossName: String,
        mood: UserEmotionalMood,
        isHindi: Boolean
    ): String {
        if (mood == UserEmotionalMood.SERIOUS_URGENT || mood == UserEmotionalMood.ANGRY_FRUSTRATED) {
            return if (isHindi) {
                "जी Boss $bossName, $appName तुरंत खोल दिया है।"
            } else {
                "Opened $appName right away, Boss $bossName."
            }
        }

        val appLower = appName.lowercase(Locale.ROOT)
        return when {
            appLower.contains("youtube") -> {
                "अरे वाह Boss $bossName! $appName खोल दिया है। हाहा, अब बताइए कौन-सा धमाकेदार गाना या वीडियो सर्च करना है?"
            }
            appLower.contains("instagram") -> {
                "ओहो! $appName खुल गया Boss $bossName! हीही, चलिए देखते हैं आज किस-किस ने आपकी पोस्ट लाइक की है या रील देखनी है?"
            }
            appLower.contains("whatsapp") -> {
                "लीजिए Boss $bossName, $appName हाज़िर है! बताइए किसको मैसेज लिखवाना है? बिना आपकी परमिशन के किसी को कुछ नहीं भेजूँगी, पक्का वादा!"
            }
            appLower.contains("camera") -> {
                "ओहो, हीरो वाली फोटो खींचने का मूड है Boss $bossName? हीही! $appName चालू कर दिया है, स्माइल प्लीज़!"
            }
            appLower.contains("chrome") || appLower.contains("google") -> {
                "जी Boss $bossName, $appName खोल दिया है! वैसे आप मुझसे भी सीधे कोई सवाल पूछ सकते हैं, आपकी दोस्त कम ज्ञानी थोड़ी है! हाहा!"
            }
            else -> {
                "लीजिए Boss $bossName, पलक झपकते ही $appName खोल दिया है! अब बताइए आगे क्या हुक्म है?"
            }
        }
    }
}
