package com.example.brain

import java.util.Locale

sealed class NluIntent {
    data object WakeWordActivate : NluIntent()
    data object SystemOff : NluIntent()
    data class OpenApp(val appQuery: String, val rawUtterance: String) : NluIntent()
    data class CloseApp(val rawUtterance: String) : NluIntent()

    // 1. YouTube Voice Control Intents
    data class YouTubeSearch(val searchQuery: String) : NluIntent()
    data class YouTubeSelectVideo(val spokenSelection: String) : NluIntent()
    data class YouTubeMediaControl(val action: String) : NluIntent() // "PAUSE", "RESUME", "NEXT", "PREVIOUS", "STOP", "VOL_UP", "VOL_DOWN", "MUTE", "SEARCH_AGAIN"

    // 2. WhatsApp Automation Intents
    data class WhatsAppSearchContact(val contactName: String) : NluIntent()
    data class PrepareWhatsAppMessage(val recipientName: String, val messageBody: String) : NluIntent()
    data object ReadWhatsAppMessages : NluIntent()

    // 3. Instagram Automation Intents
    data object InstagramCheckLikes : NluIntent()
    data object InstagramCheckMessages : NluIntent()
    data class InstagramSearchProfile(val usernameOrName: String) : NluIntent()
    data class PrepareInstagramMessage(val usernameOrName: String, val messageBody: String) : NluIntent()

    // 4. Calling, SMS & Security Confirmation Intents
    data class PlaceCall(val targetNameOrNumber: String) : NluIntent()
    data class PrepareSmsMessage(val recipientName: String, val messageBody: String) : NluIntent()
    data class ConfirmPendingAction(val isConfirmed: Boolean) : NluIntent()
    data class SensitiveOperationWarning(val operationType: String) : NluIntent() // "PAYMENT", "DELETE_DATA", "POST_CONTENT"

    // 5. General Knowledge, Date/Time & Memory Intents
    data object AskDayOfWeek : NluIntent()
    data object AskCurrentDate : NluIntent()
    data object AskCurrentTime : NluIntent()
    data object AskUserName : NluIntent()
    data object AskMemoryRecall : NluIntent()
    data class CancelTask(val taskKeyword: String) : NluIntent()
    data class GeneralOrContextualQuery(val cleanedQuery: String) : NluIntent()
}

/**
 * Module 5: Advanced Natural Language Understanding (NLU) Engine.
 * Understands Hindi, English, Hinglish, colloquial speech, imperfect grammar, and conversational context
 * for YouTube, WhatsApp, Instagram, Universal App Control, Calling, and Security Confirmations.
 */
class JarvisNluEngine {

    fun normalizeAndClean(rawInput: String): String {
        var text = rawInput.trim().lowercase(Locale.ROOT)
        val phoneticMap = mapOf(
            "यू ट्यूब" to "youtube",
            "यूट्यूब" to "youtube",
            "you tube" to "youtube",
            "utube" to "youtube",
            "yutube" to "youtube",
            "इंस्टाग्राम" to "instagram",
            "इंस्टा" to "instagram",
            "insta gram" to "instagram",
            "व्हाट्सएप" to "whatsapp",
            "व्हाट्सऐप" to "whatsapp",
            "वाट्सएप" to "whatsapp",
            "watsapp" to "whatsapp",
            "whatsup" to "whatsapp",
            "whats app" to "whatsapp",
            "क्रोम" to "chrome",
            "crome" to "chrome",
            "कैमरा" to "camera",
            "camra" to "camera",
            "गैलरी" to "gallery",
            "galery" to "gallery",
            "galary" to "gallery",
            "जीमेल" to "gmail",
            "गूगल मैप्स" to "google maps",
            "मैप्स" to "maps",
            "सेटिंग्स" to "settings",
            "सेटिंग" to "settings",
            "seting" to "settings",
            "प्ले स्टोर" to "play store",
            "playstore" to "play store",
            "कॉल" to "call",
            "फोन लगाओ" to "call",
            "कॉल लगाओ" to "call",
            "कॉल करो" to "call",
            "खोलो" to "kholo",
            "खोल दो" to "kholo",
            "चालू करो" to "chalao",
            "चलाओ" to "chalao",
            "ओपन करो" to "open karo",
            "ओपन" to "open",
            "लॉन्च करो" to "launch karo",
            "दिखाओ" to "dikhao",
            "सर्च करो" to "search karo",
            "ढूंढो" to "dhundo",
            "खोजो" to "search karo",
            "गाना" to "gana",
            "बंद करो" to "band karo",
            "रोको" to "pause",
            "आवाज़ बढ़ाओ" to "volume up",
            "आवाज़ कम करो" to "volume down",
            "हे जार्विस" to "hey jarvis",
            "हाय जार्विस" to "hey jarvis",
            "अरे जार्विस" to "hey jarvis",
            "जार्विस" to "jarvis",
            "सिस्टम ऑफ" to "system off",
            "बंद हो जाओ" to "system off"
        )
        for ((k, v) in phoneticMap) {
            text = text.replace(k, v)
        }
        return text.replace(Regex("\\s+"), " ").trim()
    }

    fun parseIntent(
        rawInput: String,
        hasPendingConfirmation: Boolean = false,
        isYouTubeSelectionActive: Boolean = false
    ): NluIntent {
        val norm = normalizeAndClean(rawInput)
        val withoutWake = norm
            .removePrefix("hey jarvis")
            .removePrefix("hi jarvis")
            .removePrefix("hello jarvis")
            .removePrefix("ok jarvis")
            .removePrefix("jarvis")
            .removePrefix("boss")
            .trim()
            .removePrefix(",")
            .trim()

        // 1. SINGLE VOICE CONTROL SYSTEM OFF ("Jarvis System Off")
        if (norm.contains("system off") ||
            norm.contains("jarvis off") ||
            withoutWake == "off" ||
            withoutWake == "stop listening" ||
            withoutWake == "so jao"
        ) {
            return NluIntent.SystemOff
        }

        // 2. Pure Wake Word ("Hey Jarvis")
        if ((norm.contains("hey jarvis") || norm == "jarvis") && withoutWake.isBlank()) {
            return NluIntent.WakeWordActivate
        }

        // 3. Confirmation for Pending WhatsApp / Instagram / Call / Sensitive Action
        if (hasPendingConfirmation) {
            if (withoutWake in listOf("haan", "ha", "yes", "bhej do", "send", "ok", "okay", "sure", "confirm", "हाँ", "भेज दो", "जी हाँ", "bhejo", "kar do", "call lagao")) {
                return NluIntent.ConfirmPendingAction(true)
            }
            if (withoutWake in listOf("nahi", "no", "cancel", "mat bhejo", "ruk jao", "नहीं", "मत भेजो", "कैंसिल", "rehne do")) {
                return NluIntent.ConfirmPendingAction(false)
            }
        }

        // 4. YouTube Playback & Search Again Controls ("Ye gana chalao", "Isko band karo", "Kuchh aur search karo", "pause", "next video", "volume")
        if (withoutWake.contains("kuchh aur search") || withoutWake.contains("kuch aur search") || withoutWake.contains("search again") || withoutWake.contains("naya search")) {
            return NluIntent.YouTubeMediaControl("SEARCH_AGAIN")
        }
        if (withoutWake.contains("ye gana chalao") || withoutWake.contains("yeh gana chalao") || withoutWake.contains("isko chalao") || withoutWake.contains("play this")) {
            return if (isYouTubeSelectionActive) {
                NluIntent.YouTubeSelectVideo(withoutWake)
            } else {
                NluIntent.YouTubeMediaControl("RESUME")
            }
        }
        if (withoutWake.contains("isko band karo") || withoutWake.contains("gana band karo") || withoutWake.contains("stop video") || withoutWake.contains("video roko")) {
            return NluIntent.YouTubeMediaControl("STOP")
        }
        if (withoutWake == "pause" || withoutWake.contains("pause karo") || withoutWake.contains("pause video")) {
            return NluIntent.YouTubeMediaControl("PAUSE")
        }
        if (withoutWake == "resume" || withoutWake.contains("resume karo") || withoutWake.contains("wapas chalao")) {
            return NluIntent.YouTubeMediaControl("RESUME")
        }
        if (withoutWake.contains("next video") || withoutWake.contains("agla gana") || withoutWake.contains("agla video") || withoutWake.contains("next song")) {
            return NluIntent.YouTubeMediaControl("NEXT")
        }
        if (withoutWake.contains("previous video") || withoutWake.contains("pichla gana") || withoutWake.contains("pichla video") || withoutWake.contains("previous song")) {
            return NluIntent.YouTubeMediaControl("PREVIOUS")
        }
        if (withoutWake.contains("volume up") || withoutWake.contains("aawaz badhao") || withoutWake.contains("awaz badhao") || withoutWake.contains("sound badhao")) {
            return NluIntent.YouTubeMediaControl("VOL_UP")
        }
        if (withoutWake.contains("volume down") || withoutWake.contains("aawaz kam") || withoutWake.contains("awaz kam") || withoutWake.contains("sound kam")) {
            return NluIntent.YouTubeMediaControl("VOL_DOWN")
        }
        if (withoutWake.contains("mute karo") || withoutWake == "mute") {
            return NluIntent.YouTubeMediaControl("MUTE")
        }

        // If YouTube search results were just read aloud and user answers with a selection ("pehla", "doosra", "teesra", "1", "2", "3")
        if (isYouTubeSelectionActive) {
            val selectionTokens = listOf("pehla", "पहला", "first", "1", "ek", "doosra", "dusra", "दूसरा", "second", "2", "do", "teesra", "tisra", "तीसरा", "third", "3", "teen", "play", "chalao")
            if (selectionTokens.any { withoutWake == it || withoutWake.contains("$it ") || withoutWake.endsWith(" $it") }) {
                return NluIntent.YouTubeSelectVideo(withoutWake)
            }
        }

        // 5. YouTube Voice Search ("YouTube par Bhojpuri gana search karo", "YouTube par latest news search karo", "search X on YouTube")
        if (withoutWake.contains("youtube") &&
            (withoutWake.contains("search") || withoutWake.contains("dhundo") || withoutWake.contains("gana") || withoutWake.contains("video") || withoutWake.contains("par ") || withoutWake.contains("pe ") || withoutWake.contains("play "))
        ) {
            val q = extractYouTubeSearchQuery(withoutWake)
            if (q.isNotBlank() && q !in listOf("open", "kholo", "chalao", "launch")) {
                return NluIntent.YouTubeSearch(q)
            }
        }

        // 6. Instagram Automation Intents
        // Who liked my posts / notifications ("Instagram par kisne like kiya", "check instagram likes", "instagram notifications")
        if (withoutWake.contains("instagram") &&
            (withoutWake.contains("like") || withoutWake.contains("notification") || withoutWake.contains("kisne"))
        ) {
            return NluIntent.InstagramCheckLikes
        }

        // Instagram message requests / read DMs ("instagram message check karo", "instagram message requests")
        if (withoutWake.contains("instagram") &&
            (withoutWake.contains("request") || withoutWake.contains("inbox") || (withoutWake.contains("message") && (withoutWake.contains("check") || withoutWake.contains("padho") || withoutWake.contains("read"))))
        ) {
            return NluIntent.InstagramCheckMessages
        }

        // Instagram dictate message ("Instagram par Rahul ko message bhejo ki...", "message X on instagram that...")
        if (withoutWake.contains("instagram") &&
            (withoutWake.contains("message") || withoutWake.contains("dm") || withoutWake.contains("मैसेज")) &&
            (withoutWake.contains("bhejo") || withoutWake.contains("send") || withoutWake.contains("ki ") || withoutWake.contains("लिखो"))
        ) {
            val (targetUser, body) = parseRecipientAndMessage(withoutWake.replace("instagram par", "").replace("on instagram", "").trim())
            return NluIntent.PrepareInstagramMessage(targetUser, body)
        }

        // Instagram search profile ("Instagram par Rahul ko dhundo", "search X on instagram", "open X profile on instagram")
        if (withoutWake.contains("instagram") &&
            (withoutWake.contains("dhundo") || withoutWake.contains("search") || withoutWake.contains("profile") || withoutWake.contains("id "))
        ) {
            val target = extractSocialSearchTarget(withoutWake, "instagram")
            if (target.isNotBlank()) {
                return NluIntent.InstagramSearchProfile(target)
            }
        }

        // 7. WhatsApp Automation Intents
        // Read incoming WhatsApp messages ("WhatsApp message padho", "read whatsapp messages", "kiska message aaya hai")
        if ((withoutWake.contains("whatsapp") || withoutWake.contains("मैसेज") || withoutWake.contains("message")) &&
            (withoutWake.contains("padho") || withoutWake.contains("read") || withoutWake.contains("kiska message") || withoutWake.contains("incoming") || withoutWake.contains("check message"))
        ) {
            return NluIntent.ReadWhatsAppMessages
        }

        // Search contact / open chat on WhatsApp ("WhatsApp par Rahul ko dhundo", "open Amit chat on WhatsApp")
        if (withoutWake.contains("whatsapp") &&
            (withoutWake.contains("dhundo") || withoutWake.contains("search") || withoutWake.contains("chat kholo")) &&
            !withoutWake.contains("bhejo") && !withoutWake.contains("ki ")
        ) {
            val target = extractSocialSearchTarget(withoutWake, "whatsapp")
            if (target.isNotBlank()) {
                return NluIntent.WhatsAppSearchContact(target)
            }
        }

        // Dictate & Send WhatsApp / SMS message ("Boss, Amit ko message bhejo ki main kal aaunga", "Rahul ko WhatsApp karo ki...")
        if ((withoutWake.contains("whatsapp") || withoutWake.contains("message") || withoutWake.contains("मैसेज") || withoutWake.contains("संदेश")) &&
            (withoutWake.contains("bhejo") || withoutWake.contains("send") || withoutWake.contains("karo") || withoutWake.contains("likho") || withoutWake.contains("भेजो") || withoutWake.contains("ki "))
        ) {
            val isSms = withoutWake.contains("sms") || withoutWake.contains("text message")
            val parsed = parseRecipientAndMessage(withoutWake)
            return if (isSms) {
                NluIntent.PrepareSmsMessage(parsed.first, parsed.second)
            } else {
                NluIntent.PrepareWhatsAppMessage(parsed.first, parsed.second)
            }
        }

        // 8. Security & Confirmation Guard for Payments, Deleting Data, or Posting Content
        if (withoutWake.contains("payment karo") || withoutWake.contains("paise bhejo") || withoutWake.contains("transfer money")) {
            return NluIntent.SensitiveOperationWarning("PAYMENT")
        }
        if (withoutWake.contains("delete all") || withoutWake.contains("sab delete karo") || withoutWake.contains("data delete")) {
            return NluIntent.SensitiveOperationWarning("DELETE_DATA")
        }

        // 9. Date, Day, Time Intents
        if (withoutWake.contains("कौन-सा दिन") ||
            withoutWake.contains("कौन सा दिन") ||
            withoutWake.contains("kaun sa din") ||
            withoutWake.contains("kaunsa din") ||
            withoutWake.contains("what day") ||
            withoutWake.contains("which day") ||
            withoutWake.contains("aaj kya din hai") ||
            withoutWake.contains("आज क्या दिन है")
        ) {
            return NluIntent.AskDayOfWeek
        }

        if (withoutWake.contains("तारीख") ||
            withoutWake.contains("tarikh") ||
            withoutWake.contains("tareekh") ||
            withoutWake.contains("date kya hai") ||
            withoutWake.contains("today's date") ||
            withoutWake.contains("what is the date") ||
            withoutWake.contains("aaj date")
        ) {
            return NluIntent.AskCurrentDate
        }

        if (withoutWake.contains("समय") ||
            withoutWake.contains("samay") ||
            withoutWake.contains("kitne baje") ||
            withoutWake.contains("कितने बजे") ||
            withoutWake.contains("time kya") ||
            withoutWake.contains("what time") ||
            withoutWake.contains("current time") ||
            withoutWake == "time"
        ) {
            return NluIntent.AskCurrentTime
        }

        // 10. Personal Memory Recall Intents
        if (withoutWake.contains("मेरा नाम क्या") ||
            withoutWake.contains("mera naam kya") ||
            withoutWake.contains("boss ka naam kya") ||
            withoutWake.contains("what is my name") ||
            withoutWake.contains("who am i") ||
            withoutWake.contains("main kaun hoon")
        ) {
            return NluIntent.AskUserName
        }

        if (withoutWake.contains("पहले क्या बताया") ||
            withoutWake.contains("क्या बताया था") ||
            withoutWake.contains("pehle kya bataya") ||
            withoutWake.contains("kya bataya tha") ||
            withoutWake.contains("kya yaad hai") ||
            withoutWake.contains("क्या याद है") ||
            withoutWake.contains("what did i tell you") ||
            withoutWake.contains("what do you remember") ||
            withoutWake.contains("meri pasand kya hai") ||
            withoutWake.contains("मेरी पसंद क्या है")
        ) {
            return NluIntent.AskMemoryRecall
        }

        // 11. Calling Intents ("राहुल को कॉल करो", "call rahul")
        if ((withoutWake.contains("call") || withoutWake.contains("phone lagao") || withoutWake.contains("baat karao") || withoutWake.contains("dial")) &&
            !withoutWake.contains("truecaller") && !withoutWake.contains("call status")
        ) {
            val target = extractCallTarget(withoutWake)
            if (target.isNotBlank()) {
                return NluIntent.PlaceCall(target)
            }
        }

        // 12. Task Cancellation
        if (withoutWake.contains("cancel task") || withoutWake.contains("task cancel") || withoutWake.contains("kaam roko")) {
            return NluIntent.CancelTask(withoutWake)
        }

        // 13. Universal App Control
        val appTarget = detectAppTargetFromNaturalSpeech(withoutWake)
        if (appTarget != null) {
            return NluIntent.OpenApp(appTarget, rawInput)
        }

        // 14. Close Active App
        if (withoutWake.contains("close app") || withoutWake.contains("app band karo") || withoutWake == "band karo" || withoutWake == "wapas aao") {
            return NluIntent.CloseApp(rawInput)
        }

        return NluIntent.GeneralOrContextualQuery(withoutWake.ifBlank { norm })
    }

    private fun extractYouTubeSearchQuery(text: String): String {
        return text
            .replace("youtube par", "")
            .replace("youtube pe", "")
            .replace("on youtube", "")
            .replace("in youtube", "")
            .replace("youtube", "")
            .replace("search karo", "")
            .replace("search", "")
            .replace("dhundo", "")
            .replace("play karo", "")
            .replace("chalao", "")
            .replace("kholo", "")
            .replace("open karo", "")
            .trim()
    }

    private fun extractSocialSearchTarget(text: String, platform: String): String {
        return text
            .replace("$platform par", "")
            .replace("$platform pe", "")
            .replace("on $platform", "")
            .replace(platform, "")
            .replace("ko dhundo", "")
            .replace("dhundo", "")
            .replace("search karo", "")
            .replace("search", "")
            .replace("ki profile kholo", "")
            .replace("profile kholo", "")
            .replace("chat kholo", "")
            .replace("profile", "")
            .replace("ko", "")
            .trim()
    }

    private fun detectAppTargetFromNaturalSpeech(text: String): String? {
        val knownApps = listOf(
            "youtube" to listOf("youtube", "yt", "you tube"),
            "instagram" to listOf("instagram", "insta"),
            "whatsapp" to listOf("whatsapp", "whats app", "watsapp"),
            "chrome" to listOf("chrome", "browser", "google chrome"),
            "camera" to listOf("camera", "photo khincho", "selfie"),
            "gallery" to listOf("gallery", "photos", "photo album", "tasveer"),
            "gmail" to listOf("gmail", "email app", "mail app"),
            "maps" to listOf("google maps", "maps", "map", "navigation"),
            "settings" to listOf("settings", "setting", "phone ki settings", "phone settings"),
            "play store" to listOf("play store", "playstore", "google play"),
            "calculator" to listOf("calculator", "calc", "hisab"),
            "telegram" to listOf("telegram"),
            "snapchat" to listOf("snapchat"),
            "gpay" to listOf("gpay", "google pay"),
            "phonepe" to listOf("phonepe", "phone pe"),
            "flipkart" to listOf("flipkart"),
            "free fire" to listOf("free fire", "freefire")
        )

        val launchVerbs = listOf(
            "open", "kholo", "khol do", "khol", "launch", "chalao", "chalu", "start",
            "dikhao", "dikha do", "lagao", "chala do", "app"
        )

        val hasLaunchVerb = launchVerbs.any { text.contains(it) }

        for ((canonicalApp, aliases) in knownApps) {
            if (aliases.any { alias -> text.contains(alias) }) {
                if (hasLaunchVerb || text.split(" ").size <= 5) {
                    return canonicalApp
                }
            }
        }
        return null
    }

    private fun extractCallTarget(text: String): String {
        return text
            .replace("ab ", "")
            .replace("now ", "")
            .replace("mujhe ", "")
            .replace("zara ", "")
            .replace("turant ", "")
            .replace("ko call karo", "")
            .replace("ko call lagao", "")
            .replace("ko phone lagao", "")
            .replace("ko phone karo", "")
            .replace("call lagao", "")
            .replace("call karo", "")
            .replace("phone lagao", "")
            .replace("make a call to", "")
            .replace("call to", "")
            .replace("call ", "")
            .replace("dial ", "")
            .replace("ko ", "")
            .replace("से बात कराओ", "")
            .replace("को", "")
            .trim()
    }

    private fun parseRecipientAndMessage(text: String): Pair<String, String> {
        // e.g., "amit ko message bhejo ki main kal aaunga"
        val clean = text
            .replace("whatsapp par", "")
            .replace("whatsapp pe", "")
            .replace("on whatsapp", "")
            .trim()

        val recipient = if (clean.contains(" ko ")) {
            clean.substringBefore(" ko ").trim().split(" ").lastOrNull() ?: "Contact"
        } else {
            clean.split(" ").firstOrNull() ?: "Contact"
        }

        val body = when {
            clean.contains(" ki ") -> clean.substringAfter(" ki ").trim()
            clean.contains(" कि ") -> clean.substringAfter(" कि ").trim()
            clean.contains(" that ") -> clean.substringAfter(" that ").trim()
            else -> {
                clean.substringAfter("bhejo", "")
                    .substringAfter("send", "")
                    .trim()
                    .ifBlank { "नमस्ते, मैं पवन बोल रहा हूँ।" }
            }
        }
        return recipient to body
    }
}
