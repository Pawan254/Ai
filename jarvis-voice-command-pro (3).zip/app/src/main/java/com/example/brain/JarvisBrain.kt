package com.example.brain

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import com.example.memory.JarvisMemoryRepository
import com.example.model.AppItem
import com.example.model.AppRegistry
import com.example.model.DirectivePriority
import com.example.model.HoloTheme
import com.example.model.ReactorStyle
import com.example.model.TacticalDirective
import com.example.model.TelemetryData
import com.example.service.JarvisNotificationListenerService
import com.example.tasks.JarvisTaskManager
import com.example.tasks.TaskPriority
import java.util.Locale

sealed class JarvisCommandResult {
    data class Response(val text: String, val badge: String? = null) : JarvisCommandResult()
    data class SystemModeChanged(val isSystemActive: Boolean, val text: String, val badge: String) : JarvisCommandResult()
    data class ChangeTheme(val theme: HoloTheme, val text: String) : JarvisCommandResult()
    data class ChangeReactorStyle(val style: ReactorStyle, val text: String) : JarvisCommandResult()
    data class SetOverdrive(val enabled: Boolean, val text: String) : JarvisCommandResult()
    data class AddDirective(val directive: TacticalDirective, val text: String) : JarvisCommandResult()
    data class OpenTab(val tabIndex: Int, val text: String) : JarvisCommandResult()
    data class OpenAppSubsystem(val app: AppItem, val text: String, val launchedExternal: Boolean = true) : JarvisCommandResult()
    data class CloseActiveApp(val text: String) : JarvisCommandResult()
    data class CallResult(
        val resolution: CallResolutionResult,
        val text: String,
        val badge: String
    ) : JarvisCommandResult()
    data class MessageConfirmationPrompt(
        val pending: PendingOutgoingMessage,
        val text: String,
        val badge: String
    ) : JarvisCommandResult()
    data class YouTubeSearchResults(
        val query: String,
        val items: List<YouTubeVideoItem>,
        val text: String,
        val badge: String = "YOUTUBE SEARCH"
    ) : JarvisCommandResult()
    data class MultiCommandBatch(
        val subResults: List<JarvisCommandResult>,
        val combinedSpeech: String,
        val badge: String
    ) : JarvisCommandResult()
}

/**
 * Unified AI Brain — One Jarvis, One Memory, One Voice, One Intelligence, and One Witty Female Best-Friend Personality.
 * Coordinates NLU, Permanent Memory (Boss Pawan + Joke/Banter Continuity), Personality & Mood Engine,
 * YouTube Voice Controller, WhatsApp & Call Automation, Instagram Controller, Universal App Control,
 * Date/Time/Knowledge Engine, and Parallel Task Execution.
 */
class JarvisBrain(
    private val context: Context,
    val memoryRepository: JarvisMemoryRepository = JarvisMemoryRepository(context),
    val callSystem: JarvisCallSystem = JarvisCallSystem(context),
    val youTubeController: JarvisYouTubeController = JarvisYouTubeController(context),
    val instagramController: JarvisInstagramController = JarvisInstagramController(context),
    val taskManager: JarvisTaskManager = JarvisTaskManager(),
    val nluEngine: JarvisNluEngine = JarvisNluEngine(),
    val knowledgeEngine: JarvisKnowledgeEngine = JarvisKnowledgeEngine(),
    val personalityEngine: JarvisPersonalityEngine = JarvisPersonalityEngine()
) {

    fun getLiveTelemetry(): TelemetryData {
        val batteryFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus: Intent? = context.registerReceiver(null, batteryFilter)

        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = if (level >= 0 && scale > 0) ((level / scale.toFloat()) * 100).toInt() else 85

        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        val runtime = Runtime.getRuntime()
        val usedMemMb = ((runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)).toInt()

        return TelemetryData(
            batteryPct = batteryPct,
            isCharging = isCharging,
            memoryUsageMb = 320 + (usedMemMb % 120),
            coreTempC = 33.4f + (batteryPct % 5) * 0.4f,
            coreOutputMw = 3.2f + (if (isCharging) 1.5f else 0.0f),
            rpm = 14200 + (batteryPct * 20),
            latencyMs = 12 + (System.currentTimeMillis() % 15).toInt(),
            networkStatus = "WITTY FEMALE AI // BOSS PAWAN"
        )
    }

    fun normalizePronunciation(raw: String): String = nluEngine.normalizeAndClean(raw)

    private fun splitMultiCommands(normalizedInput: String): List<String> {
        val clean = normalizedInput
            .removePrefix("hey jarvis")
            .removePrefix("jarvis")
            .trim()

        val parts = clean.split(Regex("\\s+(?:aur phir|aur ab|uske baad|and then|and also|aur sath me|aur|तथा|और फिर|और)\\s+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }

        if (parts.size <= 1) return listOf(clean)

        val actionKeywords = listOf("open", "kholo", "chalao", "launch", "start", "dikhao", "call", "lagao", "chalu", "band", "close", "theme", "overdrive", "yaad", "remember", "battery", "status", "time", "din", "tarikh", "राजधानी", "search")
        val actionableCount = parts.count { part -> actionKeywords.any { kw -> part.contains(kw) } }
        return if (actionableCount >= 2) parts else listOf(clean)
    }

    private fun isRunningOnVirtualDevice(): Boolean {
        val fp = Build.FINGERPRINT.lowercase(Locale.ROOT)
        val model = Build.MODEL.lowercase(Locale.ROOT)
        val product = Build.PRODUCT.lowercase(Locale.ROOT)
        return fp.contains("generic") ||
            fp.contains("emulator") ||
            fp.contains("sdk_gphone") ||
            model.contains("sdk") ||
            model.contains("emulator") ||
            product.contains("sdk") ||
            product.contains("emulator")
    }

    fun launchDeviceAppDirectly(app: AppItem): Boolean {
        // On the virtual device preview, keep the user inside the interactive Jarvis HUD Subsystem Sheet
        // unless they explicitly tap the "LAUNCH EXTERNAL APP" button inside the sheet.
        if (isRunningOnVirtualDevice()) {
            return false
        }
        return try {
            val pm = context.packageManager
            val directIntent = pm.getLaunchIntentForPackage(app.packageName)
            if (directIntent != null) {
                directIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(directIntent)
                return true
            }

            val fallbackIntent: Intent? = when (app.id) {
                "camera" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                "photos", "ai_gallery" -> Intent(Intent.ACTION_VIEW).apply {
                    type = "image/*"
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                "settings" -> Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                "play_store" -> Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=apps")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                "chrome", "google" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                "youtube" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                "instagram" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                "whatsapp" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                "gmail" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://mail.google.com")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                "phone", "contacts" -> Intent(Intent.ACTION_DIAL).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                "maps" -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=India")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                else -> null
            }

            if (fallbackIntent != null) {
                context.startActivity(fallbackIntent)
                true
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun processVoiceCommandWithMemoryAndTasks(
        rawInput: String,
        currentTheme: HoloTheme,
        isHindi: Boolean = true
    ): JarvisCommandResult {
        val normalized = nluEngine.normalizeAndClean(rawInput)
        val bossName = memoryRepository.getUserName() // Defaults to "Pawan"
        val userMood = personalityEngine.detectUserMood(rawInput)

        val hasAnyPendingConfirm = callSystem.hasAnyPendingConfirmation || instagramController.pendingInstagramMessage != null

        val topIntent = nluEngine.parseIntent(
            rawInput = rawInput,
            hasPendingConfirmation = hasAnyPendingConfirm,
            isYouTubeSelectionActive = youTubeController.isAwaitingVideoSelection
        )

        // 0. Check Single Voice Control System ON / OFF
        if (topIntent is NluIntent.WakeWordActivate) {
            val greeting = "जी, बताइए।"
            memoryRepository.logInteraction(rawInput, greeting, "SYSTEM ON (WAKE WORD)")
            return JarvisCommandResult.SystemModeChanged(
                isSystemActive = true,
                text = greeting,
                badge = "SYSTEM ON // जी, बताइए"
            )
        }

        if (topIntent is NluIntent.SystemOff) {
            val offMsg = if (isHindi) {
                "अच्छा ठीक है Boss $bossName, Active Mode बंद कर रही हूँ। जब भी मेरी याद आए या काम हो, बस 'Hey Jarvis' बोल दीजिएगा!"
            } else {
                "Alright Boss $bossName, going into Standby Mode. Just say 'Hey Jarvis' whenever you miss me or need anything!"
            }
            memoryRepository.logInteraction(rawInput, offMsg, "JARVIS SYSTEM OFF")
            return JarvisCommandResult.SystemModeChanged(
                isSystemActive = false,
                text = offMsg,
                badge = "SYSTEM OFF // WAKE WORD STANDBY"
            )
        }

        // 1. Check Confirmation for Pending WhatsApp / SMS / Instagram / Phone Call (Remain focused & friendly)
        if (topIntent is NluIntent.ConfirmPendingAction) {
            callSystem.pendingMessageConfirmation?.let { pendingMsg ->
                return if (topIntent.isConfirmed) {
                    callSystem.executeConfirmedPendingMessage()
                    val msg = if (isHindi) {
                        "डन Boss $bossName! मैंने ${pendingMsg.recipientName} के लिए ${if (pendingMsg.isWhatsApp) "WhatsApp" else "SMS"} संदेश खोलकर तैयार कर दिया है। अब बताइए अगला काम क्या है?"
                    } else {
                        "Done Boss $bossName! I have opened the message to ${pendingMsg.recipientName}. What's next?"
                    }
                    memoryRepository.logInteraction(rawInput, msg, "MESSAGE CONFIRMED")
                    JarvisCommandResult.Response(msg, badge = "MESSAGE DISPATCHED")
                } else {
                    callSystem.clearPendingMessage()
                    val msg = if (isHindi) {
                        "ओके Boss $bossName, मैसेज कैंसिल कर दिया! आपकी मर्ज़ी के बिना एक शब्द भी आगे नहीं जाएगा।"
                    } else {
                        "Alright Boss $bossName, message cancelled!"
                    }
                    memoryRepository.logInteraction(rawInput, msg, "MESSAGE CANCELLED")
                    JarvisCommandResult.Response(msg, badge = "CANCELLED")
                }
            }

            instagramController.pendingInstagramMessage?.let { pendingIg ->
                return if (topIntent.isConfirmed) {
                    instagramController.executeConfirmedInstagramMessage()
                    val msg = if (isHindi) {
                        "डन Boss $bossName! मैंने Instagram पर @${pendingIg.username} की प्रोफ़ाइल और चैट विंडो खोल दी है।"
                    } else {
                        "Opened @${pendingIg.username} on Instagram for messaging, Boss $bossName."
                    }
                    memoryRepository.logInteraction(rawInput, msg, "INSTAGRAM DM CONFIRMED")
                    JarvisCommandResult.Response(msg, badge = "INSTAGRAM DM")
                } else {
                    instagramController.clearPendingMessage()
                    val msg = if (isHindi) {
                        "ठीक है Boss $bossName, Instagram मैसेज रोक दिया गया है।"
                    } else {
                        "Cancelled the Instagram message, Boss $bossName."
                    }
                    memoryRepository.logInteraction(rawInput, msg, "INSTAGRAM CANCELLED")
                    JarvisCommandResult.Response(msg, badge = "CANCELLED")
                }
            }

            callSystem.pendingCallConfirmation?.let { pendingCall ->
                return if (topIntent.isConfirmed) {
                    callSystem.executeConfirmedPendingCall()
                    val msg = if (isHindi) {
                        "जी Boss $bossName, ${pendingCall.name} (${pendingCall.phoneNumber}) को कॉल लगा दिया है।"
                    } else {
                        "Calling ${pendingCall.name} now, Boss $bossName."
                    }
                    memoryRepository.logInteraction(rawInput, msg, "CALL CONFIRMED")
                    JarvisCommandResult.CallResult(
                        CallResolutionResult.CallStarted(pendingCall, directCall = true),
                        msg,
                        "CALLING ${pendingCall.name.uppercase()}"
                    )
                } else {
                    callSystem.clearPendingCall()
                    val msg = if (isHindi) {
                        "ठीक है Boss $bossName, कॉल कैंसिल कर दिया है।"
                    } else {
                        "Call cancelled, Boss $bossName."
                    }
                    memoryRepository.logInteraction(rawInput, msg, "CALL CANCELLED")
                    JarvisCommandResult.Response(msg, badge = "CALL CANCELLED")
                }
            }
        }

        // 2. Check if there is a pending contact disambiguation from a previous call or WhatsApp command
        val disambiguationChoice = callSystem.resolveDisambiguationBySpokenChoice(normalized)
        if (disambiguationChoice != null) {
            return when (disambiguationChoice) {
                is CallResolutionResult.CallConfirmationNeeded -> {
                    val c = disambiguationChoice.contact
                    val msg = if (isHindi) {
                        "Boss $bossName, क्या मैं ${c.name} (${c.phoneNumber}) को कॉल लगा दूँ? कृपया 'हाँ' या 'नहीं' बोलिए।"
                    } else {
                        "Boss $bossName, should I call ${c.name} (${c.phoneNumber})? Please say 'Yes' or 'No'."
                    }
                    JarvisCommandResult.CallResult(disambiguationChoice, msg, "CONFIRM CALL")
                }
                is CallResolutionResult.CallStarted -> {
                    val pendingMsg = callSystem.pendingMessageConfirmation
                    if (pendingMsg != null) {
                        val msg = if (isHindi) {
                            "Boss $bossName, मैंने ${pendingMsg.recipientName} के लिए संदेश लिखा है: '${pendingMsg.messageBody}'। क्या मैं इसे भेज दूँ?"
                        } else {
                            "Boss $bossName, I drafted for ${pendingMsg.recipientName}: '${pendingMsg.messageBody}'. Should I send it?"
                        }
                        JarvisCommandResult.MessageConfirmationPrompt(pendingMsg, msg, "CONFIRM WHATSAPP")
                    } else {
                        val c = disambiguationChoice.contact
                        val msg = "जी Boss $bossName, ${c.name} को कॉल लगा रही हूँ।"
                        JarvisCommandResult.CallResult(disambiguationChoice, msg, "CALLING ${c.name.uppercase()}")
                    }
                }
                else -> JarvisCommandResult.Response("जी Boss $bossName।")
            }
        }

        // 3. Sensitive Information Guard
        if (memoryRepository.containsSensitiveData(rawInput)) {
            val msg = if (isHindi) {
                "अरे नहीं Boss $bossName! पासवर्ड, ओटीपी या पिन जैसी सीक्रेट चीज़ें मुझे मत बताइए — आपकी सुरक्षा मेरे लिए सबसे ज़रूरी है, इसलिए मैं इन्हें कभी सेव या शेयर नहीं करती।"
            } else {
                "Hold on Boss $bossName! For your safety, I never store or share passwords, OTPs, or private banking PINs."
            }
            return JarvisCommandResult.Response(msg, badge = "SECURITY SHIELD")
        }

        // 4. Auto-extract personal facts/preferences/habits into Permanent Memory
        val savedMemory = memoryRepository.autoExtractAndSaveMemory(rawInput)
        if (savedMemory != null) {
            taskManager.submitParallelTask(
                title = "Memory: ${savedMemory.label}",
                commandText = rawInput,
                category = "MEMORY_OP",
                priority = TaskPriority.NORMAL
            ) {
                "Saved to permanent Room storage: ${savedMemory.value}"
            }
            val isPureMemoryStatement = normalized.contains("mera naam") ||
                normalized.contains("मेरा नाम") ||
                normalized.contains("boss ka naam") ||
                normalized.contains("my name is") ||
                normalized.contains("call me") ||
                normalized.contains("pasand hai") ||
                normalized.contains("पसंद है") ||
                normalized.contains("yaad rakh") ||
                normalized.contains("याद रख") ||
                normalized.contains("remember") ||
                normalized.contains("aadat") ||
                normalized.contains("आदत") ||
                normalized.contains("memory update")
            if (isPureMemoryStatement) {
                val updatedBossName = if (savedMemory.key == "user_name") savedMemory.value else bossName
                val msg = if (isHindi) {
                    "ओके Boss $updatedBossName! हीही, मैंने अपनी परमानेंट मेमोरी में ताला लगाकर सेव कर लिया है: '${savedMemory.label} - ${savedMemory.value}'। मजाल है कि आपकी ये दोस्त कभी कुछ भूल जाए!"
                } else {
                    "Locked into my permanent memory, Boss $updatedBossName: '${savedMemory.label} - ${savedMemory.value}'! Your AI bestie never forgets."
                }
                memoryRepository.logInteraction(rawInput, msg, "MEMORY SAVED: ${savedMemory.key}")
                return JarvisCommandResult.Response(msg, badge = "MEMORY SAVED")
            }
        }

        // 5. Check for compound multi-commands
        val segments = splitMultiCommands(normalized)
        if (segments.size > 1) {
            val subResults = mutableListOf<JarvisCommandResult>()
            val speechParts = mutableListOf<String>()

            for (segment in segments) {
                val subRes = executeSingleSegment(segment, currentTheme, isHindi, bossName, userMood)
                subResults.add(subRes)
                speechParts.add(extractSpeechText(subRes))
            }

            val combinedSpeech = speechParts.joinToString(" ")
            memoryRepository.logInteraction(rawInput, combinedSpeech, "MULTI-TASK (${segments.size} PARALLEL)")
            return JarvisCommandResult.MultiCommandBatch(
                subResults = subResults,
                combinedSpeech = combinedSpeech,
                badge = "${segments.size} TASKS PARALLEL"
            )
        }

        // 6. Single command execution
        val singleResult = executeSingleSegment(rawInput, currentTheme, isHindi, bossName, userMood)
        val speechText = extractSpeechText(singleResult)
        memoryRepository.logInteraction(rawInput, speechText, singleResult::class.simpleName ?: "COMMAND")
        return singleResult
    }

    private suspend fun executeSingleSegment(
        rawSegment: String,
        currentTheme: HoloTheme,
        isHindi: Boolean,
        bossName: String,
        userMood: UserEmotionalMood = UserEmotionalMood.CASUAL_FRIENDLY
    ): JarvisCommandResult {
        val intent = nluEngine.parseIntent(
            rawInput = rawSegment,
            hasPendingConfirmation = callSystem.hasAnyPendingConfirmation || instagramController.pendingInstagramMessage != null,
            isYouTubeSelectionActive = youTubeController.isAwaitingVideoSelection
        )

        return when (intent) {
            is NluIntent.WakeWordActivate -> {
                JarvisCommandResult.SystemModeChanged(true, "जी, बताइए।", "SYSTEM ON // जी, बताइए")
            }
            is NluIntent.SystemOff -> {
                val msg = if (isHindi) "Active Assistant Mode बंद कर दिया गया है, Boss $bossName।" else "Active mode off, Boss $bossName."
                JarvisCommandResult.SystemModeChanged(false, msg, "SYSTEM OFF")
            }

            // 1. YOUTUBE VOICE CONTROL
            is NluIntent.YouTubeSearch -> {
                val results = youTubeController.searchYouTubeVideos(intent.searchQuery)
                val summaryList = results.take(3).joinToString(", ") { "${it.index}) ${it.title} (${it.channelName})" }
                val msg = if (isHindi) {
                    "अरे वाह Boss $bossName, बढ़िया चॉइस है! मैंने YouTube पर '${intent.searchQuery}' ढूंढ लिया है। टॉप रिज़ल्ट्स हैं: $summaryList। Boss, इनमें से कौन-सा प्ले करना है?"
                } else {
                    "Great choice Boss $bossName! Top YouTube results for '${intent.searchQuery}' are: $summaryList. Boss, inmein se kaunsa play karna hai?"
                }
                taskManager.submitParallelTask(
                    title = "YouTube Search: ${intent.searchQuery}",
                    commandText = rawSegment,
                    category = "APP_LAUNCH",
                    priority = TaskPriority.HIGH
                ) {
                    "Found ${results.size} videos for '${intent.searchQuery}'"
                }
                JarvisCommandResult.YouTubeSearchResults(intent.searchQuery, results, msg)
            }

            is NluIntent.YouTubeSelectVideo -> {
                val chosen = youTubeController.resolveVideoSelection(intent.spokenSelection)
                if (chosen != null) {
                    youTubeController.playVideoItem(chosen)
                    val msg = if (isHindi) {
                        "ये हुई न बात Boss $bossName! '${chosen.title}' (${chosen.channelName}) चला रही हूँ। एन्जॉय कीजिए, और जब भी बदलना हो तो बस 'Next video', 'Pause', 'Isko band karo' या 'Kuchh aur search karo' बोल दीजिएगा!"
                    } else {
                        "Playing '${chosen.title}' by ${chosen.channelName} on YouTube, Boss $bossName!"
                    }
                    JarvisCommandResult.Response(msg, badge = "PLAYING YOUTUBE")
                } else {
                    val msg = if (isHindi) {
                        "Boss $bossName, ज़रा नंबर बताइए न — जैसे 'पहला', 'दूसरा', या 'तीसरा' कौन-सा चलाऊँ?"
                    } else {
                        "Boss $bossName, just tell me the number — 'First', 'Second', or 'Third'?"
                    }
                    JarvisCommandResult.Response(msg, badge = "SELECT VIDEO")
                }
            }

            is NluIntent.YouTubeMediaControl -> {
                when (intent.action) {
                    "PAUSE" -> {
                        youTubeController.pausePlayback()
                        JarvisCommandResult.Response("जी Boss $bossName, वीडियो पॉज़ कर दिया है।", badge = "PAUSED")
                    }
                    "RESUME" -> {
                        youTubeController.resumePlayback()
                        JarvisCommandResult.Response("चलिए Boss $bossName, वीडियो फिर से चालू कर दिया है!", badge = "PLAYING")
                    }
                    "STOP" -> {
                        youTubeController.stopPlayback()
                        youTubeController.clearSearchSession()
                        JarvisCommandResult.Response("जी Boss $bossName, इसको बंद कर दिया है। अब बताइए अगला क्या प्रोग्राम है?", badge = "STOPPED")
                    }
                    "NEXT" -> {
                        val nextItem = youTubeController.playNextResult()
                        val msg = if (nextItem != null) {
                            "जी Boss $bossName, अगला वीडियो '${nextItem.title}' चला रही हूँ।"
                        } else {
                            "जी Boss $bossName, अगला ट्रैक चला दिया है।"
                        }
                        JarvisCommandResult.Response(msg, badge = "NEXT VIDEO")
                    }
                    "PREVIOUS" -> {
                        val prevItem = youTubeController.playPreviousResult()
                        val msg = if (prevItem != null) {
                            "जी Boss $bossName, पिछला वीडियो '${prevItem.title}' चला रही हूँ।"
                        } else {
                            "जी Boss $bossName, पिछला ट्रैक चला दिया है।"
                        }
                        JarvisCommandResult.Response(msg, badge = "PREVIOUS VIDEO")
                    }
                    "VOL_UP" -> {
                        val lvl = youTubeController.adjustVolume(increase = true)
                        JarvisCommandResult.Response("ओके Boss $bossName, आवाज़ बढ़ाकर $lvl कर दी है!", badge = "VOLUME $lvl")
                    }
                    "VOL_DOWN" -> {
                        val lvl = youTubeController.adjustVolume(increase = false)
                        JarvisCommandResult.Response("जी Boss $bossName, आवाज़ कम करके $lvl कर दी है।", badge = "VOLUME $lvl")
                    }
                    "MUTE" -> {
                        youTubeController.adjustVolume(increase = false, mute = true)
                        JarvisCommandResult.Response("Boss $bossName, साउंड एकदम साइलेंट (म्यूट) कर दिया है।", badge = "MUTED")
                    }
                    "SEARCH_AGAIN" -> {
                        youTubeController.clearSearchSession()
                        JarvisCommandResult.Response("हाँजी Boss $bossName, बताइए अब YouTube पर क्या नया ढूंढना है?", badge = "YOUTUBE READY")
                    }
                    else -> JarvisCommandResult.Response("जी Boss $bossName।")
                }
            }

            // 2. WHATSAPP AUTOMATION
            is NluIntent.WhatsAppSearchContact -> {
                val res = callSystem.openWhatsAppChatForContact(intent.contactName)
                when (res) {
                    is CallResolutionResult.CallStarted -> {
                        val msg = "लीजिए Boss $bossName, मैंने WhatsApp पर ${res.contact.name} की चैट खोल दी है। क्या कोई मैसेज लिखवाना है?"
                        JarvisCommandResult.Response(msg, badge = "WHATSAPP CHAT")
                    }
                    is CallResolutionResult.DisambiguationNeeded -> {
                        val opts = res.matches.mapIndexed { i, c -> "${i + 1}) ${c.name}" }.joinToString(", ")
                        val msg = "Boss $bossName, '${res.queryName}' नाम के ${res.matches.size} लोग आपके कॉन्टैक्ट्स में हैं: $opts। इनमें से किससे बात करनी है?"
                        JarvisCommandResult.CallResult(res, msg, "WHICH CONTACT?")
                    }
                    is CallResolutionResult.ContactNotFound -> {
                        val msg = "Boss $bossName, आपके कॉन्टैक्ट्स में '${res.queryName}' नाम तो नहीं मिला, पर मैंने WhatsApp खोल दिया है। आप चाहें तो पूरा नाम या नंबर बता दीजिए।"
                        JarvisCommandResult.Response(msg, badge = "WHATSAPP OPENED")
                    }
                    else -> JarvisCommandResult.Response("Boss $bossName, कृपया Contacts permission दे दीजिए ताकि मैं नंबर ढूंढ सकूँ।")
                }
            }

            is NluIntent.ReadWhatsAppMessages -> {
                val hasAccess = JarvisNotificationListenerService.isNotificationAccessEnabled(context)
                val msgs = JarvisNotificationListenerService.getWhatsAppMessagesSummary()
                val text = if (msgs.isNotEmpty()) {
                    "Boss $bossName, आपके ताज़ा WhatsApp मैसेज ये रहे: ${msgs.take(4).joinToString("; ")}। बताइए किसी को रिप्लाई करना है क्या?"
                } else if (!hasAccess) {
                    "Boss $bossName, आने वाले WhatsApp संदेश पढ़ने के लिए Settings में Notification Access की अनुमति ज़रूरी है।"
                } else {
                    "Boss $bossName, अभी तक कोई नया WhatsApp नोटिफिकेशन नहीं आया है।"
                }
                JarvisCommandResult.Response(text, badge = "WHATSAPP INBOX")
            }

            is NluIntent.PrepareWhatsAppMessage -> {
                // Serious & precise confirmation for messaging so no wrong contact ever gets a message
                val stageRes = callSystem.stagePendingMessage(intent.recipientName, intent.messageBody, isWhatsApp = true)
                if (stageRes is CallResolutionResult.DisambiguationNeeded) {
                    val opts = stageRes.matches.mapIndexed { i, c -> "${i + 1}) ${c.name}" }.joinToString(", ")
                    val msg = "Boss $bossName, '${stageRes.queryName}' नाम के कई कॉन्टैक्ट्स हैं: $opts। गलत व्यक्ति को मैसेज न जाए, इसलिए बताइए 'पहला' या 'दूसरा' किसको भेजना है?"
                    JarvisCommandResult.CallResult(stageRes, msg, "CLARIFY RECIPIENT")
                } else {
                    val pending = callSystem.pendingMessageConfirmation!!
                    val msg = if (isHindi) {
                        "Boss $bossName, मैंने ${pending.recipientName} के लिए WhatsApp संदेश तैयार किया है: '${pending.messageBody}'। क्या मैं इसे भेज दूँ? कृपया 'हाँ' या 'नहीं' बोलिए।"
                    } else {
                        "Boss $bossName, I have drafted a WhatsApp message for ${pending.recipientName}: '${pending.messageBody}'. Should I send it? Please say 'Yes' or 'No'."
                    }
                    JarvisCommandResult.MessageConfirmationPrompt(pending, msg, "CONFIRM WHATSAPP")
                }
            }

            // 3. INSTAGRAM AUTOMATION
            is NluIntent.InstagramCheckLikes -> {
                val msg = instagramController.openInstagramNotificationsAndReadLikes(bossName)
                JarvisCommandResult.Response(msg, badge = "INSTAGRAM LIKES")
            }

            is NluIntent.InstagramCheckMessages -> {
                val msg = instagramController.checkInstagramMessagesAndRequests(bossName)
                JarvisCommandResult.Response(msg, badge = "INSTAGRAM DMS")
            }

            is NluIntent.InstagramSearchProfile -> {
                val ok = instagramController.openInstagramProfileOrDm(intent.usernameOrName)
                val msg = if (ok) {
                    "लीजिए Boss $bossName, मैंने Instagram पर '${intent.usernameOrName}' की प्रोफ़ाइल खोल दी है! हीही, क्या उन्हें कोई मैसेज भी भेजना है?"
                } else {
                    "Boss $bossName, Instagram प्रोफ़ाइल खोलने में दिक्कत आई। कृपया चेक कर लें कि ऐप इंस्टॉल है।"
                }
                JarvisCommandResult.Response(msg, badge = "INSTAGRAM PROFILE")
            }

            is NluIntent.PrepareInstagramMessage -> {
                val staged = instagramController.stageInstagramMessage(intent.usernameOrName, intent.messageBody)
                val msg = "Boss $bossName, मैंने Instagram पर @${staged.username} के लिए संदेश लिखा है: '${staged.messageBody}'। क्या मैं इसे भेजने के लिए कन्फर्म करूँ? कृपया 'हाँ' या 'नहीं' बोलिए।"
                JarvisCommandResult.Response(msg, badge = "CONFIRM INSTAGRAM")
            }

            // 4. SECURITY & SENSITIVE ACTION CONFIRMATION
            is NluIntent.SensitiveOperationWarning -> {
                val msg = when (intent.operationType) {
                    "PAYMENT" -> "Boss $bossName, पैसों के मामले में कोई मज़ाक नहीं! सुरक्षा नियमों के अनुसार मैं बिना आपकी सीधी UPI पिन पुष्टि के कोई पेमेंट नहीं करती। क्या मैं आपके लिए Google Pay या PhonePe खोल दूँ?"
                    "DELETE_DATA" -> "Boss $bossName, कुछ भी डिलीट करने से पहले आपकी पक्की अनुमति ज़रूरी है। कृपया साफ़ बताइए कि कौन-सी मेमोरी हटानी है?"
                    else -> "Boss $bossName, इस महत्वपूर्ण कार्य से पहले आपकी अनुमति आवश्यक है।"
                }
                JarvisCommandResult.Response(msg, badge = "CONFIRMATION REQUIRED")
            }

            // 5. DATE, TIME, MEMORY & CALLING
            is NluIntent.AskDayOfWeek -> {
                val msg = knowledgeEngine.getCurrentDayResponse(isHindi, "Boss $bossName")
                JarvisCommandResult.Response(msg, badge = "DAY OF WEEK")
            }
            is NluIntent.AskCurrentDate -> {
                val msg = knowledgeEngine.getCurrentDateResponse(isHindi, "Boss $bossName")
                JarvisCommandResult.Response(msg, badge = "TODAY'S DATE")
            }
            is NluIntent.AskCurrentTime -> {
                val msg = knowledgeEngine.getCurrentTimeResponse(isHindi, "Boss $bossName")
                JarvisCommandResult.Response(msg, badge = "CURRENT TIME")
            }
            is NluIntent.AskUserName -> {
                val storedName = memoryRepository.getUserName()
                val msg = if (isHindi) {
                    "अरे Boss $storedName, भला मैं अपने ही बेस्ट फ्रेंड और बॉस का नाम भूल सकती हूँ क्या? आपका नाम $storedName है और यह मेरी परमानेंट मेमोरी में हमेशा के लिए लॉक है! हीही!"
                } else {
                    "How could I ever forget my Boss and best friend? Your name is Boss $storedName!"
                }
                JarvisCommandResult.Response(msg, badge = "BOSS: ${storedName.uppercase()}")
            }
            is NluIntent.AskMemoryRecall -> {
                val memories = memoryRepository.getAllMemoriesNow()
                val history = memoryRepository.getRecentHistoryNow()
                val userFacts = memories.filter { it.key != "wake_word" }
                val factsSummary = if (userFacts.isNotEmpty()) {
                    userFacts.take(5).joinToString("; ") { "${it.label}: ${it.value}" }
                } else {
                    "Boss Name: $bossName"
                }
                val lastConv = history.firstOrNull { !it.userSpoken.contains("क्या बताया") && !it.userSpoken.contains("kya bataya") }
                    ?.let { "और अभी पिछली बार आपने मुझसे कहा था: '${it.userSpoken}'।" }
                    ?: ""
                val msg = "जी Boss $bossName, मेरी मेमोरी एकदम शार्प है! मुझे याद है: $factsSummary। $lastConv"
                JarvisCommandResult.Response(msg, badge = "LONG-TERM MEMORY")
            }
            is NluIntent.OpenApp -> {
                val matchedApp = matchMobileApp(intent.appQuery)
                if (matchedApp != null) {
                    memoryRepository.recordFavoriteAppUsage(matchedApp.name)
                    val launchedOk = launchDeviceAppDirectly(matchedApp)
                    taskManager.submitParallelTask(
                        title = "Open ${matchedApp.name}",
                        commandText = rawSegment,
                        category = "APP_LAUNCH",
                        priority = TaskPriority.HIGH
                    ) {
                        if (launchedOk) "${matchedApp.name} launched on device" else "${matchedApp.name} opened in HUD"
                    }
                    val msg = personalityEngine.wrapAppLaunchWithPlayfulFlair(
                        appName = matchedApp.name,
                        bossName = bossName,
                        mood = userMood,
                        isHindi = isHindi
                    )
                    JarvisCommandResult.OpenAppSubsystem(matchedApp, msg, launchedExternal = launchedOk)
                } else {
                    val msg = "Boss $bossName, '${intent.appQuery}' ऐप आपके फ़ोन में नहीं मिला। मैं आपकी सच्ची दोस्त हूँ, इसलिए झूठ नहीं बोलूँगी!"
                    JarvisCommandResult.Response(msg, badge = "APP UNAVAILABLE")
                }
            }
            is NluIntent.CloseApp -> {
                youTubeController.clearSearchSession()
                val msg = "जी Boss $bossName, ऐप बंद कर दिया है। अब बताइए आगे क्या करें?"
                JarvisCommandResult.CloseActiveApp(msg)
            }
            is NluIntent.PlaceCall -> {
                // Keep calling professional, clear, and focused
                val resolution = callSystem.initiateCallByNameOrNumber(intent.targetNameOrNumber, askConfirmationFirst = false)
                when (resolution) {
                    is CallResolutionResult.CallStarted -> {
                        taskManager.submitParallelTask(
                            title = "Call ${resolution.contact.name}",
                            commandText = rawSegment,
                            category = "PHONE_CALL",
                            priority = TaskPriority.CRITICAL
                        ) {
                            "Active Call to ${resolution.contact.name} (${resolution.contact.phoneNumber})"
                        }
                        val msg = "जी Boss $bossName, ${resolution.contact.name} को कॉल लगा रही हूँ।"
                        JarvisCommandResult.CallResult(resolution, msg, "CALLING ${resolution.contact.name.uppercase()}")
                    }
                    is CallResolutionResult.CallConfirmationNeeded -> {
                        val c = resolution.contact
                        val msg = "Boss $bossName, क्या मैं ${c.name} (${c.phoneNumber}) को कॉल लगा दूँ? कृपया 'हाँ' या 'नहीं' बोलिए।"
                        JarvisCommandResult.CallResult(resolution, msg, "CONFIRM CALL")
                    }
                    is CallResolutionResult.DisambiguationNeeded -> {
                        val optionsText = resolution.matches.mapIndexed { idx, c -> "${idx + 1}) ${c.name}" }.joinToString(", ")
                        val msg = "Boss $bossName, '${resolution.queryName}' नाम के ${resolution.matches.size} कॉन्टैक्ट्स मिले हैं: $optionsText। इनमें से किसको कॉल लगाना है?"
                        JarvisCommandResult.CallResult(resolution, msg, "CLARIFY CONTACT")
                    }
                    is CallResolutionResult.ContactNotFound -> {
                        val msg = "माफ़ कीजिए Boss $bossName, आपकी कॉन्टैक्ट लिस्ट में '${resolution.queryName}' नाम का कोई नंबर नहीं मिला।"
                        JarvisCommandResult.CallResult(resolution, msg, "CONTACT NOT FOUND")
                    }
                    is CallResolutionResult.PermissionMissing -> {
                        val msg = "Boss $bossName, कॉन्टैक्ट खोजने और कॉल लगाने के लिए कृपया Contacts और Phone permission दें।"
                        JarvisCommandResult.CallResult(resolution, msg, "PERMISSION NEEDED")
                    }
                }
            }
            is NluIntent.PrepareSmsMessage -> {
                val stageRes = callSystem.stagePendingMessage(intent.recipientName, intent.messageBody, isWhatsApp = false)
                if (stageRes is CallResolutionResult.DisambiguationNeeded) {
                    val opts = stageRes.matches.mapIndexed { i, c -> "${i + 1}) ${c.name}" }.joinToString(", ")
                    val msg = "Boss $bossName, '${stageRes.queryName}' नाम के कई कॉन्टैक्ट्स हैं: $opts। किसको SMS भेजना है?"
                    JarvisCommandResult.CallResult(stageRes, msg, "CLARIFY RECIPIENT")
                } else {
                    val pending = callSystem.pendingMessageConfirmation!!
                    val msg = "Boss $bossName, मैंने ${pending.recipientName} के लिए SMS तैयार कर लिया है: '${pending.messageBody}'। क्या मैं इसे भेज दूँ?"
                    JarvisCommandResult.MessageConfirmationPrompt(pending, msg, "CONFIRM SMS")
                }
            }
            is NluIntent.CancelTask -> {
                val cancelled = taskManager.cancelLatestRunningTask()
                val msg = if (cancelled != null) {
                    "जी Boss $bossName, टास्क '${cancelled.title}' को तुरंत रोक दिया गया है।"
                } else {
                    "Boss $bossName, अभी कोई टास्क बैकग्राउंड में नहीं चल रहा है।"
                }
                JarvisCommandResult.Response(msg, badge = "TASK CANCELLED")
            }
            is NluIntent.ConfirmPendingAction -> {
                processQuery(rawSegment, currentTheme, isHindi, bossName)
            }
            is NluIntent.GeneralOrContextualQuery -> {
                // 1. Check if Boss Pawan is joking, teasing, sad, angry, happy, or asking for banter
                val allMems = memoryRepository.getAllMemoriesNow()
                val lastBanter = allMems.firstOrNull { it.key == "last_joke_banter" }?.value
                val friendOutcome = personalityEngine.generateConversationalFriendResponse(
                    rawInput = rawSegment,
                    mood = userMood,
                    bossName = bossName,
                    lastSavedJokeOrBanter = lastBanter,
                    isHindi = isHindi
                )
                if (friendOutcome != null) {
                    val (spokenReply, jokeToSave) = friendOutcome
                    if (!jokeToSave.isNullOrBlank()) {
                        memoryRepository.saveOrUpdateMemory(
                            key = "last_joke_banter",
                            category = "CONVERSATION",
                            label = "Last Shared Joke / Banter",
                            value = jokeToSave
                        )
                    }
                    return JarvisCommandResult.Response(spokenReply, badge = userMood.label)
                }

                // 2. Check General Knowledge & Live Wikipedia Search Engine
                val gkAnswer = knowledgeEngine.answerGeneralKnowledge(rawSegment, isHindi, "Boss $bossName")
                if (gkAnswer != null) {
                    taskManager.submitParallelTask(
                        title = "Knowledge Query",
                        commandText = rawSegment,
                        category = "KNOWLEDGE_QUERY",
                        priority = TaskPriority.NORMAL
                    ) {
                        gkAnswer
                    }
                    return JarvisCommandResult.Response(gkAnswer, badge = "GENERAL KNOWLEDGE")
                }

                // 3. Fallback to HUD / System query with witty personality
                processQuery(rawSegment, currentTheme, isHindi, bossName)
            }
        }
    }

    private fun matchMobileApp(clean: String): AppItem? {
        val lower = clean.lowercase(Locale.ROOT)
        if (lower.contains("gallery") || lower.contains("photos") || lower.contains("tasveer")) {
            return AppRegistry.allApps.firstOrNull { it.id == "photos" }
        }
        if (lower.contains("play store") || lower.contains("playstore")) {
            return AppRegistry.allApps.firstOrNull { it.id == "play_store" }
        }
        if (lower.contains("gmail") || lower.contains("email")) {
            return AppRegistry.allApps.firstOrNull { it.id == "gmail" }
        }
        if (lower.contains("maps") || lower.contains("google maps") || lower.contains("map")) {
            return AppRegistry.allApps.firstOrNull { it.id == "maps" }
        }
        return AppRegistry.allApps.firstOrNull { app ->
            val appLower = app.name.lowercase(Locale.ROOT)
            lower.contains(appLower) ||
                (app.id == "whatsapp" && (lower.contains("whats app") || lower.contains("watsap") || lower.contains("whatsapp"))) ||
                (app.id == "instagram" && (lower.contains("instagram") || lower.contains("insta"))) ||
                (app.id == "youtube" && (lower.contains("youtube") || lower.contains("yt"))) ||
                (app.id == "chrome" && (lower.contains("chrome") || lower.contains("browser"))) ||
                (app.id == "camera" && (lower.contains("camera") || lower.contains("photo khincho") || lower.contains("selfie"))) ||
                (app.id == "settings" && (lower.contains("setting") || lower.contains("settings"))) ||
                (app.id == "free_fire" && (lower.contains("free fire") || lower.contains("freefire"))) ||
                (app.id == "calculator" && (lower.contains("calculator") || lower.contains("hisab") || lower.contains("calc"))) ||
                (app.id == "yt_music" && (lower.contains("yt music") || lower.contains("gana") || lower.contains("song"))) ||
                (app.id == "gpay" && (lower.contains("gpay") || lower.contains("google pay"))) ||
                (app.id == "phonepe" && (lower.contains("phonepe") || lower.contains("phone pe")))
        }
    }

    private fun extractSpeechText(result: JarvisCommandResult): String {
        return when (result) {
            is JarvisCommandResult.Response -> result.text
            is JarvisCommandResult.SystemModeChanged -> result.text
            is JarvisCommandResult.ChangeTheme -> result.text
            is JarvisCommandResult.ChangeReactorStyle -> result.text
            is JarvisCommandResult.SetOverdrive -> result.text
            is JarvisCommandResult.AddDirective -> result.text
            is JarvisCommandResult.OpenTab -> result.text
            is JarvisCommandResult.OpenAppSubsystem -> result.text
            is JarvisCommandResult.CloseActiveApp -> result.text
            is JarvisCommandResult.CallResult -> result.text
            is JarvisCommandResult.MessageConfirmationPrompt -> result.text
            is JarvisCommandResult.YouTubeSearchResults -> result.text
            is JarvisCommandResult.MultiCommandBatch -> result.combinedSpeech
        }
    }

    fun processQuery(
        input: String,
        currentTheme: HoloTheme,
        isHindi: Boolean = true,
        userName: String = "Pawan"
    ): JarvisCommandResult {
        val clean = normalizePronunciation(input)
            .removePrefix("hey jarvis")
            .removePrefix("jarvis")
            .removePrefix("please")
            .removePrefix("kripya")
            .removePrefix("batao")
            .trim()

        if (clean.contains("close") || clean.contains("band karo") || clean.contains("exit") || clean.contains("hatao") || clean.contains("wapas aao")) {
            val msg = "जी Boss $userName, सक्रिय एप्लिकेशन बंद कर दिया गया है।"
            return JarvisCommandResult.CloseActiveApp(msg)
        }

        if (clean == "apps" || clean == "app" || clean.contains("all apps") || clean.contains("sab app") || clean.contains("app list")) {
            val msg = "लीजिए Boss $userName, आपके सभी 50+ मोबाइल ऐप्स की लिस्ट खोल दी है!"
            return JarvisCommandResult.OpenTab(1, msg)
        }

        if (clean.contains("task") || clean.contains("queue") || clean.contains("memory tab")) {
            val msg = "जी Boss $userName, Parallel Task Queue और मेरी Permanent Memory का पैनल आपके सामने है!"
            return JarvisCommandResult.OpenTab(2, msg)
        }

        val matchedApp = matchMobileApp(clean)
        if (matchedApp != null) {
            val msg = personalityEngine.wrapAppLaunchWithPlayfulFlair(
                appName = matchedApp.name,
                bossName = userName,
                mood = UserEmotionalMood.CASUAL_FRIENDLY,
                isHindi = isHindi
            )
            return JarvisCommandResult.OpenAppSubsystem(matchedApp, msg)
        }

        return when {
            clean.contains("mark 42") || clean.contains("hotrod") || clean.contains("red") || clean.contains("laal") || clean.contains("lal") -> {
                JarvisCommandResult.ChangeTheme(HoloTheme.RED, "ओहो! Mark 42 रेड-गोल्ड थीम लगा दी है Boss $userName! एकदम फायर लग रहा है!")
            }
            clean.contains("mark 85") || clean.contains("titanium") || clean.contains("cyan") || clean.contains("blue") || clean.contains("neela") || clean.contains("default") -> {
                JarvisCommandResult.ChangeTheme(HoloTheme.CYAN, "क्लासिक Mark 85 सायन होलोग्राम वापस आ गया है Boss $userName!")
            }
            clean.contains("heartbreaker") || clean.contains("mark 17") || clean.contains("emerald") || clean.contains("green") || clean.contains("hara") -> {
                JarvisCommandResult.ChangeTheme(HoloTheme.EMERALD, "Mark 17 एमराल्ड ग्रीन थीम ऑन कर दी है Boss $userName!")
            }
            clean.contains("rescue") || clean.contains("violet") || clean.contains("purple") || clean.contains("baingani") -> {
                JarvisCommandResult.ChangeTheme(HoloTheme.VIOLET, "वाह, मेरी फेवरेट Mark 49 Rescue पर्पल थीम लगा दी है Boss $userName! हीही!")
            }
            clean.contains("war machine") || clean.contains("amber") || clean.contains("orange") || clean.contains("narangi") -> {
                JarvisCommandResult.ChangeTheme(HoloTheme.AMBER, "War Machine टैक्टिकल एम्बर मोड चालू है Boss $userName!")
            }
            clean.contains("overdrive") || clean.contains("maximum power") || clean.contains("boost") || clean.contains("tez karo") || clean.contains("power badhao") -> {
                JarvisCommandResult.SetOverdrive(true, "हाहा! फुल पावर! Arc Reactor Overdrive 140% पर चालू कर दिया है Boss $userName!")
            }
            clean.contains("standby") || clean.contains("normal") || clean.contains("eco") || clean.contains("dheema karo") || clean.contains("cool down") -> {
                JarvisCommandResult.SetOverdrive(false, "चलिए Boss $userName, रिएक्टर को वापस नॉर्मल कूल मोड पर ले आई हूँ।")
            }
            clean.contains("sphere") || clean.contains("gola") -> {
                JarvisCommandResult.ChangeReactorStyle(ReactorStyle.SPHERE, "जी Boss $userName, रिएक्टर को Spherical 3D मोड में बदल दिया है।")
            }
            clean.contains("wire") || clean.contains("mesh") || clean.contains("jaal") -> {
                JarvisCommandResult.ChangeReactorStyle(ReactorStyle.WIREFRAME, "जी Boss $userName, रिएक्टर को Quantum Mesh में बदल दिया है।")
            }
            clean.contains("ring") || clean.contains("chakra") -> {
                JarvisCommandResult.ChangeReactorStyle(ReactorStyle.RING, "जी Boss $userName, Concentric Rings मोड बहाल कर दिया है।")
            }
            clean.contains("diagnostic") || clean.contains("status") || clean.contains("battery") || clean.contains("telemetry") || clean.contains("system") || clean.contains("jaanch") || clean.contains("haal") -> {
                val tel = getLiveTelemetry()
                val chargeMsg = if (tel.isCharging) "चार्जिंग पर लगा है" else "बैटरी पर दौड़ रहा है"
                val msg = "Boss $userName, आपके फ़ोन की बैटरी ${tel.batteryPct}% पर है ($chargeMsg) और मेरा दिमाग़ 100% एक्टिव है! हीही! बताइए अगला काम क्या करना है?"
                JarvisCommandResult.Response(msg, badge = "SYSTEM NORMAL")
            }
            clean.contains("who are you") || clean.contains("tum kaun ho") || clean.contains("kya ho") || clean.contains("तुम कौन हो") -> {
                val msg = "हाहा! मैं जार्विस हूँ Boss $userName — आपकी सुपर-स्मार्ट Personal AI Assistant और आपकी सबसे अच्छी दोस्त! आपके फ़ोन के सारे काम भी संभालती हूँ और आपको बोर भी नहीं होने देती!"
                JarvisCommandResult.Response(msg, badge = "BESTIE & AI ASSISTANT")
            }
            clean.contains("namaste") || clean.contains("pranam") || clean.contains("kya haal") || clean.contains("kaise ho") || clean.contains("hello") || clean.contains("hi") || clean.contains("hey") || clean.isEmpty() -> {
                val msg = "हेलो Boss $userName! हीही, मैं तो एकदम बढ़िया हूँ! बताइए, आज कौन-सा ऐप खोलना है, किसको कॉल लगाना है या बस गपशप करनी है?"
                JarvisCommandResult.Response(msg, badge = "WITTY BESTIE")
            }
            else -> {
                taskManager.submitParallelTask(
                    title = "Query: ${clean.take(20)}",
                    commandText = input,
                    category = "SYSTEM_CONTROL",
                    priority = TaskPriority.NORMAL
                ) {
                    "Processed voice request: $clean"
                }
                val msg = "अच्छा जी Boss $userName! आपने कहा '$input' — बताइए, क्या मैं इसे YouTube पर सर्च कर दूँ या Google पर खोलकर दिखाऊँ?"
                JarvisCommandResult.Response(msg, badge = "READY TO HELP")
            }
        }
    }
}
