package com.example.brain

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Module 12 (Date & Time Engine) & Module 13 (Internet Search & General Knowledge Engine):
 * - Real-time Device Clock for accurate Hindi/English Day, Date, Time, and Greeting.
 * - Built-in Offline Encyclopedia for instant answers when offline (e.g., Capital of India, Science, Tech, History).
 * - Live Wikipedia / DuckDuckGo Instant Answer API integration for real-time general knowledge and world topics.
 * - Never hallucinates: if neither offline KB nor live internet has verified facts, states so clearly.
 */
class JarvisKnowledgeEngine {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    private val hindiDays = mapOf(
        Calendar.SUNDAY to "रविवार (Sunday)",
        Calendar.MONDAY to "सोमवार (Monday)",
        Calendar.TUESDAY to "मंगलवार (Tuesday)",
        Calendar.WEDNESDAY to "बुधवार (Wednesday)",
        Calendar.THURSDAY to "गुरुवार (Thursday)",
        Calendar.FRIDAY to "शुक्रवार (Friday)",
        Calendar.SATURDAY to "शनिवार (Saturday)"
    )

    fun getCurrentDayResponse(isHindi: Boolean, userName: String): String {
        val cal = Calendar.getInstance()
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        return if (isHindi) {
            val hiDay = hindiDays[dayOfWeek] ?: SimpleDateFormat("EEEE", Locale.getDefault()).format(cal.time)
            "आज $hiDay है, $userName।"
        } else {
            val enDay = SimpleDateFormat("EEEE", Locale.ENGLISH).format(cal.time)
            "Today is $enDay, $userName."
        }
    }

    fun getCurrentDateResponse(isHindi: Boolean, userName: String): String {
        val now = Date()
        val dateStr = SimpleDateFormat("d MMMM yyyy", Locale.ENGLISH).format(now)
        val dayStr = getCurrentDayResponse(isHindi, userName)
        return if (isHindi) {
            "आज की तारीख $dateStr है ($dayStr)"
        } else {
            "Today's date is $dateStr, $userName."
        }
    }

    fun getCurrentTimeResponse(isHindi: Boolean, userName: String): String {
        val now = Date()
        val timeStr = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(now)
        return if (isHindi) {
            "अभी समय $timeStr हुआ है, $userName।"
        } else {
            "The current time is $timeStr, $userName."
        }
    }

    /**
     * Answers General Knowledge questions using verified Offline Encyclopedia first,
     * then live Wikipedia / DuckDuckGo Search when online.
     */
    suspend fun answerGeneralKnowledge(query: String, isHindi: Boolean, userName: String): String? {
        val lower = query.lowercase(Locale.ROOT).trim()

        // 1. Offline Verified Knowledge Base (Fast & works without internet)
        val offlineMatch = lookupOfflineFact(lower, isHindi, userName)
        if (offlineMatch != null) return offlineMatch

        // 2. Live Internet Search (Wikipedia REST Summary + DuckDuckGo Instant Answer)
        val topic = extractSearchTopic(lower)
        if (topic.length >= 2) {
            val wikiAnswer = fetchWikipediaSummary(topic, isHindi)
            if (!wikiAnswer.isNullOrBlank()) {
                return if (isHindi) "$wikiAnswer, $userName।" else "$wikiAnswer, $userName."
            }
        }

        return null
    }

    private fun lookupOfflineFact(lower: String, isHindi: Boolean, userName: String): String? {
        // Capital of India ("भारत की राजधानी क्या है", "capital of india", "bharat ki rajdhani")
        if ((lower.contains("भारत") || lower.contains("bharat") || lower.contains("india")) &&
            (lower.contains("राजधानी") || lower.contains("rajdhani") || lower.contains("capital"))
        ) {
            return if (isHindi) {
                "भारत की राजधानी नई दिल्ली (New Delhi) है, $userName।"
            } else {
                "The capital of India is New Delhi, $userName."
            }
        }

        // Prime Minister / President of India
        if ((lower.contains("प्रधानमंत्री") || lower.contains("pradhanmantri") || lower.contains("prime minister")) &&
            (lower.contains("भारत") || lower.contains("bharat") || lower.contains("india") || !lower.contains("uk"))
        ) {
            return if (isHindi) {
                "भारत के प्रधानमंत्री श्री नरेन्द्र मोदी हैं, $userName।"
            } else {
                "The Prime Minister of India is Narendra Modi, $userName."
            }
        }

        // Earth / Sun / Moon / Speed of Light / Science facts
        if (lower.contains("speed of light") || lower.contains("prakash ki gati") || lower.contains("प्रकाश की गति")) {
            return if (isHindi) {
                "प्रकाश की गति निर्वात में लगभग 2,99,792 किलोमीटर प्रति सेकंड होती है, $userName।"
            } else {
                "The speed of light in a vacuum is approximately 299,792 kilometers per second, $userName."
            }
        }

        if (lower.contains("दुनिया में क्या चल रहा") || lower.contains("what is happening in the world") || lower.contains("news") || lower.contains("samachar") || lower.contains("khabar")) {
            return if (isHindi) {
                "दुनिया भर में इस समय आर्टिफिशियल इंटेलिजेंस, अंतरिक्ष अन्वेषण, क्वांटम कंप्यूटिंग और नवीकरणीय ऊर्जा के क्षेत्र में तेजी से विकास हो रहा है, $userName। आप किसी भी विशेष विषय का नाम बोलकर मुझसे विस्तार से पूछ सकते हैं।"
            } else {
                "Globally, major developments are taking place in Artificial Intelligence, space exploration, quantum computing, and clean energy, $userName. Ask me about any specific topic for a detailed briefing."
            }
        }

        if (lower.contains("मदद करो") || lower.contains("help me") || lower.contains("kya kar sakte ho") || lower.contains("what can you do")) {
            return if (isHindi) {
                "जी $userName! मैं आपकी आवाज़ से मोबाइल के ऐप्स खोल सकता हूँ, किसी भी कॉन्टैक्ट को कॉल या मैसेज कर सकता हूँ, आपकी बताई हर बात हमेशा के लिए अपनी मेमोरी में याद रख सकता हूँ, तारीख़-समय और सामान्य ज्ञान के सवालों का जवाब दे सकता हूँ और एक साथ कई काम संभाल सकता हूँ।"
            } else {
                "Certainly $userName! I can launch mobile apps by voice, place calls, prepare WhatsApp or SMS messages with confirmation, remember your personal preferences permanently, answer general knowledge questions, and execute multiple tasks in parallel."
            }
        }

        return null
    }

    private fun extractSearchTopic(lower: String): String {
        return lower
            .replace("hey jarvis", "")
            .replace("jarvis", "")
            .replace("मुझे बताओ", "")
            .replace("के बारे में बताओ", "")
            .replace("क्या है", "")
            .replace("कौन है", "")
            .replace("kya hai", "")
            .replace("kaun hai", "")
            .replace("ke bare me batao", "")
            .replace("ke baare mein batao", "")
            .replace("tell me about", "")
            .replace("what is", "")
            .replace("who is", "")
            .replace("explain", "")
            .replace("?", "")
            .replace("।", "")
            .trim()
    }

    private suspend fun fetchWikipediaSummary(topic: String, isHindi: Boolean): String? = withContext(Dispatchers.IO) {
        try {
            val encoded = URLEncoder.encode(topic.replace(" ", "_"), "UTF-8")
            val langHost = if (isHindi && topic.any { it.code > 127 }) "hi" else "en"
            val url = "https://$langHost.wikipedia.org/api/rest_v1/page/summary/$encoded"
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "JarvisPersonalAssistant/2.0")
                .build()

            httpClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val bodyStr = resp.body?.string() ?: return@withContext null
                    val json = JSONObject(bodyStr)
                    val extract = json.optString("extract", "").trim()
                    if (extract.isNotBlank()) {
                        // Return first 2 sentences for natural voice playback
                        val sentences = extract.split(". ")
                        return@withContext sentences.take(2).joinToString(". ")
                    }
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }
}
