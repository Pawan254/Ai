package com.example.brain

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.service.JarvisNotificationListenerService

data class PendingInstagramMessage(
    val username: String,
    val messageBody: String
)

/**
 * Instagram Voice Automation Engine:
 * - Opens Instagram main feed, activity notifications, direct messages, or specific user profiles (`instagram.com/_u/{username}`).
 * - Reads real Instagram Like & DM notifications captured by JarvisNotificationListenerService when Notification Access is enabled.
 * - Never claims to know private Instagram data that is not exposed by Android notifications or the logged-in account.
 * - Stages dictated Instagram messages and requires explicit user confirmation ("Haan" / "Yes") before opening the DM thread.
 */
class JarvisInstagramController(private val context: Context) {

    var pendingInstagramMessage: PendingInstagramMessage? = null
        private set

    fun clearPendingMessage() {
        pendingInstagramMessage = null
    }

    fun stageInstagramMessage(username: String, messageBody: String): PendingInstagramMessage {
        val cleanUser = username.trim().removePrefix("@").replace(" ", "_").lowercase()
        val staged = PendingInstagramMessage(username = cleanUser, messageBody = messageBody.trim())
        pendingInstagramMessage = staged
        return staged
    }

    fun executeConfirmedInstagramMessage(): Boolean {
        val pending = pendingInstagramMessage ?: return false
        pendingInstagramMessage = null
        return openInstagramProfileOrDm(pending.username)
    }

    fun openInstagramHome(): Boolean {
        return try {
            val pm = context.packageManager
            val launchIntent = pm.getLaunchIntentForPackage("com.instagram.android")
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                true
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    fun openInstagramProfileOrDm(rawUsername: String): Boolean {
        val cleanUser = rawUsername.trim().removePrefix("@").replace(" ", "").lowercase()
        return try {
            val pm = context.packageManager
            if (pm.getLaunchIntentForPackage("com.instagram.android") != null) {
                val uri = Uri.parse("http://instagram.com/_u/$cleanUser")
                val appIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage("com.instagram.android")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(appIntent)
            }
            true
        } catch (_: Exception) {
            true
        }
    }

    fun openInstagramNotificationsAndReadLikes(bossName: String): String {
        openInstagramHome()
        val hasAccess = JarvisNotificationListenerService.isNotificationAccessEnabled(context)
        val likers = JarvisNotificationListenerService.getInstagramLikersSummary()

        return if (likers.isNotEmpty()) {
            val summary = likers.take(4).joinToString("; ")
            "Boss $bossName, Instagram खोल दिया गया है। हाल ही में आपकी पोस्ट लाइक करने वालों के नोटिफिकेशन हैं: $summary।"
        } else if (!hasAccess) {
            "Boss $bossName, मैंने Instagram खोल दिया है। Instagram अपनी प्राइवेट पोस्ट लाइक्स की सूची किसी बाहरी ऐप को बिना Notification Access के नहीं देता। यदि आप Settings में JARVIS Notification Reader चालू कर देंगे, तो जब भी कोई आपकी पोस्ट लाइक करेगा या मैसेज भेजेगा, मैं उसका नाम तुरंत पढ़कर सुना दूँगी।"
        } else {
            "Boss $bossName, मैंने Instagram खोल दिया है। अभी आपके नोटिफिकेशन पैनल में कोई नया Instagram लाइक नोटिफिकेशन नहीं आया है। मैं कोई भी नकली या प्राइवेट जानकारी अपने आप नहीं बनाती।"
        }
    }

    fun checkInstagramMessagesAndRequests(bossName: String): String {
        openInstagramHome()
        val hasAccess = JarvisNotificationListenerService.isNotificationAccessEnabled(context)
        val dmList = JarvisNotificationListenerService.getInstagramMessagesSummary()

        return if (dmList.isNotEmpty()) {
            val summary = dmList.take(4).joinToString("; ")
            "Boss $bossName, आपके उपलब्ध Instagram मैसेज नोटिफिकेशन हैं: $summary। क्या आप किसी का रिप्लाई लिखवाना चाहेंगे?"
        } else if (!hasAccess) {
            "Boss $bossName, मैंने Instagram खोल दिया है। Instagram के प्राइवेट इनबॉक्स और Message Requests केवल ऐप के अंदर या Notification Access अनुमति मिलने पर ही पढ़े जा सकते हैं।"
        } else {
            "Boss $bossName, Instagram खोल दिया गया है। अभी कोई अपठित Instagram DM नोटिफिकेशन उपलब्ध नहीं है।"
        }
    }
}
