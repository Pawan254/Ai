package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.service.JarvisBackgroundService
import com.example.ui.JarvisMainScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Allow Jarvis to work and respond smoothly even when the screen is locked
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        // Pre-warm shared Brain & Voice Engine so the virtual device responds immediately
        JarvisBackgroundService.ensureVoiceEngineReady(applicationContext)

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                var hasAudioPermission by remember {
                    mutableStateOf(
                        ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                    )
                }

                var hasContactsPermission by remember {
                    mutableStateOf(
                        ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.READ_CONTACTS
                        ) == PackageManager.PERMISSION_GRANTED
                    )
                }

                var hasCallPermission by remember {
                    mutableStateOf(
                        ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.CALL_PHONE
                        ) == PackageManager.PERMISSION_GRANTED
                    )
                }

                val lifecycleOwner = LocalLifecycleOwner.current
                DisposableEffect(lifecycleOwner) {
                    val observer = LifecycleEventObserver { _, event ->
                        if (event == Lifecycle.Event.ON_RESUME) {
                            val micGranted = ContextCompat.checkSelfPermission(
                                this@MainActivity,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            hasAudioPermission = micGranted
                            hasContactsPermission = ContextCompat.checkSelfPermission(
                                this@MainActivity,
                                Manifest.permission.READ_CONTACTS
                            ) == PackageManager.PERMISSION_GRANTED
                            hasCallPermission = ContextCompat.checkSelfPermission(
                                this@MainActivity,
                                Manifest.permission.CALL_PHONE
                            ) == PackageManager.PERMISSION_GRANTED

                            if (micGranted) {
                                JarvisBackgroundService.startPermanentService(this@MainActivity)
                            }
                        }
                    }
                    lifecycleOwner.lifecycle.addObserver(observer)
                    onDispose {
                        lifecycleOwner.lifecycle.removeObserver(observer)
                    }
                }

                val multiPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) { permissionsMap ->
                    permissionsMap[Manifest.permission.RECORD_AUDIO]?.let { granted ->
                        hasAudioPermission = granted
                        if (granted) {
                            JarvisBackgroundService.startPermanentService(this@MainActivity)
                        }
                    }
                    permissionsMap[Manifest.permission.READ_CONTACTS]?.let {
                        hasContactsPermission = it
                    }
                    permissionsMap[Manifest.permission.CALL_PHONE]?.let {
                        hasCallPermission = it
                    }
                }

                fun requestOneTimeSetupPermissions() {
                    val perms = mutableListOf(
                        Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.READ_CONTACTS,
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission.READ_PHONE_STATE
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        perms.add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    multiPermissionLauncher.launch(perms.toTypedArray())
                }

                // One-Time Permission Setup on first launch + Automatic Service Startup
                LaunchedEffect(Unit) {
                    if (hasAudioPermission) {
                        JarvisBackgroundService.startPermanentService(this@MainActivity)
                    } else {
                        requestOneTimeSetupPermissions()
                    }
                }

                JarvisMainScreen(
                    onRequestAudioPermission = {
                        requestOneTimeSetupPermissions()
                    },
                    hasAudioPermission = hasAudioPermission,
                    hasContactsPermission = hasContactsPermission,
                    hasCallPermission = hasCallPermission,
                    onRequestCallPermissions = {
                        requestOneTimeSetupPermissions()
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
