package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.brain.JarvisBrain
import com.example.brain.JarvisCommandResult
import com.example.brain.NluIntent
import com.example.model.HoloTheme
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var brain: JarvisBrain

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        brain = JarvisBrain(context)
    }

    @Test
    fun `read string from context`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("JARVIS", appName)
    }

    @Test
    fun `test Boss Pawan default identity and memory recall`() = runBlocking {
        val nameRes = brain.processVoiceCommandWithMemoryAndTasks("मेरा नाम क्या है?", HoloTheme.CYAN, isHindi = true)
        assertTrue(nameRes is JarvisCommandResult.Response)
        val text = (nameRes as JarvisCommandResult.Response).text
        assertTrue("Expected Pawan in response: $text", text.contains("Pawan", ignoreCase = true))
        assertTrue("Expected Boss in response: $text", text.contains("Boss", ignoreCase = true))
    }

    @Test
    fun `test YouTube voice search, result selection, playback and stop controls`() = runBlocking {
        // 1. "Jarvis, YouTube par Bhojpuri gana search karo"
        val searchRes = brain.processVoiceCommandWithMemoryAndTasks(
            "Jarvis, YouTube par Bhojpuri gana search karo",
            HoloTheme.CYAN,
            isHindi = true
        )
        assertTrue(searchRes is JarvisCommandResult.YouTubeSearchResults)
        val ytSearch = searchRes as JarvisCommandResult.YouTubeSearchResults
        assertTrue(ytSearch.items.isNotEmpty())
        assertTrue(ytSearch.text.contains("इनमें से कौन-सा प्ले करना है") || ytSearch.text.contains("kaunsa play karna hai"))

        // 2. Select video by saying "Ye gana chalao" or "पहला"
        val playRes = brain.processVoiceCommandWithMemoryAndTasks("Ye gana chalao", HoloTheme.CYAN, isHindi = true)
        assertTrue(playRes is JarvisCommandResult.Response)
        assertEquals("PLAYING YOUTUBE", (playRes as JarvisCommandResult.Response).badge)

        // 3. Pause / Resume / Stop ("Isko band karo") / Search again ("Kuchh aur search karo")
        val stopRes = brain.processVoiceCommandWithMemoryAndTasks("Isko band karo", HoloTheme.CYAN, isHindi = true)
        assertTrue(stopRes is JarvisCommandResult.Response)
        assertEquals("STOPPED", (stopRes as JarvisCommandResult.Response).badge)

        val searchAgainRes = brain.processVoiceCommandWithMemoryAndTasks("Kuchh aur search karo", HoloTheme.CYAN, isHindi = true)
        assertTrue(searchAgainRes is JarvisCommandResult.Response)
        assertEquals("YOUTUBE READY", (searchAgainRes as JarvisCommandResult.Response).badge)
    }

    @Test
    fun `test WhatsApp message dictation, confirmation prompt, and sending`() = runBlocking {
        // 1. "Boss, Amit ko message bhejo ki main kal aaunga"
        val draftRes = brain.processVoiceCommandWithMemoryAndTasks(
            "Boss, Amit ko message bhejo ki main kal aaunga",
            HoloTheme.CYAN,
            isHindi = true
        )
        assertTrue(draftRes is JarvisCommandResult.MessageConfirmationPrompt)
        val prompt = draftRes as JarvisCommandResult.MessageConfirmationPrompt
        assertEquals("Amit", prompt.pending.recipientName)
        assertTrue(prompt.pending.messageBody.contains("main kal aaunga", ignoreCase = true))
        assertNotNull(brain.callSystem.pendingMessageConfirmation)

        // 2. Confirm with "Haan"
        val confirmRes = brain.processVoiceCommandWithMemoryAndTasks("Haan", HoloTheme.CYAN, isHindi = true)
        assertTrue(confirmRes is JarvisCommandResult.Response)
        assertEquals("MESSAGE DISPATCHED", (confirmRes as JarvisCommandResult.Response).badge)
    }

    @Test
    fun `test Instagram voice automation and honest notification reporting`() = runBlocking {
        // 1. "Instagram kholo"
        val openIg = brain.processVoiceCommandWithMemoryAndTasks("Instagram kholo", HoloTheme.CYAN, isHindi = true)
        assertTrue(openIg is JarvisCommandResult.OpenAppSubsystem)
        assertEquals("Instagram", (openIg as JarvisCommandResult.OpenAppSubsystem).app.name)

        // 2. Check who liked posts (must not fabricate private data when notification listener is not populated)
        val likesRes = brain.processVoiceCommandWithMemoryAndTasks("Instagram par kisne like kiya", HoloTheme.CYAN, isHindi = true)
        assertTrue(likesRes is JarvisCommandResult.Response)
        assertEquals("INSTAGRAM LIKES", (likesRes as JarvisCommandResult.Response).badge)

        // 3. Search profile on Instagram
        val profileRes = brain.processVoiceCommandWithMemoryAndTasks("Instagram par Rahul ko dhundo", HoloTheme.CYAN, isHindi = true)
        assertTrue(profileRes is JarvisCommandResult.Response)
        assertEquals("INSTAGRAM PROFILE", (profileRes as JarvisCommandResult.Response).badge)
    }

    @Test
    fun `test Universal App Control commands`() = runBlocking {
        val mapsRes = brain.processVoiceCommandWithMemoryAndTasks("Google Maps kholo", HoloTheme.CYAN, isHindi = true)
        assertTrue(mapsRes is JarvisCommandResult.OpenAppSubsystem)
        assertEquals("Maps", (mapsRes as JarvisCommandResult.OpenAppSubsystem).app.name)

        val camRes = brain.processVoiceCommandWithMemoryAndTasks("Camera chalao", HoloTheme.CYAN, isHindi = true)
        assertTrue(camRes is JarvisCommandResult.OpenAppSubsystem)
        assertEquals("Camera", (camRes as JarvisCommandResult.OpenAppSubsystem).app.name)

        val settingsRes = brain.processVoiceCommandWithMemoryAndTasks("Mere phone ki settings kholo", HoloTheme.CYAN, isHindi = true)
        assertTrue(settingsRes is JarvisCommandResult.OpenAppSubsystem)
        assertEquals("Settings", (settingsRes as JarvisCommandResult.OpenAppSubsystem).app.name)
    }

    @Test
    fun `test Hey Jarvis Wake Word and Jarvis System Off`() = runBlocking {
        val wakeResult = brain.processVoiceCommandWithMemoryAndTasks("Hey Jarvis", HoloTheme.CYAN, isHindi = true)
        assertTrue(wakeResult is JarvisCommandResult.SystemModeChanged)
        val onMode = wakeResult as JarvisCommandResult.SystemModeChanged
        assertTrue(onMode.isSystemActive)
        assertEquals("जी, बताइए।", onMode.text)

        val offResult = brain.processVoiceCommandWithMemoryAndTasks("Jarvis System Off", HoloTheme.CYAN, isHindi = true)
        assertTrue(offResult is JarvisCommandResult.SystemModeChanged)
        assertFalse((offResult as JarvisCommandResult.SystemModeChanged).isSystemActive)
    }

    @Test
    fun `test Day, Date, Time, and Capital of India`() = runBlocking {
        val dayRes = brain.processVoiceCommandWithMemoryAndTasks("आज कौन-सा दिन है?", HoloTheme.CYAN, isHindi = true)
        assertEquals("DAY OF WEEK", (dayRes as JarvisCommandResult.Response).badge)

        val dateRes = brain.processVoiceCommandWithMemoryAndTasks("आज की तारीख क्या है?", HoloTheme.CYAN, isHindi = true)
        assertEquals("TODAY'S DATE", (dateRes as JarvisCommandResult.Response).badge)

        val timeRes = brain.processVoiceCommandWithMemoryAndTasks("अभी कितना समय हुआ है?", HoloTheme.CYAN, isHindi = true)
        assertEquals("CURRENT TIME", (timeRes as JarvisCommandResult.Response).badge)

        val capitalRes = brain.processVoiceCommandWithMemoryAndTasks("भारत की राजधानी क्या है?", HoloTheme.CYAN, isHindi = true)
        assertTrue((capitalRes as JarvisCommandResult.Response).text.contains("नई दिल्ली"))
    }

    @Test
    fun `test Witty Female Best Friend Personality, Mood Adaptation, and Joke Memory Continuity`() = runBlocking {
        // 1. Joke request saves banter memory and returns witty response
        val jokeRes = brain.processVoiceCommandWithMemoryAndTasks("Jarvis, ek funny joke sunao", HoloTheme.CYAN, isHindi = true)
        assertTrue(jokeRes is JarvisCommandResult.Response)
        val jokeResponse = jokeRes as JarvisCommandResult.Response
        assertEquals("PLAYFUL // BANTER", jokeResponse.badge)

        val savedJoke = brain.memoryRepository.getAllMemoriesNow().firstOrNull { it.key == "last_joke_banter" }
        assertNotNull("Expected last_joke_banter to be saved in permanent memory", savedJoke)

        // 2. Sad / low mood triggers empathetic caring friend response
        val sadRes = brain.processVoiceCommandWithMemoryAndTasks("Aaj mera mood off hai", HoloTheme.CYAN, isHindi = true)
        assertTrue(sadRes is JarvisCommandResult.Response)
        assertEquals("EMPATHETIC // CARING FRIEND", (sadRes as JarvisCommandResult.Response).badge)

        // 3. Angry / frustrated mood triggers calm de-escalating response
        val angryRes = brain.processVoiceCommandWithMemoryAndTasks("Tumhara dimaag kharab hai kya", HoloTheme.CYAN, isHindi = true)
        assertTrue(angryRes is JarvisCommandResult.Response)
        assertEquals("CALM // DE-ESCALATING", (angryRes as JarvisCommandResult.Response).badge)

        // 4. Playful drama / teasing triggers dramatic bestie comeback
        val dramaRes = brain.processVoiceCommandWithMemoryAndTasks("Tum bahut drama karti ho", HoloTheme.CYAN, isHindi = true)
        assertTrue(dramaRes is JarvisCommandResult.Response)
        assertEquals("PLAYFUL // BANTER", (dramaRes as JarvisCommandResult.Response).badge)

        // 5. Urgent task ("Turant Camera chalao") stays focused without unnecessary joke filler
        val urgentApp = brain.processVoiceCommandWithMemoryAndTasks("Turant Camera chalao", HoloTheme.CYAN, isHindi = true)
        assertTrue(urgentApp is JarvisCommandResult.OpenAppSubsystem)
        val urgentText = (urgentApp as JarvisCommandResult.OpenAppSubsystem).text
        assertFalse("Urgent launch should not contain playful banter filler", urgentText.contains("सेल्फी"))
    }
}

