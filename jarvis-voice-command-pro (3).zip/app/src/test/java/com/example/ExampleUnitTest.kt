package com.example

import com.example.model.DirectivePriority
import com.example.model.HoloTheme
import com.example.model.ReactorStyle
import com.example.model.TacticalDirective
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testHoloThemeDefinitions() {
        assertEquals("Mark LXXXV", HoloTheme.CYAN.title)
        assertEquals("Mark XLII", HoloTheme.RED.title)
        assertEquals("Mark XVII", HoloTheme.EMERALD.title)
        assertEquals("Mark XLIX", HoloTheme.VIOLET.title)
        assertEquals("Mark II", HoloTheme.AMBER.title)
    }

    @Test
    fun testReactorStyles() {
        assertEquals("CONCENTRIC RINGS", ReactorStyle.RING.label)
        assertEquals("SPHERICAL MATRIX", ReactorStyle.SPHERE.label)
        assertEquals("QUANTUM MESH", ReactorStyle.WIREFRAME.label)
    }

    @Test
    fun testTacticalDirective() {
        val directive = TacticalDirective(
            title = "Run Desktop Bridge Setup",
            detail = "Clone repository and run npm start",
            priority = DirectivePriority.CRITICAL
        )
        assertNotNull(directive.id)
        assertFalse(directive.isCompleted)
        assertEquals(DirectivePriority.CRITICAL, directive.priority)
    }

    @Test
    fun testVoiceIdNormalization() {
        val rawInput = "JBFqnCBsd6RMk/VDRZzb"
        val normalized = rawInput.trim().replace("/", "j")
        assertEquals("JBFqnCBsd6RMkjVDRZzb", normalized)
    }
}
